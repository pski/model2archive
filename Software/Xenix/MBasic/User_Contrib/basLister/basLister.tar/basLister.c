/*
 *  "basic_lister.c"
 */
#include <stdio.h>

main(argc, argv)
	int argc;
	char *argv[];
{
	FILE	*fp;
	char	*myname;

	myname = *argv;
	++argv, --argc;

	if (argc < 1)
		do_list(stdin);
	else while (argc > 0)
	{
		if (0 == strcmp(*argv, "-"))
			fp = stdin;
		else
			fp = fopen(*argv, "r");
		if (0 == fp) {
			fprintf(stderr, "%s: Can't open argument ", myname);
			perror(*argv);
		}
		else {
			do_list(fp);
			if (stdin != fp)
				fclose(fp);
		}

		--argc, ++argv;
	}

	exit(0);
}

char *
token_lookup(tok, fp)
	int		tok;
	FILE	*fp;
{
	static char rval[30];
	unsigned short line;

	/* for now, until we have a token table */
	switch (tok)
	{
		case 0x80:  return "ABS";
		case 0x81:  return "ASC";
		case 0x82:  return "ATN";
		case 0x83:  return "CALL";
		case 0x84:  return "CDBL";
		case 0x85:	return "CHR$";
		case 0x86:	return "CINT";
		case 0x87:	return "CLOSE";
		case 0x88:	return "COMMON";
		case 0x89:  return "COS";
		case 0x8A:	return "CVD";
		case 0x8B:	return "CVI";
		case 0x8C:	return "CVS";
		case 0x8D:	return "DATA";
		case 0x8E:	return "ELSE";
		case 0x8F:	return "EOF";
		case 0x90:	return "EXP";
		case 0x91:	return "FIELD";
		case 0x92:	return "FIX";
		case 0x93:	return "FN";
		case 0x94:	return "FOR";
		case 0x95:	return "GET";
		case 0x96:	return "GOSUB";
		case 0x97:	return "GOTO";
		case 0x98:	return "IF";
		case 0x99:	return "INKEY$";
		case 0x9A:	return "INPUT";
		case 0x9B:	return "INT";
		case 0x9C:	return "LEFT$";
		case 0x9D:	return "LEN";
		case 0x9E:	return "LET";
		case 0x9F:	return "LINE";
		case 0xA0:	return "LOCK";
		case 0xA1:	return "LOC";
		case 0xA2:	return "LOF";
		case 0xA3:	return "LOG";
		case 0xA4:	return "LSET";
		case 0xA5:	return "MID$";
		case 0xA6:	return "MKD$";
		case 0xA7:	return "MKI$";
		case 0xA8:	return "MKS$";
		case 0xA9:	return "NEXT";
		case 0xAA:	return "ON";
		case 0xAB:	return "OPEN";
		case 0xAC:	return "PRINT";
		case 0xAD:	return "PUT";
		case 0xAE:	return "READ";
		case 0xAF:	return "REM";
		case 0xB0:	return "RETURN";
		case 0xB1:	return "RIGHT$";
		case 0xB2:	return "RND";
		case 0xB3:	return "RSET";
		case 0xB4:	return "SGN";
		case 0xB5:	return "SIN";
		case 0xB6:	return "SPACE$";
		case 0xB7:	return "SQR";
		case 0xB8:	return "STR$";
		case 0xB9:	return "STRING$";
		case 0xBA:	return "TAN";
		case 0xBB:	return "UNLOCK";
		case 0xBC:	return "VAL";
		case 0xBD:	return "WEND";
		case 0xBE:	return "WHILE";
		case 0xBF:	return "WRITE";
		case 0xE4:	return "USING";
		case 0xE5:	return "TO";
		case 0xE6:	return "THEN";
		case 0xE7:	return "NOT";
		case 0xE8:	return "'";
		case 0xE9:	return ">";
		case 0xEA:	return "=";
		case 0xEB:	return "<";
		case 0xEC:	return "+";
		case 0xED:	return "-";
		case 0xEE:	return "*";
		case 0xEF:	return "/";
		case 0xF0:	return "^";
		case 0xF1:	return "AND";
		case 0xF2:	return "OR";
		case 0xF3:	return "XOR";
		case 0xF4:	return "EQV";
		case 0xF5:	return "IMP";
		case 0xF6:	return "MOD";
		case 0xF7:	return "\\";
		case 0xF8:	
			switch ((tok = fgetc(fp))) {
				case 0x80:  return "AUTO";
				case 0x81:  return "CHAIN";
				case 0x82:  return "CLEAR";
				case 0x83:  return "CLS";
				case 0x84:  return "CONT";
				case 0x85:  return "CSNG";
				case 0x86:  return "DATE$";
				case 0x87:  return "DEFINT";
				case 0x88:  return "DEFSNG";
				case 0x89:  return "DEFDBL";
				case 0x8A:  return "DEFSTR";
				case 0x8B:  return "DEF";
				case 0x8C:	return "DELETE";
				case 0x8D:  return "DIM";
				case 0x8E:  return "EDIT";
				case 0x8F:  return "END";
				case 0x90:	return "ERASE";
				case 0x91:	return "ERL";
				case 0x92:  return "ERROR";
				case 0x93:	return "ERR";
				case 0x94:	return "FILES";
				case 0x95:  return "FRE";
				case 0x96:	return "HEX$";
				case 0x97:	return "INSTR";
				case 0x98:	return "KILL";
				case 0x99:  return "LIST";
				case 0x9A:  return "LLIST";
				case 0x9B:	return "LOAD";
				case 0x9C:	return "LPOS";
				case 0x9D:  return "LPRINT";
				case 0x9E:	return "MERGE";
				case 0x9F:	return "NAME";
				case 0xA0:	return "NEW";
				case 0xA1:	return "OCT$";
				case 0xA2:	return "OPTION";
				case 0xA3:	return "PEEK";
				case 0xA4:	return "POKE";
				case 0xA5:	return "POS";
				case 0xA6:	return "RANDOMIZE";
				case 0xA7:	return "RENUM";
				case 0xA8:	return "RESTORE";
				case 0xA9:	return "RESUME";
				case 0xAA:	return "RUN";
				case 0xAB:	return "SAVE";
				case 0xAC:	return "SHELL";
				case 0xAD:	return "STOP";
				case 0xAE:	return "SWAP";
				case 0xAF:	return "SYSTEM";
				case 0xB0:	return "TIME";
				case 0xB1:	return "TRON";
				case 0xB2:	return "TROFF";
				case 0xB3:	return "VARPTR";
				case 0xB4:	return "WIDTH";
				default:
					sprintf(rval, "[T:F8%x]", tok);
					break;
			}
			break;

		case 0xF9:
			switch ((tok = fgetc(fp))) {
				case 0xF5:	return "BREAK";
				case 0xF6:	return "WAIT";
				case 0xF7:	return "USR";
				case 0xF8:	return "TAB";
				case 0xF9:	return "STEP";
				case 0xFA:	return "SPC";
				case 0xFB:	return "OUTPUT";
				case 0xFC:	return "BASE";
				case 0xFD:	return "AS";
				case 0xFE:	return "APPEND";
				case 0xFF:	return "ALL";
				default:
					sprintf(rval, "[T:F9%x]", tok);
					break;
			}
			break;

		case 0xFA:
			switch ((tok = fgetc(fp))) {
				case 0x80:	return "MEM";
				case 0x81:	return "RANDOM";
				default:
					sprintf(rval, "[T:FA%x]", tok);
					break;
			}
			break;

		default:
			sprintf(rval, "[T:%x]", tok);
			break;
	}

	return rval;
}

do_list(fp)
	FILE *fp;
{
	int		c, b1, b2, b3, b4, b5, b6, b7, b8;
	unsigned short lineNr;

	c = fgetc(fp);	/* first byte of file is throwaway */
	if (EOF == c)
		return;
	for ( ; ; ) {
		/* first 3 bytes of a line are not used for listing */
		b1 = fgetc(fp);
		b2 = fgetc(fp);
		b3 = fgetc(fp);
		if (EOF == b1 || EOF == b2 || EOF == b3)
			return;

		/* but, if they're all zero, we're at the end */
		if (0 == b1 + b2 + b3)
			return;

		/* get the line number */
		c = fgetc(fp); if (EOF == c) return;
		lineNr = c << 8;
		c = fgetc(fp); if (EOF == c) return;
		lineNr |= c;
		printf("%d ", lineNr);
		while (EOF != (c = fgetc(fp))) {
			if (0 == c)
				break;	/* End of statement, parse the next */
			if (c > 127)
				printf("%s", token_lookup(c, fp));
			else if (c >= 0x11 && c <= 0x1B) {
				printf("%d", c - 0x11);
			}
			else if (c < ' ') {
				switch (c) {
					case 0x0E:	/* unsigned short? */
						c = fgetc(fp);
						c = fgetc(fp);
						if (EOF != c) {
							lineNr = c << 8;
							c = fgetc(fp);
							if (EOF != c) {
								lineNr |= c;
								printf("%u", lineNr);
							}
						}
						break;

					case 0x0F:	/* unsigned char? */
						c = fgetc(fp);
						if (EOF != c) 
						{
							unsigned char	num = c;
							printf("%u", num);
						}
						break;

					case 0x1C:	/* signed short? */
						b1 = fgetc(fp);
						b2 = fgetc(fp);
						if (EOF != b1 && EOF != b2) 
						{
							short num = (b1 << 8) | (b2 & 0xFF);
							printf("%d", num);
						}
						break;

					case 0x1D:	/* SNG? */
						b1 = fgetc(fp);
						b2 = fgetc(fp);
						b3 = fgetc(fp);
						b4 = fgetc(fp);
						if (EOF != b1 && EOF != b2 && EOF != b3 && EOF != b4)
						{
							/* Bytes are BCD */
								/* double instead of float because printf */
							double sng = 0;		
							sng = (b2 >> 4) / 10.0;
							sng += (b2 & 0x0F) / 100.0;
							sng += (b3 >> 4) / 1000.0;
							sng += (b3 & 0x0F) / 10000.0;
							sng += (b4 >> 4) / 100000.0;
							sng += (b4 & 0x0F) / 1000000.0;

							b1 -= 0x40;
							if (b1 > 0) {
								while (b1-- > 0)
									sng *= 10;
							}
							if (b1 < 0) {
								while (b1++ < 0)
									sng /= 10;
							}
							printf("%f", sng);
						}
						break;

					case 0x1F:	/* DBL? */
						b1 = fgetc(fp);
						b2 = fgetc(fp);
						b3 = fgetc(fp);
						b4 = fgetc(fp);
						b5 = fgetc(fp);
						b6 = fgetc(fp);
						b7 = fgetc(fp);
						b8 = fgetc(fp);
						if (EOF != b1 && EOF != b2 && EOF != b3 && EOF != b4
					       && EOF != b5 && EOF != b6 && EOF != b7 && EOF != b8)
						{
							double dbl = 0.0;
							float div = 10.0;

							/* Bytes are BCD */
							dbl = (b2 >> 4) / div; div *= 10;
							dbl += (b2 & 0x0F) / div; div *= 10;
							dbl += (b3 >> 4) / div; div *= 10;
							dbl += (b3 & 0x0F) / div; div *= 10;
							dbl += (b4 >> 4) / div; div *= 10;
							dbl += (b4 & 0x0F) / div; div *= 10;
							dbl += (b5 >> 4) / div; div *= 10;
							dbl += (b5 & 0x0F) / div; div *= 10;
							dbl += (b6 >> 4) / div; div *= 10;
							dbl += (b6 & 0x0F) / div; div *= 10;
							dbl += (b7 >> 4) / div; div *= 10;
							dbl += (b7 & 0x0F) / div; div *= 10;
							dbl += (b8 >> 4) / div; div *= 10;
							dbl += (b8 & 0x0F) / div;

							b1 -= 0x40;
							if (b1 > 0) {
								while (b1-- > 0)
									dbl *= 10;
							}
							if (b1 < 0) {
								while (b1++ < 0)
									dbl /= 10;
							}
								
							printf("%.12f", dbl);
						}
						break;

					default:
						printf("^%c", c + '@');
						break;
				}
			}
			else
				putchar(c);
		}
		putchar('\n');
	}
}
