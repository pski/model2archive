#include <stdio.h>

main(argc, argv)
	int	argc;
	char **argv;
{
	FILE	*fp;
	char	*myname;
	char	ltr;
	int		c;
	int		tokn;
	int		start;
	long	pos;

	myname = *argv++, --argc;

	fp = fopen("/usr/bin/b68k", "r");
	if (0 == fp) {
		fprintf(stderr, "%s: can't open ", myname);
		perror("b68k");
		exit(1);
	}

	pos = 0x434A; 
	if (0 != fseek(fp, pos, 0)) {
		fprintf(stderr, "%s: can't seek in ", myname);
		perror("b68k");
		fclose(fp);
		exit(1);
	}

	tokn = 0;
	start = 1;
	ltr = 'A';
	while (EOF != (c = getc(fp)) && ++pos < 0x45F8) {
		if (0 == c)
			++ltr;
		else if (c >= 0x80) {
			if (0 == tokn)
				printf("\t[T:");
			printf("%02x", c);
			tokn = 1;
		}
		else {
			if (1 == tokn) {
				putchar(']');
				putchar('\n');
				tokn = 0;
				start = 1;
			}
			if (1 == start) {
				if ('Z' >= ltr)
					putchar(ltr);
				start = 0;
			}

			if (c < ' ')
				printf("<%02x>", c);
			else
				putchar(c);
		}
	}
	if (1 == tokn)
		putchar(']');
	putchar('\n');

	fclose(fp);
	exit(0);
}
