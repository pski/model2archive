/*
  strtolower()

  1) Convert a string in place from upper case to lower case.
*/
#include <ctype.h>
int strtol( s )
char *s;
{
  while( *s )
    {
      if( isupper(*s) ) *s = tolower(*s);
      s++;
    }
}
