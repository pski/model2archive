/*
 * %W% %E% %U% ncoast!bsa %Z%
 * %Z% Copyright (C) 1986 by Brandon S. Allbery, All Rights Reserved %Z%
 */

#ifndef lint
static char _SccsId[] = "%W% %E% %U% ncoast!bsa %Z%";
static char _CopyRt[] = "%Z% Copyright (C) 1985 by Brandon S. Allbery %Z%";
#endif  lint

#include "ua.h"

bulletin(s)
    char *s;
    {
    short mcnt, himotd;
    char tmps[256];
    FILE *fp;

    if (user.u_access == A_MKUSER)
    	return;
    sprintf(tmps, "%s/himotd", MOTD);
    if ((fp = fopen(tmps, "r")) == NULL)
	{
	log("Error %d opening %s", errno, tmps);
	panic("himotd");
	}
    fgets(tmps, 32, fp);
    fclose(fp);
    himotd = atoi(tmps);
    for (mcnt = (strcmp(user.u_name, "guest") == 0? 0: user.u_nbull + 1); mcnt <= himotd; mcnt++)
	{
	sprintf(tmps, "%s/%d", MOTD, mcnt);
	if (!readmotd(tmps, mcnt))
	    break;
	}
    }

readmotd(motd, mnum)
    char *motd;
    short mnum;
    {
    char line[256];

    printf("Bulletin #%d:\n", mnum);
    cat(motd);
    printf("\n(C)ontinue or (S)top? ");
    if (!isatty(0) || nopause)
	{
	putchar('\n');
	line[0] = '\0';
	}
    else
	gets(line);
    log("C/S? %s", line);
    return ToLower(line[0]) != 's';
    }
