/*
 * %W% %E% %U% ncoast!bsa %Z%
 * %Z% Copyright (C) 1985 by Brandon S. Allbery, All Rights Reserved %Z%
 */

struct sys {
	char ua_home[50];	/* UNaXcess lives here */
	char ua_roc;	/* read-only conference flag */
	char ua_xrc;	/* x-rated conference flag */
	char ua_edit[50];	/* the default editor */
	char ua_shell[50];	/* the default shell */
	char ua_env;	/* read environment for SHELL, EDITOR */
	char ua_bbs[32];	/* name of BBS login */
	char ua_tlimit;	/* minutes until logout */
	char ua_sysop[32];	/* name of the sysop login */
	char ua_pm;	/* allow private messages? */
	char ua_log;	/* keep a log? */
	char ua_bnr[50];	/* path of banner file, EOS = internal */
	char ua_login[80];	/* login message, EOS = internal */
	char ua_hco;	/* hard-copy-output mode enable */
	char ua_nla;	/* number of attempts to login allowed */
	char ua_auc[80];	/* ascii upload command */
	char ua_adc[80];	/* ascii download command */
	char ua_xuc[80];	/* Xmodem upload command */
	char ua_xdc[80];	/* Xmodem download command */
	char ua_kuc[80];	/* Kermit upload command */
	char ua_kdc[80];	/* Kermit download command */
};

extern struct sys parms;
