/*
 * %W% %E% %U% ncoast!bsa %Z%
 * %Z% Copyright (C) 1986 by Brandon S. Allbery, All Rights Reserved %Z%
 */

#ifndef lint
static char _SccsId[] = "%W% %E% %U% ncoast!bsa %Z%";
static char _CopyRt[] = "%Z% Copyright (C) 1985 by Brandon S. Allbery %Z%";
#endif  lint

/* this version that execs "mkdir" by jpn 4/12/86 */
main(argc, argv)
int argc;
char **argv;
    {
    setuid(geteuid());
    umask(022);
    /* oops.  UNaXcess is passing two args - only the first is wanted */
    if (argc >= 3)
	argv[3] = 0;
    execvp("mkdir", argv);
    }

#if 0
/* I considered the original supplied version to be too dangerous and
** actually quite unnecessary.  This program just does a "mkdir", so
** the my version just exec's "mkdir"!
**
** I HATE having setuid to root programs on my system that were not supplied
** as part of the system!                 - jpn 4/12/86
*/
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/dir.h>

char line[256];

#ifdef SYS3
#define RIndex		strrchr
#else
#define RIndex		rindex
#endif SYS3

char *RIndex();

main(argc, argv)
    char **argv;
    {
    if (argc != 3)
	exit(1);
    mknod(argv[1], S_IFDIR|0755, 0);
    chown(argv[1], atoi(argv[2]), 50);
    sprintf(line, "%s/.", argv[1]);
    link(argv[1], line);
    *RIndex(argv[1], '/') = '\0';
    strcat(line, ".");
    link(argv[1], line);
    }
#endif
