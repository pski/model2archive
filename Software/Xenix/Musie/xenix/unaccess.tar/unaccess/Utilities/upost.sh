:
: "%W% %E% %U% ncoast!bsa %Z%"
: "%Z% Copyright (C) 1986 by Brandon S. Allbery, All Rights Reserved %Z%"
:

UADIR="`sed -n 's/^@UAOWNER@:[^:]*:[^:]*:[^:]*:[^:]*:\([^:]*\):[^:]*$/\1/p' < /etc/passwd`"

conf=$1; shift
msgnum=`cat $UADIR/msgdir/$conf/himsg`
case "$msgnum" in
[0-9]*)	;;
*)	echo "$msgnum" >&2
	exit 1
esac
msgnum=`expr $msgnum + 1`
if echo "Date: `@udate@`
From: Message Posting Daemon <${LOGNAME-daemon>
To: All
Subject: $*
" > $UADIR/msgdir/$conf/$msgnum 2>/dev/null
then	cat >> $UADIR/msgdir/$conf/$msgnum
	echo $msgnum > $UADIR/msgdir/$conf/himsg
else	echo "$0: could not make new message $msgnum in $conf"
	exit 1
fi
