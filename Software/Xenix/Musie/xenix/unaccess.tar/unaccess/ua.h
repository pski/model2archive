/*
 * %W% %E% %U% ncoast!bsa %Z%
 * %Z% Copyright (C) 1986 by Brandon S. Allbery, All Rights Reserved %Z%
 */

#include <stdio.h>
#include <ctype.h>
#include <setjmp.h>
#include <pwd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include "user.h"
#include "dir.h"
#include "sys.h"

#ifndef SIGUSR1
#define SIGUSR1		NSIG-1
#endif

#define SYSOP	parms.ua_sysop
#define LOG	"Logfile"
#define MOTD	"motd"
#define PASSWD	"userfile"
#define MSGBASE	"msgdir"
#define NEWMSGS	"userind"
#define NEWUSER	"NewMessage"
#define CONFIG	"ua-config"

extern jmp_buf cmdloop;			/* so intrp() works */
extern int logsig(), quit(), intrp(), thatsall();
extern int doread(), doscan();
extern struct _himsg *readhigh();
extern struct tm *localtime();
extern struct passwd *getpwuid();
extern char *getowner(), *visible(), *mktemp(), *crypt(), *date(), *longdate();
extern int errno, nopause;
extern char conference[];

#define ToLower(x) (isupper(x)?tolower(x):x)	/* not all tolower() work */
#define ToUpper(x) (islower(x)?toupper(x):x)	/* not all toupper() work */
#define uncntrl(x) (x+'@')			/* maybe a Burroughs or CDC? */

/*
#ifndef SYS3
#  define RIndex(s,c) rindex(s,c)
#  define Index(s,c) index(s,c)
extern char *rindex(), *index();
#else
#  define RIndex(s,c) strrchr(s, c)
#  define Index(s,c) strchr(s, c)
extern char *strrchr(), *strchr();
#endif
*/

#  define RIndex(s,c) strrchr(s, c)
#  define Index(s,c) strchr(s, c)
extern char *strrchr(), *strchr();

#ifdef BSD42
#define CONFSIZE	32
#else
#define CONFSIZE	14
#endif
