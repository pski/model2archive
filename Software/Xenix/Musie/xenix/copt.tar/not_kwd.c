static char rcsid[] = "$Header: not_kwd.c,v 1.1 89/03/03 12:53:25 np Exp $";
/* $Log:	not_kwd.c,v $
 * Revision 1.1  89/03/03  12:53:25  np
 * Initial revision
 * 
 */

/*
 * Copyright (C) 1985-1989 Nigel Perry
 *
 * This program is distributed without any warranty.
 * The author and and distributors accept no resposibility
 * to anyone for the consequence of using this program or
 * whether it serves any particular purpose or works at all,
 * unless they say so in writing.
 *
 * Everyone is granted permission to copy, modify and
 * redistribute this program, but only provided that:
 *
 * 1) They do so without financial or material gain.
 *
 * 2) The copyright notice and this notice are preserved on
 *    all copies.
 *
 * 3) The original source is preserved in any redistribution.
 *
 * I hope you find this program useful!
 *
 */

/* do execv if AS_ENVAR not set to AS_KWD
 * enables programs to switch the option format according to the environment setting
 */

#include "cset.h"

not_kwd(object, args) register char *object, **args;
{  register char *val;
   extern char *getenv();

   if( (val = getenv(AS_ENVAR)) == (char *)0 || strcmp(val, AS_KWD) != 0 )
      execv(object, args);
}
