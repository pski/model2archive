cbreak()
{
	return;
}

nocbreak()
{
	return;
}
