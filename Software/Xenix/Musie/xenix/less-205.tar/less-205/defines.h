/* defines.h.  Generated automatically by configure.  */
/* defines.h.in.  Generated automatically from configure.in by autoheader.  */
/* Unix definition file for less.  -*- C -*-
 *
 * This file has 3 sections:
 * User preferences.
 * Settings always true on Unix.
 * Settings automatically determined by configure.
 *
 * * * * * *  WARNING  * * * * * *
 * If you edit defines.h by hand, do "touch stamp-h" before you run make
 * so config.status doesn't overwrite your changes.
 */

/* User preferences.  */

/*
 * SHELL_ESCAPE is 1 if you wish to allow shell escapes.
 * (This is possible only if your system supplies the system() function.)
 */
#define	SHELL_ESCAPE	1

/*
 * TAB_COMPLETE_FILENAME is 1 if you wish to allow the TAB key
 * to complete filenames at prompts.
 */
#define	TAB_COMPLETE_FILENAME	1

/*
 * CMD_HISTORY is 1 if you wish to allow keys to cycle through
 * previous commands at prompts.
 */
#define	CMD_HISTORY	1

/*
 * EDITOR is 1 if you wish to allow editor invocation (the "v" command).
 * (This is possible only if your system supplies the system() function.)
 * EDIT_PGM is the name of the (default) editor to be invoked.
 */
#define	EDITOR		1
#define	EDIT_PGM	"vi"

/*
 * TAGS is 1 if you wish to support tag files.
 */
#define	TAGS		1

/*
 * USERFILE is 1 if you wish to allow a .less file to specify 
 * user-defined key bindings.
 */
#define	USERFILE	1

/*
 * GLOB is 1 if you wish to have shell metacharacters expanded in filenames.
 * This will generally work if your system provides the "popen" function
 * and the "echo" shell command.
 */
#define	GLOB		1

/*
 * PIPEC is 1 if you wish to have the "|" command
 * which allows the user to pipe data into a shell command.
 */
#define	PIPEC		1

/*
 * LOGFILE is 1 if you wish to allow the -l option (to create log files).
 */
#define	LOGFILE		1

/*
 * ONLY_RETURN is 1 if you want RETURN to be the only input which
 * will continue past an error message.
 * Otherwise, any key will continue past an error message.
 */
#define	ONLY_RETURN	0

/*
 * LESSKEYFILE is the filename of the default lesskey file 
 * (in the HOME directory).
 */
#define	LESSKEYFILE	".less"

/* Settings always true on Unix.  */

/*
 * Define MSOFTC if compiling under Microsoft C.
 */
#define	MSOFTC	0

/*
 * HAVE_SYS_TYPES_H is 1 if your system has <sys/types.h>.
 */
#define HAVE_SYS_TYPES_H	1

/*
 * HAVE_STAT is 1 if your system has the stat() call.
 */
#define	HAVE_STAT	1

/*
 * HAVE_PERROR is 1 if your system has the perror() call.
 * (Actually, if it has sys_errlist, sys_nerr and errno.)
 */
#define	HAVE_PERROR	1

/*
 * HAVE_TIME is 1 if your system has the time() call.
 */
#define	HAVE_TIME	1

/*
 * HAVE_SHELL is 1 if your system supports a SHELL command interpreter.
 */
#define	HAVE_SHELL	1

/* Settings automatically determined by configure.  */

/* Define to `long' if <sys/types.h> doesn't define.  */
/* #undef off_t */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define if you have the ANSI C header files.  */
/* #undef STDC_HEADERS */

/*
 * Regular expression library.
 * Define exactly one of the following to be 1:
 * HAVE_POSIX_REGCOMP: POSIX regcomp() and regex.h
 * HAVE_RE_COMP: BSD re_comp()
 * HAVE_REGCMP: System V regcmp()
 * HAVE_V8_REGCOMP: Henry Spencer V8 regcomp() and regexp.h
 * NO_REGEX: pattern matching is supported, but without metacharacters.
 */
/* #undef HAVE_POSIX_REGCOMP */
/* #undef HAVE_RE_COMP */
#define HAVE_REGCMP 1
/* #undef HAVE_V8_REGCOMP */
/* #undef NO_REGEX */

/* Define HAVE_VOID if your compiler supports the "void" type. */
/* #undef HAVE_VOID */

/* Define HAVE_STRERROR if you have the strerror() function. */
/* #undef HAVE_STRERROR */

/* Define HAVE_ERRNO if you have the errno variable */
#define HAVE_ERRNO 1

/* Define HAVE_SYS_ERRLIST if you have the sys_errlist[] variable */
#define HAVE_SYS_ERRLIST 1

/* Define if you have _setjmp.  */
/* #undef HAVE__SETJMP */

/* Define if you have memcpy.  */
#define HAVE_MEMCPY 1

/* Define if you have sigsetmask.  */
/* #undef HAVE_SIGSETMASK */

/* Define if you have system.  */
#define HAVE_SYSTEM 1

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the <stdio.h> header file.  */
#define HAVE_STDIO_H 1

/* Define if you have the <sys/ptem.h> header file.  */
#undef HAVE_SYS_PTEM_H

/* Define if you have the <sys/stream.h> header file.  */
#undef HAVE_SYS_STREAM_H

/* Define if you have the <termcap.h> header file.  */
/* #undef HAVE_TERMCAP_H */

/* Define if you have the <termio.h> header file.  */
/* Leave undefined for the Tandy 6000 so it uses sgtty.h */
#undef HAVE_TERMIO_H

/* Define if you have the <termios.h> header file.  */
#undef HAVE_TERMIOS_H

/* Define if you have the <time.h> header file.  */
#define HAVE_TIME_H 1

/* Define if you have the <unistd.h> header file.  */
/* #undef HAVE_UNISTD_H */
