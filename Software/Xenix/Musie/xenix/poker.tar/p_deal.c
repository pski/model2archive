/*-------------------------------------------*\
|  procedures to deal the cards               |
\*-------------------------------------------*/

#include "poker.h"

static playing_card  standard[DECK_SIZE];
                     /* a template of the unshuffled pack */

static playing_card  deck[DECK_SIZE];
static int  top_of_pack;
                     /* These are for the pack used to deal from */


long rand();


open_pack(packptr)

    playing_card *packptr; 

   /* This function initialises the deck of cards */
{

   int suit_count,face_count,card;

   for(suit_count=0;suit_count<4;suit_count++)

     for (face_count=1;face_count<14;face_count++)
     {

       card = (suit_count * 13) + face_count - 1;

       packptr[card].face_value= face_count;
       packptr[card].suit_value= suit_count;

       switch (face_count) {
	    case 1 : packptr[card].face = 'A';
		     break;
		     
	    case 10: packptr[card].face = 'T';
		     break;
		     
	    case 11: packptr[card].face = 'J';
		     break;
		     
	    case 12: packptr[card].face = 'Q';
		     break;
		     
	    case 13: packptr[card].face = 'K';
		     break;
		     
	    default: packptr[card].face = ('0' + face_count); 
		    
	    }
	
	switch (suit_count) {
	    case 0 : packptr[card].suit = 'H';
		     break;

	    case 1 : packptr[card].suit = 'C';
		     break;

	    case 2 : packptr[card].suit = 'S';
                     break;

	    case 3 : packptr[card].suit = 'D';

	    }
	
       }
   
} /* open_pack */



initialise_cards()

     /* create an unshuffled static pack */
{
   open_pack(standard);

}/*initialise_cards*/


new_deal()

   /* create a new pack, that can be manipulated	*/
{
   int count;

   for(count=0;count < DECK_SIZE;count++)
       deck[count] = standard[count];
   

}/* new_deal */
   


void swap(a,b)
     playing_card *a,*b;

/* swap two cards around */
{
     playing_card temp;

     temp = *a;
     *a = *b;
     *b = temp;

}/* swap */




shuffle_pack()


   /* This function will shuffle the deck that is used for manipulation	*/
{

   int count1,count2,swap_with;

/* The pack is shuffled 150 times. The higher this value the more random */
/* is the pack, but it is slower between deals */

   for (count1=0;count1<150;count1++) {
	  for (count2=0; count2<DECK_SIZE ;count2++) {
	       swap_with = rand()%DECK_SIZE;
	       swap(&deck[count2],&deck[swap_with]);
	  }
    }
} /* shuffle_pack */



void sort(hand)
     playing_card *hand;

/* Sort the hand of cards */
{
   int count1,count2,smallest;

   for (count1=0;count1 < HAND_SIZE -1;++count1)
   {
       smallest=count1;
       for (count2=(count1 + 1) ;count2 < HAND_SIZE;++count2)
	    if ((hand[count2].face_value < hand[smallest].face_value) ||
                ((hand[count2].face_value == hand[smallest].face_value) &&
                (hand[count2].suit < hand[smallest].suit)))

	       smallest = count2;

	if (smallest != count1)
	    swap ((hand + count1),(hand + smallest));

     }

}/* sort */




deal_two_hands(you,me)
	playing_card *you,*me;

{
    /* deal out hands to YOU & ME from deck , starting at top_of_pack */

    int count;

    shuffle_pack();
    top_of_pack = 0;

    for (count=0;count< HAND_SIZE; top_of_pack += 2, count++)
	{ you[count] = deck[top_of_pack];
	  me[count] = deck[top_of_pack + 1];
	}

     sort(you);
     sort(me);

} /* deal_two_hands */



void  re_deal(hand,needs)

      playing_card  *hand;
      describe   needs;

/* overwrite the cards that a player wants to change, by taking cards */
/* from top of deck */
{

  int count;

  for(count = 0;count<needs.reject;count++)
     hand[needs.exchange[count]] = deck[top_of_pack++];

  sort(hand);

  
}/* re-deal */
