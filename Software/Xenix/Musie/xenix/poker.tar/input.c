/*--------------------------------------------*\
|   These procedures handle the majority of    |
|  input from the user.                        |
\*--------------------------------------------*/
#include "poker.h"


void  get_input(des,val)
      int des;
      char *val;

/*---------------------------------------------*\
|    get a byte from the input descriptor       |
\*---------------------------------------------*/
{

   do
   {
     while(read(des,val,1) != 1);      /* Wait for a key press */

     if(*val == '\022')
	 redraw_screen();

     if(*val == 'F')                   /*  quitting  */
	 really();
    }
    while (*val == '\022' );

}/* get i/p  */



get_SDB(source,choice)
      int   source;
      char  *choice;

/*-----------------------------------------------*\
|  Get a choice of Stay, Drop or Bet from user    |
\*-----------------------------------------------*/
{
   do
      get_input(source,choice);
   while(*choice != 's' &&
	 *choice != 'd' &&
	 *choice != 'b');

}/* get SDB */




get_RCD(source,choice,turn)
      int   source;
      char  *choice;
      int   turn;

/*-----------------------------------------------*\
|  Get a choice of Raise, Drop or Call from user  |
\*-----------------------------------------------*/
{
   do
      get_input(source,choice);
   while((*choice != 'r' && turn != 6) &&
	 *choice != 'd' &&
	 *choice != 'c');

}/* get RCD */



get_increment(source,amount)
      int  source;
      int  *amount;

/*--------------------------------------------------*\
|  Get the user's bet, or raise from a single key    |
| press, using multiles of five, for the bets.       |
\*--------------------------------------------------*/
{
   char amt;

   do
     get_input(source,&amt);
   while (amt < '1' || amt > '5');

   *amount = ((int)(amt - '0' ) * 5);

}


get_user_changes(source,reject,exchange)

       int    source;
       int    *reject;
       int    *exchange;

/*--------------------------------------------------*\
|   Get a maximum of Three cards to be rejected by   |
|  the user.                                         |
\*--------------------------------------------------*/

{
       int  no_of_cards,complete,count,ok,value;
       char choice;

       ask_which();

       no_of_cards = 0;
       complete = 0;
       choice = ' ';

       do
       {
	   do
	     get_input(source,&choice);
	   while ((choice < '1' || choice > '5') && 
		   choice != '\n' && choice != '\b' && choice != '\177');
	      
		switch (choice) {

		case '\n' :  complete = 1;
                             *reject = no_of_cards;
			     break;
		case '\b' :  case '\177' :
			     delete_line();
		             no_of_cards = 0;
			     break;
		default : if(no_of_cards < 3)
			    {
			      value = choice - '1';
			      ok = 1;
			      for(count=0;count<no_of_cards;count++)
				if(value == exchange[count])
				     ok = 0;

			      if(ok)
				 {
			         show_choice(choice,no_of_cards);
			         exchange[no_of_cards++] = value;
				 }
			    }

		}/* switch */

       }
       while(!complete);


}/*get_users_changes*/
