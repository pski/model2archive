/*----------------------------------------------------*\
|   These procedures make all the strategy decisions.  |
\*----------------------------------------------------*/

#include "poker.h" 

long rand();

/*--------------------------------------------------*\
|   This next array determines the strategy, and     |
|  ability of the game.                              |
|   The values are probabilities relating to the     |
|  different decisions the game makes.               |
|   The first 5 values, relate to how often a Call   |
|  is made.                                          |
|   The next 10 affect the how often the machine     |
|  drops its cards.                                  |
|   The remainder are concerned with Calling.        |
\*--------------------------------------------------*/

static int percent[18] = {92,92,92,100,70,                   /*  STAY  */
			  67,80,90,88,97,50,85,85,50,85,     /*  DROP  */
			  90,85,70};                         /*  CALL  */



int  decision_A(first_deal)

{
     /*  decide between hi pair or 4 flush   */
     /*  with a 70:30 bias to a pair         */

   if(!first_deal)
       return  11;

   else
   
      return  ((rand()%100 < 30) ? 10:11);

}/*  decision A */




int  decision_B()

{
     /* decide between using 3 card straight flush  or 3 high cards */
     /* with a bias of 60:40 for 3 high cards  */


     return  ((rand()%100 < 40) ? 7:6);

}/*  decision B */




int  decision_C()

{
    /* decide whether to use 2 high cards or 3 card flush */
    /* there is a bias of 70:30 for 2 high cards   */


    return  ((rand()%100 < 30) ? 3:4);

}/* decision C */




int  decision_D()

{
    /* decide between 3 card run and 1 high card */
    /* there is a bias of 70:30 for 1 high cards   */


    return  ((rand()%100 < 30) ? 2:1);

}/* decision D */




int  stay (Hv,last_act,deal,winnings)
     int  Hv,last_act,deal,winnings;

{
  /*******************************************************\
  |*   Do I stay ?                                       *|
  |*                               			 *|
  |* Only if Hv (Handvalue) == 0 and 			 *|
  |*if last_act == 1 or 0 (i.e last was a stay, or 	 *|
  |*you go first). 					 *|
  |*                               			 *|
  |* Which deal also determines staying, as on first deal*|
  |*there is room for improvement			 *|
  |*                               			 *|
  \*******************************************************/


   int result;

   result = 0;  /* don't stay */

   switch (deal) {
   case 1 : /* first deal */
            if(Hv < 13 && Hv != 11 && Hv != 8)
	       /* i.e nothing in hand */
	      {
	        if(last_act == 0) /* I go first */
		   result = (rand()%100 < percent[0]);

	        if(last_act == 1) /* opponent stayed */
		    result = (rand()%100) < percent[1];

	      }
	    break;

   case 0 : /* second deal */
            if(Hv < 13 && Hv != 11 && Hv != 8)
	       /* i.e nothing in hand */
	      {
	        if(last_act == 0) /* I go first */
		   result = (rand()%100 < percent[2]);

	        if(last_act == 1) /* opponent stayed */
		  if(winnings >=0 )
		     result = (rand()%100 < percent[3]);

	      }
	     else /* some thing in hand */

	       if(Hv < 13) /* only consider if < 2 pair */
	       {
	        if(last_act == 0) /* I go first */
		   result = (rand()%100 < percent[4]);

	       };
	    break;
    }/* switch */


    return result;

} /* stay */



int  drop(deal,cards_taken,Hv,last_act,winnings,turn)
     int  deal,Hv;
     int  cards_taken,last_act;
     int  winnings,turn;

{
  /**********************************************\
  |*  Do i drop my cards ?			*|
  |*						*|
  |*  Only consider if nothing in hand and last *|
  |*action was increase. Number of cards taken  *|
  |*by opponent, if second deal, is important.	*|
  |* If presently losing money, then be more	*|
  |*cautious, and drop more often.		*|
  |*						*|
  |*   Follow through with a bluff, so never    *|
  |* drop if have previously bet. 		*|
  |*						*|
  \**********************************************/

  int  result;

  result = 0; /* do not drop */

  if(last_act < 9)  
          /*  If the last action was a raise, i.e. >= 9, then I must have*/
	  /* previously bet, so it is important to carry the bet on      */
	  /* and not go back on a bluff.				 */
	  /*  Otherwise, I have added no money to the pot, and can 	 */
	  /* consider dropping.						 */

  switch (deal) {

  case 1 : /* first deal */

            if(Hv < 13 && Hv != 11 && Hv != 8)
	       /* i.e nothing in hand */
              {
                if(last_act ==0) /* go first */
		    if(winnings >= 0)
			result = (rand()%100) < percent[5];
		    else
			result = (rand()%100) < percent[6];
		
		if(last_act > 3) /* opponent bet */
		    if(winnings < 0)
			result = (rand()%100) < percent[7];
		    else
			result = (rand()%100) < percent[8];
	       }
	    
	    break;
	    
  case 0 : /* second deal */

            if(Hv < 13 && Hv != 11 && Hv != 8)
	       /* i.e nothing in hand */

              {
	       if(last_act == 0) /* go first */

	           if(cards_taken == 0) /* opponent took no cards */
			result = (rand()%100) < percent[9];
		    else
		      if(winnings >=0 )
			  result = (rand()%100) < percent[10];
		      else
			  result = (rand()%100) < percent[11];

	      if(last_act > 3)
		 if(winnings <0)
		    result = (rand()%100) < percent[12];
		    else
	               result = (rand()%100 < percent[13]);
              }

             else /* have some thing */
	       if(cards_taken == 0 && Hv <15 )
		  result = (rand()%100 < percent[14]);
   }
		  
    return result;

}/* drop */



int  calling(Hv,turn,first_deal,cards_taken)
     int Hv,turn,cards_taken,first_deal;

{
   /*****************************************************\
   |* calling is determined by hand value and pot       *|
   |* on turn 6 of the betting the only options will be *|
   |* drop or call, so automatically call on 6          *|
   \*****************************************************/

   int action;


   action =0;  /* do not call */

   if (turn == 6)
      action = 1;

    else
    {
        if(Hv < 13 && Hv != 11 && Hv != 8)
	       /* i.e nothing in hand */

	  action = (rand()%100 < percent[15]); /* nearly always call */
	else
	   if(Hv < 13)  /*  less than 2 pair */
	      if(!first_deal && cards_taken == 0)
                 action = (rand()%100 < percent[16]);  /* likely to call */
		else
	           action = (rand()%100 < percent[17]);
     }

     return action;

}/* calling */



int   increase(Hv,first_deal,cards_taken)
      int Hv,first_deal,cards_taken;


    /**************************************************\
    |*  increase current bet by one of three amounts  *|
    |*   Small , Medium , Large .                     *|
    |*						      *|
    |*  returned amounts are :-			      *|
    |*						      *|
    |*   1 - 5 , corresponding to bets of             *|
    |*   5,10,15,20,25  respectively		      *|
    |*						      *|
    \**************************************************/

{
    int  amount;


    switch (Hv) {

    case 20 : case 19 : case 18 : case 17 : case 16 :  /* all 5 cards */
	      if( rand()%100 < 75) /* 75% of the time */
	          amount = 1 + (rand()%3); /* 1,2 or 3 */
	      else
		  amount = 4 + (rand()&01);  /*  4 or 5 */

	      break;

    case 15 : case 14 : case 13 :  /*  more than a hi pair  */
	      if( rand()%100 < 75) /* 75% of the time */
	          amount = 1 + (rand()%3); /* 1,2 or 3 */
	      else
		  amount = 4 + (rand()&01);  /*  4 or 5 */

	      break;

    case 8 :    /*  lo pair */
	      if (first_deal)
		{
                 if( rand()%100 < 75) /* 75% of the time */
		     amount = 1 + (rand()&01);  /*  1 or 2 */
	         else
		     amount = 3;
		}
	       else  /* second_deal */
		{
		   if(cards_taken ==0 )
		     {
	              if( rand()%100 < 75) /* 75% of the time */
			  amount = 1;
			else
			   amount = 2;
		     }
		   else  /*  some cards taken */
		      {
	              if( rand()%100 < 75) /* 75% of the time */
			  amount = 1 + (rand()&01);  /* 1 or 2 */
			else
			   amount = 3;
		      }
		 }

	      break;

    case 11 :    /*  hi pair */
	      if (first_deal)
		 {
	         if( rand()%100 < 75) /* 75% of the time */
		     amount = 1 + (rand()&01);  /*  1 or 2 */
	         else
		     amount = 3;
		 }

	       else  /* second_deal */
		  {
		   if(cards_taken ==0 )
		     {
	              if( rand()%100 < 75) /* 75% of the time */
			  amount = 1 + (rand()&01);
			else
			   amount = 3;
		      }
		   else  /*  some cards taken */
		      {
	              if( rand()%100 < 75) /* 75% of the time */
			  amount = 1 + (rand()%3);  /* 1,2 or 3 */
			else
			   amount = 4 + (rand()&01);  /* 4 or 5 */
		      }
		   }

	      break;

    default : /*  nothing in hand */
	      amount = 1 + (rand()%5); /* 1 to 5 */
	      break;
    }/* switch */


    return amount;

}/* increase bet */


