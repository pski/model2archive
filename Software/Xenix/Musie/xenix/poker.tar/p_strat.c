
#include "poker.h"

/****************************************/
/*  p_strat.c  strategies               */
/* Determine what is in the hand, and   */
/* make the appropriate strategy        */
/* decisions.                           */
/****************************************/
/* 					*/
/*  Hand value :-			*/
/*  					*/
/*  20    :     Royal Flush.		*/
/*  19    :     Straight Flush 		*/
/*  18	  :     4 of a Kind		*/
/*  17	  :	Full House		*/
/*  16    :	Flush			*/
/*  15    :	Straight		*/
/*  14	  :	3 of a Kind		*/
/*  13	  : 	2 pair			*/
/*  12    :     4 card straight flush	*/
/* {11    :     high pair		*/
/* {10	  : 	4 card flush		*/
/*   9	  :	4 card straight		*/
/*   8    :	low pair		*/
/*  {7    :     3 card straight flush	*/
/*  {6	  :	3 high card		*/
/*   5    :     inside straight`	*/
/*  {4	  :	2 high cards		*/
/*  {3	  :	3 card flush		*/
/*  					*/
/*  {2	  :	3 card run		*/
/*  {1	  :     1 high card		*/
/*					*/
/*  a high card is >= 10		*/
/*					*/
/****************************************/

/* These are the procedures that categorise the hand */

flush  flusher();
prile  pairs();
run    runs();
high   high_cards();



prile     priles;
run       straight;
flush     flushes;
high      top_cards;
describe  res;

int  hi_straight;



int  strai_flush (stra,flus,length)
      int  *stra,*flus,length;

/* If there is a run present, and a flush present, this decides whether */
/* or not the same cards are involved in both, i.e. a straight flush    */
{
    int count;
    int truth;


    truth=1;

    for(count=0;count < length;count++)
       if(stra[count] != flus[count])
	   truth = 0;

    return truth;

}/* strai_flush */





void  improve(keep,throw,numkept)
      int  *keep,*throw;
      int  numkept;

/* given the cards used in a hand, locate those that need to be changed */

{
   int card_count,keep_count,throw_count;
   int keeping;

   throw_count = 0;
   for(card_count = 0;card_count < HAND_SIZE;card_count++)
      {
	keeping = 0;
	for(keep_count = 0;keep_count < numkept;keep_count++)
	   if(keep[keep_count] == card_count)
	      keeping =1;

	if(!keeping)
	   throw[throw_count++] = card_count;
      }


}/* improve */




int   real_straight(hand)

      playing_card  *hand;

      /*  the straight algorithm is often wrong if there is a pair present  */
      /*  This one makes certain */

{
     int  real;
     int  counter,ptr;

     real = 1;
     counter =0;
     ptr=straight.card[0] ; /*  first card of straight */


     if(hand[ptr].face_value == 1 &&
	hand[HAND_SIZE - 1].face_value == 13)  /* ace and king present */

	ptr = straight.card[++counter]; /* look at next card */

     do
     {
	if(hand[ptr].face_value >= hand[ptr+1].face_value)
	   real = 0;
	
	ptr++;
	counter++;
     }
     while(counter < straight.length - 1);

     return real;


}/* real_straight */


	    

void handle_prile(hand,deal)

     playing_card  *hand;
     int   deal;

/* This decides what to do with a hand, given that a pair is present */

{
     switch (priles.p_type) {

     /* Four of a kind */
     case 256 : res.hand_value = 18;
		if(hand[priles.cards[0]].face_value < 10)
		   {
		     res.reject = 1;
		     improve(priles.cards,res.exchange,4);
		   }
		 else
		   res.reject = 0;
		break;

      /* Full house */
      case 32 :	case 64 : res.hand_value = 17;
			  res.reject = 0;
			  break;

      /* Three of a kind */
      case 16 :	res.hand_value = 14;
		res.reject = 2;
		improve(priles.cards,res.exchange,3);
		break;

      /* Two pair */
      case 8  : res.hand_value = 13;
		res.reject = 1;
		improve(priles.cards,res.exchange,4);
		break;

      /* One pair */
      case 4  : if(flushes.flush_of == 4 &&

		   deal && /* only continue if first deal */

		   !straight.open_str    &&
		   straight.length == 4  &&
		   real_straight(hand) )

		       /* is there also a 4 straight_flush ? */
		       /* if so it is a better hand to improve */
		       /* on first deal than any pair */
		
		     {
		      res.hand_value=12;
		      res.reject = 1;
		      improve(flushes.cards,res.exchange,4);
		     }
		else /* no 4 sra_flush */
		 {
                   if(hand[priles.cards[0]].face_value < 10 &&
                      hand[priles.cards[0]].face_value > 1 )

		     {/* have a low pair but others are better if still */
		      /* improving hand.*/

              		if(flushes.flush_of == 4 && deal)
			  {
			    res.hand_value = 10;
			    res.reject = 1;
			    improve(flushes.cards,res.exchange,4);
			  }
			else
			  {
			    if(straight.length == 4 &&
			       deal &&
			       !straight.open_str   &&
			       real_straight(hand))

			       {
				 res.hand_value = 9;
				 res.reject = 1;
				 improve(straight.card,res.exchange,4);
			       }
			     else /* only a low pair */
			       {
				 res.hand_value = 8;
				 res.reject = 3;
				 improve(priles.cards,res.exchange,2);
			       }
			  }

			 
		     }
		  else /* hi pair */
		     {
		     if(flushes.flush_of == 4)
		      {
		        res.hand_value = decision_A(deal);
		        if(res.hand_value == 11)
			{
			  res.reject = 3;
			  improve(priles.cards,res.exchange,2);
			}
		       else /* is 10 */
			{
			  res.reject = 1;
			  improve(flushes.cards,res.exchange,4);
			}
		      }
		     else /* only a high pair */
		      {
			res.hand_value = 11;
		        res.reject = 3;
		        improve(priles.cards,res.exchange,2);
		      }
		  
		    }
		}
     
     }/*switch*/


}/* prile */



void  handle_no_prile(hand,first_deal)
     playing_card *hand;
     int  first_deal;

{
    if(hi_straight)
	if(flushes.flush_of == 5)
         {
	   if(hand[0].suit == 'H')  /* Royal flush */
	     {
	       res.hand_value = 20;
	       res.reject = 0;
	     }
	   else /* just hi_straight */
	     {
	       res.hand_value = 19;
	       res.reject = 0;
	     }
	 }
	else /* just hi straight */
	 {
	   res.hand_value = 15;
	   res.reject = 0;
	 }
     else
	if(flushes.flush_of == 5)
	  {
	   res.hand_value = 16;
	   res.reject = 0;
	  }
	 else
	  
	  /* all hands that could win with no pairs  	*/
	  /* have been found at this point, the 	*/
	  /* following is only needed if improvements	*/
	  /* can be made, so only do on second deal.	*/

	  if(first_deal)
	   {

	     if(flushes.flush_of == straight.length &&
		strai_flush(flushes.cards,straight.card,straight.length))

		switch (straight.length) 
		{
		  case 4 : res.hand_value = 12;
			   res.reject = 1;
			   improve(flushes.cards,res.exchange,4);
			   break;
		  case 3 : if(top_cards.number == 3) /* 3 hi cards */
			     {
			       res.hand_value = decision_B();
			       res.reject = 2;
			       if(res.hand_value == 7) /* 3 str flush */
				   improve(flushes.cards,res.exchange,3);
				else
				   improve(top_cards.cards,res.exchange,3);
			     }
			     else /* just 3 str flush */
			       {
				 res.hand_value = 7;
			         res.reject = 2;
				 improve(flushes.cards,res.exchange,3);
			       }/* end case 3 */

		}/* end switch */

                else   /* no straight flushes present */
		 if(flushes.flush_of==4)
		   {
		      res.hand_value = 10;
		      res.reject = 1;
		      improve(flushes.cards,res.exchange,4);
		   } 
		   else
		    if(straight.length == 4 && !straight.open_str)
		     {
		        res.hand_value = 9;
		        res.reject = 1;
		        improve(straight.card,res.exchange,4);
		     }
		     else
		      if(top_cards.number == 3)
		       {
			res.hand_value = 6;
			res.reject = 2;
			improve(top_cards.cards,res.exchange,3);
		       }
		       else
			if(straight.open_str)
			 {
			  res.hand_value = 5;
			  res.reject = 1;
			  improve(straight.card,res.exchange,4);
			 }
			 else
			  if(top_cards.number == 2)
			   {
			    if(flushes.flush_of == 3)
			      {
				res.hand_value = decision_C();
				res.reject = ((res.hand_value == 4)?3:2);
				improve((res.hand_value == 4)?top_cards.cards:
							      flushes.cards,
					 res.exchange,
					 (HAND_SIZE - res.reject));
			      }
			      else /* just 2 hi cards */
			       {
				res.hand_value = 4;
				res.reject = 3;
				improve(top_cards.cards,res.exchange,2);
			       }
			    }/* end 2 hi cards */
			    else
			    if(flushes.flush_of == 3)
			     {
			      res.hand_value = 3;
			      res.reject = 2;
			      improve(flushes.cards,res.exchange,3);
			     }
			     else
			      if(straight.length == 3)
			      {
			       if(top_cards.number == 1)
				{
				 res.hand_value=decision_D();
				 res.reject=((res.hand_value == 2)?2:3);
				 improve((res.hand_value == 2)?straight.card:
							       top_cards.cards,
					 res.exchange,
					 (HAND_SIZE - res.reject));
				}
				else
				 {
				  res.hand_value=2;
				  res.reject=2;
				  improve(straight.card,res.exchange,3);
				 }
			       }
			       else
				if(top_cards.number == 1)
				  { /* only 1 high card */
				    res.hand_value = 1;
				    res.reject = 3;
				    improve(top_cards.cards,res.exchange,2);
                                   }
				else
				 { /* nothing */
				   res.hand_value = 0;
				   res.reject = 3;
				   improve(top_cards.cards,res.exchange,2);
				 }
				 
	    }/*  first_deal check */


}/* no prile */




describe  evaluate(hand,first_deal)
          playing_card  *hand;
          int  first_deal;

/* The hand evaluation routine */

{
                      /* First find what is in the hand  */

  flushes = flusher(hand);

  hi_straight = high_straight(hand);

  priles = pairs(hand);

  if(first_deal && !hi_straight) 
		              /* not needed second deal, as can not        */
		              /* improve any more or if hi straight found  */
    if(priles.p_type <= 4)

       straight = runs(hand,(priles.p_type == 4),priles.cards[0]);

  top_cards = high_cards(hand);

  res.hand_value = 0;
  res.reject = 0;



  if (priles.p_type > 2) 

       handle_prile(hand,first_deal);

    else 

       handle_no_prile(hand,first_deal);

  if(!first_deal)  /* on 2nd deal all other Hv's are irrelevant */

      if(res.hand_value <13 && res.hand_value != 11 && res.hand_value !=8)

	  res.hand_value = 0;


  return res;

}/* absolute */




int  det_winner(my_val,opp_val,my_hand,your_hand)
      int           my_val,opp_val;
      playing_card  *my_hand, *your_hand;

/* determine the winner, particularly when the hand values are the same */

{
     int  winner;
     int  my_hi,your_hi,my_lo,your_lo,count;

     winner = -1;
     
     if(my_val != opp_val)
	  winner = (my_val > opp_val);
	
	else
	  switch (my_val) { /*  are equal  */

	  case 19 : case 15 : /* straights */
	       if(my_hand[HAND_SIZE - 1].face_value ==
	          your_hand[HAND_SIZE - 1].face_value) /* hi cards equal */
			{
			  if(my_hand[HAND_SIZE - 1].face_value == 13)
			     if(my_hand[0].face_value !=
				your_hand[0].face_value)

				/* are the runs 9TKQK or ATJQK */

                              {
				if(my_hand[0].face_value == 1)
				   winner = 1; /* i have AKQJT */

				if(your_hand[0].face_value == 1)
				   winner = 0; /* you have AKQJT */
			      }
			 }
		  else
				
		    winner = my_hand[HAND_SIZE - 1].face_value >
			     your_hand[HAND_SIZE - 1].face_value;
		break;
	  case 18 : case 14 : case 17 :
			 /*  compare third cards of hands */
			 /* full houses determined by the 3ok present */

		    if(my_hand[2].face_value == 1)
			 winner = 1; /* me */
		      else
			  if(your_hand[2].face_value == 1)
			      winner = 0; /* you */
			else
			   winner = (my_hand[2].face_value >
				     your_hand[2].face_value);
		     break;

          case 13 : /* 2 pair */
		    /* re-evaluate the pairs present */
		    
		    priles = pairs(my_hand);
		    my_hi = my_hand[priles.cards[2]].face_value;
		    my_lo = my_hand[priles.cards[0]].face_value;
		    if(my_lo == 1) /* aces */
			{
			my_lo = my_hi;
			my_hi = 14;/* ace == 14 */
			}

		    priles = pairs(your_hand);
		    your_hi = your_hand[priles.cards[2]].face_value;
		    your_lo = your_hand[priles.cards[0]].face_value;
		    if(your_lo == 1) /* aces */
			{
			your_lo = your_hi;
			your_hi = 14;
			}

                    if (my_hi != your_hi)
			winner = (my_hi > your_hi);
		      else
			 if(my_lo != your_lo)
			    winner = (my_lo > your_lo);

		         else  /* 2 pairs the same */
			       /*  compare hi cards */
    
			   for(count=HAND_SIZE -1;(count >= 0 && winner == -1);
			       count ++)

			     if(my_hand[count].face_value != 
				your_hand[count].face_value)
			        winner = (my_hand[count].face_value > 
					  your_hand[count].face_value);

		    break;

            case 11 : case 8 : /* pairs */

		    /* First get the value of the pair */

		    priles = pairs(my_hand);
		    my_hi = my_hand[priles.cards[0]].face_value;

		    priles = pairs(your_hand);
		    your_hi = your_hand[priles.cards[0]].face_value;

		    my_hi += (13 * (my_hi == 1));
		    your_hi += (13 * (your_hi == 1));
		      /*  aces become 14 */

		    if(my_hi != your_hi)
		       winner = (my_hi > your_hi);

		     else  /* pairs the same */
			   /*  compare hi cards */

			   for(count=HAND_SIZE -1;(count >= 0 && winner == -1);
			       count ++)

			     if(my_hand[count].face_value != 
				your_hand[count].face_value)

			        winner = (my_hand[count].face_value >
					  your_hand[count].face_value);

                    break;

           default :
		    if(my_hand[0].face_value != your_hand[0].face_value)
		       /*  check for aces */
		      if(my_hand[0].face_value == 1)
			 winner = 1; /* i have ace */
			else
			   if(your_hand[0].face_value == 1)
			      winner = 0; /* you have ace */

		    if(winner == -1)

		    for(count=HAND_SIZE -1 ; count >= 0;count--)
		       if (my_hand[count].face_value != 
			    your_hand[count].face_value)
			     
			     {
			      winner = (my_hand[count].face_value >
			                your_hand[count].face_value) ;
			      break; /* from for loop */
			     }
					

	  }/* switch */


    return winner;

}/* det_winner  */
