/*--------------------------------------------------*\
|   These procedures determine what is in the hand,  |
|  or could be made out of the hand.                 |
\*--------------------------------------------------*/
#include "poker.h"



flush  flusher(hand)
      playing_card *hand;

/*------------------------------------------------*\
|     Identify the existence of a (partial)flush,  |
|   and record the cards involved.                 |
\*------------------------------------------------*/
{
   flush  result;

   int count1,count2,x_posn;
   int suit_matrix[4][HAND_SIZE + 1];

/*| suit_matrix holds the no. of cards in each suit |*/

   result.flush_of = 0;

 /* clear suit_matrix */

   for(count1=0;count1<4;count1++)
       suit_matrix[count1][0] = 0;

/* fill in suit_matrix */

   for(count1=0;count1 < HAND_SIZE;count1++)
      {
	x_posn = hand[count1].suit_value;

	suit_matrix[x_posn][(++suit_matrix[x_posn][0])] = count1;

      }

   for(count1=0;count1<4;count1++)

	if((result.flush_of = suit_matrix[count1][0]) >= 3)
	  {
	    for(count2=1;count2 <= result.flush_of; count2++)
	       result.cards[count2 - 1] = suit_matrix[count1][count2];

	    break;
	   }

    return result;

}/* flusher */



int  high_straight(hand)
     playing_card  *hand;

/*------------------------------------------------*\
|* Identify the existence of a five card straight *|
\*------------------------------------------------*/
{

    int have,ace;
    int total,mean,count;

    total=0;
    ace=0;

    ace = (hand[0].face_value == 1);

    for(count=0;count<HAND_SIZE;count++)
	 total += hand[count].face_value;

    mean = total/HAND_SIZE;

    have=1;

    if(!(total == 47 &&  ace)) /* i.e not AKQJT */
      for (count=0;count<HAND_SIZE;count++)
	 if (hand[count].face_value > (mean + 2)  ||
	     hand[count].face_value < (mean - 2))

	     have =0;

    return have;

}/* high straight */



prile  pairs(hand)
      playing_card  *hand;

/*---------------------------------------*\
|* find any pairs, or groupings of pairs *|
\*---------------------------------------*/
{
   int count,card_count,res,card;
   int check[13];
   prile  result;


   for(count=0;count<13;count++)
      check[count] = 0;  /*  clear check  */

   res = 2;
   result.no_of_cards = 0;

   check[hand[0].face_value - 1] = 2;

   for(count=1;count<HAND_SIZE;count++)
      {
	card = hand[count].face_value - 1;
	if (check[card] >= 2)
	  {
	    res *= check[card];
	    check[card] = res;
	  }
	  else
	    check[card] = 2;
       }

    result.p_type  = res;
    if (res > 2)
       {
	 card_count = 0;
	 for(count =0;count<HAND_SIZE;count++)
	   if(check[hand[count].face_value - 1] > 2)
	      result.cards[card_count++] = count;
       }


    return result;
}/* pairs  */



run   runs(in_hand,pair,posn)
     playing_card  *in_hand;
     int  pair;
     int  posn;

/*----------------------------------------------------------*\
|  Identify any partial runs, of length >= 3                 |
|  It uses a sliding window, of varying size, to isolate     |
|  any runs, then does specific checks at the end for open   |
|  runs, such as 34_67                                       |
\*----------------------------------------------------------*/

{
   playing_card  hand[HAND_SIZE];

   int  start,window,sum,mean;
   int  remove,compare,limit;
   int  straight,count;
   int  diff,begin;

   run  result;


   for(count=0;count<HAND_SIZE;count++)

     /*  move in_hand to hand making a copy */
     /* so as not to corrupt hand           */

	 hand[count] = in_hand[count];

	
   start = 0;
   window = 3;

   result.length = 0;
   result.open_str = 0;
   begin = 0;

   if (pair)                                    /* if a pair is present */
     {
       if(posn == 0)           /* check if card is first in hand */
		               /* then find a card to compare suits with */
	   compare = 2;
	else
	   compare = posn - 1;
       
                                       /* preserve any straight flushes */

       if(hand[posn].suit == hand[compare].suit)
	    remove = posn + 1;
	else
	    remove = posn;
       
                                  /* shift chosen card to right of hand */

       for(count=remove+1;count < HAND_SIZE;count++)
	   swap((hand + count -1),(hand+count));
     }
   
   limit = HAND_SIZE - pair;  /* 4 or 5 */
          /* limit is the number of cards, in the possibly altered hand */

   do
   {
	  sum =0;
	  for (count = start;count < (start +  window);count++)
	      sum += hand[count].face_value;
	  
	  mean = sum/window;

	  straight = 1;  /* disprove that a straight is present */
	  diff = window/2;

	  for(count = start;(count < (start + window) && straight );count++)
	      
	      straight = !(hand[count].face_value < mean - diff  ||
		           hand[count].face_value > mean + diff);
		         /* i.e is there a  run present */


	  if (straight)
	      {
	        result.length = window++;
	        begin = start;
	      }
	  else
	       start++;
   }
   while(start + window  <= limit);

   
   if(result.length > 0) /* identify cards in run */

       for (count = 0;count < result.length;count++)
	   result.card[count] = begin + count;


    if(result.length == 3)                       /* look for open straight */
      {
	if (begin > 0)
	     {
	                                          /* check card to left */

	     if(hand[(begin - 1)].face_value == hand[begin].face_value - 2)
	       {
		 result.card[ result.length++ ] = begin - 1;
		 result.open_str = 1;
	       }
	      if((begin + 2) < (limit - 1))
	              /* check card to right if 3 run is in middle of hand */

	        if(hand[limit].face_value == hand[limit - 1].face_value + 2)
	          {
		    result.card[ result.length++ ] = limit;
		    result.open_str = 1;
	          }

             }
	  else
	    /*  begin == 0 */
	     if (hand[3].face_value == hand[2].face_value + 2)
	       {
		 result.card[result.length++ ] = 3;
		 result.open_str = 1;
	       }
	}


   if(hand[0].face_value == 1)  /* handle any possible top straight */
      
      {
	
	if(hand[limit].face_value == 13 && hand[limit-1].face_value == 12)
	   if (hand[limit-2].face_value == 11)
	      {
		result.length = 4;
		result.card[0] = 0;
		result.card[1] = limit-2;
		result.card[2] = limit-1;
		result.card[3] = limit;
	      }
	    else
	      {
		result.length = 3;
		result.card[0] = 0;
		result.card[1] = limit-1;
		result.card[2] = limit;
	      }
         else /* look for TJQA */
	   {
	     if (hand[limit].face_value == 12 && hand[limit-1].face_value == 11)
		if (hand[limit-2].face_value == 10)
		   {
		     result.length = 4;
		     result.card[0] = 0;
     		     result.card[1] = limit-2;
		     result.card[2] = limit-1;
		     result.card[3] = limit;
		     result.open_str = 1;
		   }
	    }
      }

   if(pair)
       /* undo shifting of cards                                   */
       /* by incrementing the positon of cards to the right of the */
       /* moved card                                               */

       for(count=0;count<result.length;count++)
	   result.card[count] += (count >= remove);


   return result;

 }/* runs */




high  high_cards(hand)

     playing_card *hand;

/***************************************/
/* find all the High cards, i.e. >= 10 */
/***************************************/

{
    int   count;
    high  result;

    result.number = 0;

    for(count=0;count<HAND_SIZE;count++)
       if(hand[count].face_value >= 10 || hand[count].face_value == 1)
	  result.cards[result.number++] = count;

    if(result.number == 1) /* choose a 2nd card to keep,but don`t report */
       result.cards[1] = (hand[0].face_value == 1)?4:3;

    if(result.number == 0)
       {
	result.cards[0] = 3;
	result.cards[1] = 4;  /* keep top highest two cards */
       }

    return  result;

}/* high cards */

