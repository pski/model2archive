/*******************************************************\
|* This must be altered to the location of the rules   *|
|* file, and the paging method used, e.g. more.	       *|
\*******************************************************/

#ifdef HPUXs300
#define INSTRUCTIONS "/usr/bin/more /usr/games/lib/poker_rules"
#else
#define INSTRUCTIONS "/usr/ucb/more /usr/games/lib/poker_rules"
#endif

/******************************************************\
|*   This next will affect the length of time any     *|
|*  message is displayed for, before being erase.     *|
|*  It should be reduced to speed up the game, on     *|
|*  slower machines.                                  *|
\******************************************************/

#define PAUSE_LEN 450000


/******************************************************\
|*  The next definition is the implementor's mail     *|
|* address, and is displayed on the title_screen.     *|
\******************************************************/

#define IMPLEMENTOR "         |            sscrivan@nyx.cs.du.edu                  |\n"

/*  Leave the rest  */

#include <stdio.h>
#define HAND_SIZE 5
#define DECK_SIZE 52

typedef struct{ /* This is the structure of a single card */

		char face;
		char suit;
		int  face_value;
		int  suit_value;

              } playing_card;

typedef struct{/*  what is a flush made of */

		 int  flush_of;  /* length of flush */
		 int  cards[HAND_SIZE]; /* cards in flush */

	      }  flush;

typedef struct{/* pairs etc. */

		 int  p_type;
		 int  no_of_cards;
		 int  cards[HAND_SIZE];

	      }  prile;

typedef struct{/* partial runs */

		  int  length;
		  int  card[HAND_SIZE];
		  int  open_str;

	      } run;

typedef struct{/* high cards >= 10 */

		  int  number;
		  int  cards[HAND_SIZE];

	      } high;

typedef struct{/* hand description */

		  int  hand_value;
		  int  reject;
		  int  exchange[5];  /* max number of cards to exchange */

	      } describe;

	
