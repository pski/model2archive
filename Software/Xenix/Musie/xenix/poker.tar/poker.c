	/************************************************/
	/*						*/
	/*      	Five card Draw Poker		*/
	/*						*/
	/*  Written by Nic Smith (csx43@uk.ac.kl.seq1)	*/
	/*  As a final year project to illustrate	*/
	/*  intelligent game play.			*/
	/*						*/
	/************************************************/
	/*						*/
	/*  The files that need to be compiled together */
	/* and there main uses are :			*/
	/* 						*/
	/*  poker.h  : include file for structure 	*/
	/*		definitons and configuration   	*/
	/*		locating rules.			*/
	/*  poker.c  : top level of code that pulls 	*/
	/*		together all the main procedures*/
	/*  p_deal.c : handles the shuffling, sorting   */
	/*		and dealing of the cards.	*/
	/*  p_hand.c : hand recognition routines.	*/
	/*  p_strat.c: the strategy used to decide which*/
	/*		hand type to play with, and how */
	/*		to improve the given hand.	*/
	/*  input.c  : accepts most input from the 	*/
	/*		opponent.			*/
	/* p_decide.c: makes decisions based on 	*/
	/*  		imperfect information, such as	*/
	/*		call/raise etc. decisions made	*/
	/*		using probabilities in 'percent'*/
	/*		array.				*/
	/*  p_scr.c  : screen handling functions. This  */
	/*  		uses the 'curses' library	*/
	/* poker_rules : Text file that contains the	*/
	/*		rules and instructions for the	*/
	/*		game.				*/
	/*						*/
	/************************************************/

#include "poker.h"
#include <signal.h>
#define source 0
/* This is the file descriptor for input i.e. terminal 	*/
/* Most procedures can be reused to convert the program	*/
/* to machine-machine play. This can be used to improve	*/
/* and test the strategy.				*/

#define init_stake 250
/* obviously the initial stake given to each player */

#define VOID 0
#define STAY 1
#define DROP 2
#define CALL 3

#define flag int

/********************************/
/*				*/
/* possible responses :		*/
/*				*/
/* 1 = stay			*/
/* 2 = drop			*/
/* 3 = call			*/
/* 4-8 = bet 1-5  resp. 	*/
/* 9-13 = raise 1-5  resp.	*/
/*				*/
/********************************/

playing_card   my_hand[HAND_SIZE], your_hand[HAND_SIZE];

int   your_stake,my_stake,pot;
int   action,last_action;
int   amount,last_bet,total_bet;
int   turn;
flag  i_go_first,whos_go,winner,first_deal;
flag  ante_again;


describe  mine,yours;


long rand();
describe  evaluate();




int   SDB(who) 
      flag  who;

{/* stay, drop or bet */
 /* used for returning both computer and opponent decisions */
 /* it will either call upon the user input routines are the*/
 /* decision making routines.				    */

  int  response;

  if(!who)  /* i.e opponent go */
     response = choose_SDB(source,&amount);
   else
     {

       if (stay(mine.hand_value,last_action,
		first_deal,(my_stake - init_stake)))
          response = STAY;
         else
	     {
	     if(drop(first_deal,yours.reject,mine.hand_value,
		     last_action,(my_stake - init_stake),turn))

	        response = DROP; 
     
	      else /* bet */
	          response = 3 + increase(mine.hand_value,first_deal,
					  yours.reject);
	      }
       i_do(response);

      }
  
   return response;


}/* SDB */




int   RCD(who)
      flag  who;

{ /* raise call or drop */
 /* used for returning both computer and opponent decisions */
 /* it will either call upon the user input routines are the*/
 /* decision making routines.				    */

  int  response;

  if(!who)
     response = choose_RCD(source,&amount,turn);
   else

    {
     if(drop(first_deal,yours.reject,mine.hand_value,
	     last_action,(my_stake - init_stake),turn))
        response = DROP;
   
      else
	  {
	   if(calling(mine.hand_value,turn,first_deal,yours.reject))
	      response = CALL;
   	
	    else /* raise */
	       response = 8 + increase(mine.hand_value,first_deal,
				       yours.reject);
	  }
     i_do(response);
   
    }
   
   return response;
     
}/*RCD*/



void  ante()

{/* ante is 5 */
 /* used for intial ante and re-ante, so does not reset pot */

     your_stake -= 5;
     my_stake -= 5;
     pot += 10;

     inform_ante(pot);

}/* ante */




main()

{
  int  another_go;


  srand(getpid());

  i_go_first = rand()%01; /* a 1 means the computer goes first, a 0 means */
			    /* opponent goes first */

  another_go = 1; /*set to ensure that at least one game is played */

  initialise_screen();
  title_screen(); /* can be altered to show owners mail address */
  instruct();     /* ask if instructions are required, and display if */
		  /* necessary. The full pathname for poker_rules     */
		  /* must be set in here (p_scr.c).		      */
  initialise_cards();

  
  do
  {
    draw_screen();
  
    your_stake=my_stake=300;
    pot =0;
      
    do
    {
      new_deal();
  
      deal_two_hands (your_hand,my_hand);
  
      clear_my_hand();  /* remove computer's old  hand from screen */

      show_hand(your_hand,0); /* display hand at top of screen */
  
      action = VOID;
      ante_again =0;
      ante();
    
      money(your_stake,my_stake,pot);  /*  update money situation on screen */
  
      for(first_deal =1;first_deal >= 0 && !ante_again && action!=DROP;
		        first_deal--)

      {
        last_bet=0;
        total_bet=0;
        last_action=VOID;
        whos_go = i_go_first;
  
        mine = evaluate(my_hand,first_deal);


        turn=1;  /* there is a limited number of betting turns allowed */

        action = SDB(whos_go);

        if(action == STAY)
          {
            turn ++;
            whos_go = !whos_go;
            last_action = STAY;
            action = SDB(whos_go);
            if(action == STAY)
	       if(first_deal)
	             ante_again = 1; 
	         else
	             action = CALL;
          }
         if(!ante_again)
            {
	      while(action!=DROP && action != CALL)
	         {
	           if (whos_go)  /* my_go */
		       amount = (action > 8)?((action - 8) * 5):
				             ((action - 3) * 5);
	           total_bet = amount + last_bet;
	           last_bet = amount;
	           pot += total_bet;
	           if(whos_go)
		        my_stake -= total_bet;
		      else
		          your_stake -= total_bet;
	           money(your_stake,my_stake,pot);
	           turn++;
	           whos_go = !whos_go;
	           last_action = action;
	           action = RCD(whos_go);
	         } /* while */
  
	      if(action == DROP)
	        {
	          if(whos_go)
		      your_stake += pot;
	           else
		      my_stake += pot;
	          pot = 0;
	          money(your_stake,my_stake,pot);
	          winner = !whos_go;
	        }
	      if(action == CALL)
	         {
	            if(whos_go)
		        my_stake -= last_bet;
		      else
		          your_stake -= last_bet;
	            pot += last_bet;
	            money(your_stake,my_stake,pot);
	            if(first_deal)
		       {
                           re_deal(my_hand,mine);
			   i_take(mine.reject);
			   get_user_changes(source,&yours.reject,
					    yours.exchange);

			   re_deal(your_hand,yours);
                           show_hand(your_hand,0);  
		       }
		      else
	               {
			  yours = evaluate(your_hand,first_deal);
                          winner = det_winner(mine.hand_value,yours.hand_value,
	                                      my_hand,your_hand);
		       }

	          }/* call */
             }/* not ante again */
      }/*for*/
      if(!ante_again)
         {
  
           if(action != DROP)
             show_hand(my_hand,1); 

             show_winner(winner);
             if(winner == 1)
	          my_stake += pot;
	     if(winner == 0)
	          your_stake += pot;
	     if(winner != -1)
                  pot = 0;

             money(your_stake,my_stake,pot);

             if((my_stake <= 0 || your_stake <= 0) && !ante_again)
	      {
		if(my_stake == your_stake)
                	winner = -1;
		else
                	winner = my_stake > your_stake;
                show_over_win(winner);
	      }

	     another_go = ano_yes_no(source);

	     i_go_first = !i_go_first;
    
          }
    }/* 2nd do */
    while((my_stake > 0 && your_stake > 0) && (ante_again || another_go));
  
  
  }/* first do */
  while(another_go);

  if(my_stake > 0 && your_stake > 0)
    {
      if(my_stake == your_stake)
      	winner = -1;
      else
      	winner = my_stake > your_stake;
      show_over_win(winner);
    }

die();
}/* end of main */  
