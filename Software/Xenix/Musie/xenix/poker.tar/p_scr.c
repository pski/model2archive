#include "poker.h"
#include <curses.h>
#include <signal.h>
#define x_pos(card_num) (((card_num)%5) * 8 + 1)
#define y_pos(card_num) (((card_num)/5) * 18)
#define WHERE(a,b) ((a) + (5 * ((b) != 0)))
#define MES_Y 1
#define MES_X 1


/*-------------------------------------------------------*\
|   These procedures handle the control of the screen     |
|  using curses.                                          |
\*-------------------------------------------------------*/



WINDOW  *_card[10];              /* a seperate window for each card */


really()

/* Do you really want to quit ? */

{
   int old_x, old_y;
   char  reply;

   getyx(stdscr,old_y,old_x);
   move(23,0);
   printw("Do you really want to quit ? ");
   refresh();
   do
      get_input(0,&reply);
   while(reply != 'y' && reply != 'n');
   move(23,0);
   printw("                             ");
   refresh();
   if(reply == 'y')
	die();
   else
      {
        move(old_y,old_x);
        refresh();
	redraw_screen();
      }

}



die ()
   /********************************/
   /* What to do if user interupts */
   /* and really wants to quit     */
   /*  Or at end of game.          */
   /********************************/

{

   signal(SIGINT,SIG_IGN);
   echo();
   nocrmode();
   mvcur(0,COLS-1,LINES-1,0);
   endwin();
   exit();
}


initialise_screen()

/* init. screen and signals */
{
   initscr();

               /*  initscr() has problems when compiled under att SysV  */

#ifndef HPUXs300
   if (ERR)
       {
	 printf("Error in initialising curses\n");
	 die();
       }
#endif

   nl();
   noecho();
   crmode();
   leaveok(stdscr,TRUE);
   scrollok(stdscr,FALSE);
   signal(SIGINT,really);
   signal(SIGQUIT,really);
            /*  these signals have problems when compiled under att SysV  */

}/* init */


title_screen()
{

   char key_press;

   clear();
   move(10,0);
   printw("         +----------------------------------------------------+\n");
   printw("         |           Welcome to 5 Card Draw Poker             |\n");
   printw("         |                                                    |\n");
   printw("         | This is the Final Year Project of Nic Smith.       |\n");
   printw("         |             csx43@uk.ac.kl.seq1                    |\n");
   printw("         | The implementor of this version can be reached at :|\n");

   printw(IMPLEMENTOR);  /* This is defined in poker.h  */

   printw("         +----------------------------------------------------+\n");

   move(22,0);
   printw("---More---");
   refresh();
   do
      get_input(0,&key_press);
   while (key_press != ' ');

}



redraw_screen()

{
#ifdef HPUXs300
int count;
   for (count=0;count<10;count++)  /* places for the two hands */
      wrefresh(_card[count]);
#else
   wrefresh(curscr);
#endif
}


instruct()

/*  display instructions and rules. The position of the file used is */
/* defined in poker.h  as INSTRUCTIONS			  	     */
{
     char  *inst[100];
     char  reply;


     clear();
     move(1,0);
     printw("Do you want instructions and rules ? [y/n] : ");
     move(1,45);
     refresh();
     do
	get_input(0,&reply);
     while(reply != 'y' && reply != 'n');
     printw("%c",reply);
     refresh();
     if(reply == 'y')
       {
         sprintf(inst,INSTRUCTIONS);
         clear();
         refresh();
         system(inst);
	crmode();
       }

}



draw_screen()

    /*************************************************/
    /* Set up the screen for the game.               */
    /* i.e. Ten card windows, and positions for the  */
    /* pot and stakes.                               */
    /*************************************************/

{
   int count;


   clear();
   refresh();

                      /* first, draw the ten windows for the cards  */

   for (count =0;count<10;count++)  /* places for the two hands */
      {
	_card[count]=subwin(stdscr,5,5,y_pos(count),x_pos(count));
	scrollok(_card[count],FALSE);
	leaveok(_card[count],FALSE);
	box(_card[count],'|','-');

	wmove(_card[count],0,0);
	waddch(_card[count],'.');

	wmove(_card[count],4,0);
	waddch(_card[count],'\`');

	wmove(_card[count],0,4);
	waddch(_card[count],'.');

	wmove(_card[count],4,4);
	waddch(_card[count],'\'');
      };

/* Then number the cards */

   for (count =0;count< HAND_SIZE;count++)
   {
       move(5,(x_pos(count) + 2));
       printw("%d",count + 1);

       move(17,(x_pos(count) + 2));
       printw("%d",count + 1);

       refresh();
#ifdef HPUXs300
	redraw_screen();
#endif
   }


/* Finally set up other screen messages, such as stake etc. */

   move(3,49);
   printw("Stake : ");

   move(7,13);
   printw("Your cards.");

   move(12,55);
   printw("Pot : ");

   move (15,13);
   printw("My cards.");

   move(20,49);
   printw("Stake : ");

   refresh();

}



show_hand (hand,at_bottom)

   playing_card *hand;
   int at_bottom;

  /* display the given hand at the top/bottom of sreen */
  /* at_bottom, refers to where on the screen, and is boolean */

{
   int count;

   for (count=0;count<HAND_SIZE;count++) {
       
	wmove(_card[WHERE(count,at_bottom)],1,1);
	waddch(_card[WHERE(count,at_bottom)],hand[count].suit);

	wmove(_card[WHERE(count,at_bottom)],2,2);
	waddch(_card[WHERE(count,at_bottom)],hand[count].face);

	wmove(_card[WHERE(count,at_bottom)],3,3);
	waddch(_card[WHERE(count,at_bottom)],hand[count].suit);

#ifdef HPUXs300
        wrefresh(_card[WHERE(count,at_bottom)]);
#endif
       };
   refresh();

}/*show_hand*/



clear_my_hand ()

/*  wipe out the cards that appeared in the computer's position */

{
   int count;

   for (count=0;count<HAND_SIZE;count++) {
       
	wmove(_card[HAND_SIZE + count],1,1);
	waddch(_card[HAND_SIZE + count],' ');

	wmove(_card[HAND_SIZE + count],2,2);
	waddch(_card[HAND_SIZE + count],' ');

	wmove(_card[HAND_SIZE + count],3,3);
	waddch(_card[HAND_SIZE + count],' ');

#ifdef HPUXs300
        wrefresh(_card[HAND_SIZE + count]);
#endif
       };
   refresh();

}/* clear_my_hand */



void money(you,me,pot)
     int you,me,pot;

/*  Display all the information about the current distribution of wealth */

{
   move(3,58);
   printw("%6d",you);
   move(12,61);
   printw("%6d",pot);
   move(20,58);
   printw("%6d",me);
   refresh();

}/*money */



void  show_winner(win)
      int  win;

/* Declare the winner, after a hand is played */

{
    int pause;

    for(pause=0;pause<PAUSE_LEN;pause++);
    move(13,0);
    if(win == -1)
      printw("It is a draw, the pot stays. ");
     else
	printw("%s win.                ",win?"I ":"You ");

    refresh();
    for(pause=0;pause<PAUSE_LEN;pause++);

}/* show_winner  */



void  show_over_win(win)
      int  win;

/*  declare the over all winner, when all of a stake is lost, or no more */
/*  games are required							 */

{
    int pause;


    clear_mid();
    move(9,0);
    if(win == -1)
      printw("It is a draw.                                     ");
     else
	{
	  printw("%sthe over all winner of that game.",
		  win?"I am ":"You are ");
	  move(10,0);
	  if(win)
	     printw("     Now isn't that a pity!!           ");
	   else
	      printw("Congratulations! But that was only ONE game.");
	 }

    refresh();

    for(pause=0;pause<PAUSE_LEN;pause++);

}/* show_over_win */




void  i_do(what)
      int  what;

/* Computer declares its actions */

{
   int pause;

   move(13,0);
   printw("I will ");

   switch (what) {
      case 1 : printw("stay.           ");
	       break;
      case 2 : printw("drop my cards.  ");
	       break;
      case 3 : printw("call.           ");
	       break;
      case 4 : case 5 : case 6 : case 7 : case 8 :
	       printw("bet %2d.        ",(5 * (what - 3)));
	       break;
      default : printw("raise %2d.      ",(5 * (what - 8)));
	        break;
   }

   refresh();
   if(what == 1)
      for(pause=0;pause<PAUSE_LEN;pause++);

}/* i_do */




int  ano_yes_no(source)
     int  source;

/* ask if another game is requred, and get a y/n answer */

{
   char  reply;

    move(11,0);
    printw("Do you want another go ?               ");
    move(11,25);
    refresh();
    do
      get_input(source,&reply);
    while(reply != 'y' && reply != 'n');
    mvaddch(11,25,reply);
    refresh();

    return (reply == 'y');

}/* yes_no */
 



show_inc(raising,source,amount)
      int  raising;
      int  source;
      int  *amount;

/*  get and display the user's bet increment	*/

{
   move (9,0);
   printw("How much do you want to %s (1-5):               ",
		       raising?"raise":"bet");
   move(9,37);
   refresh();
   get_increment(source,amount);
   move(9,37);
   printw("%2d",*amount);
   refresh();

}



int   choose_SDB(source,amount)
      int  source;
      int  *amount;

/* ask the user if he wants to stay, drop or bet, and get the reply */

{
   char  choice;
   int   response;
   
   move(13,0);
   printw("                                              ");
   refresh();
   move(9,0);
   printw("Do you wish to Stay,Drop or Bet :             ");
   move(9,34);
   refresh();
   get_SDB(source,&choice);
   move(9,34);
   printw("%c",choice);
   refresh();
   if(choice == 'b')
      show_inc(0,source,amount);
   switch (choice) {
   case 's' : /* Staying */
	    response = 1;
	    break;
   case 'd' : /* dropping */
	    response = 2;
	    break;
   case 'b' : /* betting */
	    response = (*amount/5) + 3;/* bet this */

   }/*switch*/

   return response;

}/* choose SDB */




int   choose_RCD(source,amount,turn)
      int  source;
      int  *amount;
      int  turn;

/* ask user if he wants to raise, drop or call */

{
   char  choice;
   int   response;

   move(9,0);
   printw("%sDo you wish to %sDrop or Call :                ",
	   (turn ==6)?"      ":"",(turn ==6)?"":"Raise,");
   move(9,36);
   refresh();
   do
     get_RCD(source,&choice);
   while(turn == 6 && choice == 'r'); /* disallow raise on turn 6 */
   move(9,36);
   printw("%c",choice);
   refresh();
   if(choice == 'r')
      show_inc(1,source,amount);
   switch (choice) {
   case 'c' : /* Staying */
	    response = 3;
	    break;
   case 'd' : /* dropping */
	    response = 2;
	    break;
   case 'r' : /* betting */
	    response = (*amount/5) + 8;

   }/*switch*/

   return response;

}/* choose RCD */




clear_mid()

/*  Clear the message lines at the middle of the screen  */

{
   move(9,0);
   printw("                                            ");
   move(10,0);
   printw("                                                   ");
   move(11,0);
   printw("                                            ");
   move(12,0);
   printw("                                            ");
   move(13,0);
   printw("                                            ");
   refresh();
}



void  inform_ante(pot)
      int pot;

{/* inform user that ante is required */

    int  pause;

    clear_mid();
    move (11,0);
    printw("We ante%s.                        ",(pot > 10)?" again":"");
    refresh();
    for(pause=0;pause < PAUSE_LEN;pause++);
    clear_mid();

}/* inform ante */



/***********************************************/
/* Following functions are for getting users   */
/* rejected cards.                             */
/***********************************************/


ask_which()


{

    move(9,0);
    printw("Which cards do you want to reject :                ");
    refresh();
    move(9,36);
    refresh();

}/* ask which */



delete_line()

/*  delete the user's input  */

{
    move(9,35);
    printw("           ");
    refresh();
    move(9,35);
    refresh();

}/* delete line */



show_choice(choice,count)
    char  choice;
    int   count;

/* Does computer choose to stay, drop, bet, raise or call ? */

{

     int  across;

     across = 35 + (count * 2);

     mvaddch(9,across,choice);
/*#ifdef HPUXs300
     wrefresh(9);
#endif*/
     refresh();

}/* show choice */



i_take(num)
    int  num;

/* Computer declares how many cards it takes */

{
    int  pause;

    move(11,0);
    printw("I will take %d card%s                       ",num,
						   (num != 1)?"s.":".");
    refresh();
    for(pause = 0;pause < PAUSE_LEN;pause++);
    move(11,0);
    printw("                                            ");
    refresh();

}/* i_take */
