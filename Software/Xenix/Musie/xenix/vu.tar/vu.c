/* vu (v1.0) -- by Wm.Towle
Usage: vu [-c] [+d <delay>] [-l] <filename>

	-c: Don't count width or length
	+d: Add delay (slows down animations)
	-l: Don't "list" the file contents.
*/
#include <stdio.h>
#include <ctype.h>

#define WAIT 500
typedef enum {FALSE,TRUE} bool;


/* Couple of global variables (yuk!)
 */
char escBuf[10];
int escBufPos;

void notlast(int* argnum, int argc)
{
	(*argnum)++;
	if (*argnum == argc)
	{
	    printf ("%s\n", "vu: Missing filename(s)");
	    exit(0);
	}
}

void do_cposch(int* lines, int* width, int* lwidth)
{
 int nwidth,eBpos;

	eBpos = 0;
	while (isdigit(escBuf[eBpos])) eBpos++;
	if (escBuf[eBpos] == ';')
	{
	    eBpos++;
	    nwidth = 0;
	    while (isdigit(escBuf[eBpos]))
	    {
		nwidth = ((nwidth)*10) + (escBuf[eBpos]-'0');
		eBpos++;
	    }
	    nwidth--;
	    *lwidth = nwidth;
	    if (nwidth>*width) *width = nwidth;
	}
}

void main(int argc,char** argv)
{
 int argnum;
 FILE* inFile;
 char byte;
 bool openFail,escape,escOSB /* ESCAPE OPEN-SQUARE-BRACKET */;

 bool list = TRUE,count = TRUE;
 int lines,width,lwidth, pause=0,fpause;

	if (argc == 1)
	{
	    printf ("%s\n%s %s %s\n","vu (v1.0) -- by Wm.Towle",
		"Usage:", argv[0], "[-c] [+d <delay>] [-l] <filename>");
	    exit(0);
	}

	argnum = 1;

	if ( !(strcmp(argv[argnum],"-c")) )
	{
	    count = FALSE;
	    notlast(&argnum,argc);
	}
	if ( !(strcmp(argv[argnum],"+d")) )
	{
	    argnum++;
	    fpause=0;
	    while ( isdigit(argv[argnum][fpause]) )
	    {
		pause = (pause*10) + (argv[argnum][fpause] - '0');
		fpause++;
	    }
	    notlast(&argnum,argc);
	}   
	if ( !(strcmp(argv[argnum],"-l")) )
	{
	    list = FALSE;
	    notlast(&argnum,argc);
	}

	system ("stty -echo");

/* While loop next bit for multiple files, argnum<=argc */
	openFail = FALSE;
if (count)
	if ( (inFile = fopen(argv[argnum],"rb")) == NULL )
	{
	    printf ("%s %s\n", "vu: Can't open file", argv[argnum]);
	    openFail = TRUE;
	}
	else
	{
	    lines = 0; width = 0; lwidth = 0;
	    while (fread(&byte,sizeof(char),1,inFile))
	    {
		switch (byte)
		{
		case 9: /* tab */
		    if (!escape)
		    {
			while ( lwidth%8 ) lwidth++;
			if ( (lwidth) > width) width = lwidth;
			break;
		    }
		case 10: /* newline */
		    escape = FALSE;
		    lines++; lwidth = 0;
		    break;
		case 27: /* escape */
		    escape = TRUE;
		    fread(&byte,sizeof(char),1,inFile);
		    if (byte='[')
			escOSB = TRUE;
		    else
			escOSB = FALSE;
		    break;
		default:
		    if (!escape)
		    {
			if ( (++lwidth) > width) width = lwidth;
		    }
		    else
		    {
			if (escBufPos<=10)
			{
			    escBuf[escBufPos] = byte;
			    escBufPos++;
			}
			if (escOSB && isalpha(byte))
			{
			    escape = FALSE;
			    if ( (byte=='H') || (byte == 'f') )
				do_cposch(&lines,&width,&lwidth);
			}
			if (!escOSB && isdigit(byte)) escape = FALSE;
		    }
		}
	    } /* end of file. */
	    printf ("----- vu: file stats\n");
	    printf ("File : %s\n", argv[argnum]);
	    printf ("Width: %d\n", width);
	    printf ("Lines: %d\n", lines);
	    printf ("-----\n");
	    printf ("(RETURN:)");
	    do {scanf("%c",&byte);} while (byte!=10);
	    printf ("\n");
	}
if (list && !openFail)
	if ( (inFile = fopen(argv[argnum],"rb")) == NULL )
	{
	    printf ("%s %s\n", "vu: Can't open file", argv[argnum]);
	}
	else
	{
	    lines = 0; width = 0; lwidth = 0;
	    while (fread(&byte,sizeof(char),1,inFile))
	    {
		switch (byte)
		{
		case 9: /* tab */
		    printf ("\t");
		    break;
		case 10: /* newline */
		    printf ("\n");
		    break;
		default:
		    printf ("%c", byte);
		    break;
		}

		for (fpause = 0; fpause<pause*WAIT; fpause++);
	    } /* end of file. */
	}

	system ("stty echo");
}
