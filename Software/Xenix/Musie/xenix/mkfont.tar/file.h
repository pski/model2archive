struct	file
{
	char	f_flag;
	union {
		struct file *f_slnk;    /* next waiter for semaphore */
	} f_un;
};

extern struct file *file;	/* The file table itself */

