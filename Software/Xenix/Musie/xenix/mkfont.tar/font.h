/*
 * $Header: font.h,v 1.1 87/10/23 19:08:08 sysad Exp $
 */

/*
 * $Log:	font.h,v $
 * Revision 1.1  87/10/23  19:08:08  sysad
 * Initial revision
 * 
 * 
 */

struct Font {
	char nwfont;
	char specfont;
	char ligfont;
	char pad;
	char namefont[10];
	char intname[10];
};

#define	LIG_FF	01
#define	LIG_FI	02
#define	LIG_FL	04
#define	LIG_FFI	010
#define	LIG_FFL	020
