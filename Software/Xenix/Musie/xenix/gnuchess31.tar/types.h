
typedef long		daddr_t;	/* disc address */
typedef char *		caddr_t;	/* core address */
typedef unsigned short	ushort;
typedef unsigned short	ino_t;		/* i-node number */
typedef char		cnt_t;
typedef long		time_t;		/* time (seconds) */
typedef int		label_t[13];	/* d2-d7, a2-a7, pc */
typedef short		dev_t;		/* device code */
typedef long		off_t;		/* offset in file */
typedef long		paddr_t;
typedef unsigned short	mloc_t;		/* memory region location */
typedef short		msize_t;	/* memory region size */

	/* selectors and constructor for device code */
#define major(x)        (((unsigned)(x)>>8))
#define minor(x)        ((x)&0377)
#define makedev(x,y)	(dev_t)((x)<<8 | (y))

/* 'void' type compatibility */
#ifndef	M_VOID
typedef int	void;
#endif

/* 'unsigned' type compatibility */
#ifdef	M_OLDSIGN
typedef char	uchar_t;
typedef long	ulong_t;
#else
typedef unsigned char	uchar_t;
typedef unsigned long	ulong_t;
#endif

/* M000 begin...
 *  The following is not only a kludge,
 *  it is also not really correct.
 */
#define	GETUCHAR(uc)	(0xFF & (uc))		/* extract value */

/* WARNING: you lose the high (sign) bit */
#ifdef M68000
#  define GETULONG(ul)	(0x7FFFFFFF & (ul))	/* extract 31-bit value */
#else
#  define GETULONG(ul)	(0x7FFF & (ul))		/* extract 15-bit value */
#endif
/* ...end M000 */
