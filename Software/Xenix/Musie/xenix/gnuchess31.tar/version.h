/* This is version 3.1 of GNU Chess.
   Copyright (c) 1990 Free Software Foundation.

   Information about this program and its variants is
   available from:

   Stuart Cracraft
   P.O. Box 2841
   Laguna Hills, Ca.
   92654-2841
*/
