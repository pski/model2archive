#include "mshell.h"

struct macro {
	DL_NODE n;
	char *name;
	char *def;
};

static DLIST macrolist;

char *
mac_lookup(name)
char *name;
{
	struct macro *m;

	if (macrolist)
		foreachnode(macrolist, m)
			if (strcmp(m->name, name) == 0)
				return(m->def);

	/* note: could do a help/list macro here as builtin */

	printf("No definition for macro %s\n", name);
	return("");
}

load_macrofile(f)
char *f;
{
	FILE *fp;
	char line[MAXLEN], name[MAXLEN], def[MAXLEN];
	struct macro *m;

	if ((fp = fopen(f, "r")) == NULL)
		return;

	if (!macrolist)
		macrolist = dl_create(DL_FREE);

	while (fgets(line, MAXLEN, fp))
		if (
			sscanf(line, "%[^=]=%[^\n]\n", name, def) == 2 &&
			(m = getnode(sizeof(*m))) &&
			(m->name = strsave(name)) &&
			(m->def = strsave(def))
		)
			dl_prepend(macrolist, m);
	fclose(fp);
}
