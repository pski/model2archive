#include "mshell.h"


extern char     G_homevar      [];
extern char     G_uservar      [];
extern char 	G_termvar      [];
extern char     G_mailfile     [WORDLEN];
extern char     G_mail_message [WORDLEN];
extern int      G_mailsize; 
extern struct   stat G_st;

/* ======================================================================= */
execute_command (command, args)
/* ======================================================================= */
char *command, *args [];
{
	/*
	char * var_args [2 * MAXARGS]; 
	char * new_var_args [MAXARGS][MAXARGS];
	*/
	int pid, i, j, count = 0;
	extern int G_limited;

	G_mail_message[0] = EOS;

	if (G_limited && invalidcommand(args[0])) {
		printf("Invalid option in restricted menus, sorry.\n");
		printf("See the 'info' menu for how to get a real menu or shell.  (It's free.)\n");
		return;
	}
	if (strcontains(command, "*;|<>&()[]?'\"`~\\")) {
		/* let shell handle these */
		system(command);
		return;
	}

	if (strcmp (args[0], CHANGE_DIR) == 0)
		change_directory (args[1]);
	else if (strcmp (args[0], SETENV) == 0)
		/* remove $ sign from environment variable */
		setenv (args[1], args[2]);

	 /* invoke the command using fork & exec *
	  * ==================================== */
	 else if ( ( pid = fork () ) == 0 ) {	/* 	child process */
		signal (SIGINT,  SIG_DFL); 
		signal (SIGQUIT, SIG_DFL); 
		execvp(args[0], args);
		perror(args[0]);
		exit(1);
	}
	else
		while ( wait (0) !=  -1 )    /*    parent waits for  */
			;		     /*    child            */
}

/* ========================================================= */
get_actions (input_string, exec_string, args)
/* ========================================================= */
char *input_string, *exec_string, *args[];
{
	char *p = input_string, word[WORDLEN], *val, *type, *realval;
	char *index(), *prompt(), *ufix(), *strsave(), *strcatsave();
	int    i = 0;

	/* Display a helpfile, if appropriate *
	 * ================================== */
	extract_action_word    (input_string, HELPVAL, word, 0);
	if (word[0])
		helpfile_display(word);

	/* pull out the actual value of args *
	 * ==================================*/

	i = -1;
	exec_string[0] = EOS;

	/* XXX - should check i not out of bounds */
	while ( sscanf(p, "%s", word) == 1 ) {
		while (isspace(*p))	/* skip spaces, then word... */
			p++;
		p += strlen(word);	/* ...for sscanf next time */

		if ((val = index(word, '=')) == NULL) {
			/* default: treat like arg= */
			val = word;
			type = "arg";
		}
		else {
			val[0] = EOS;	/* split word into selector and value */
			val++;		/* make val point to value part */
			type = word;
		}

		/* build an argv entry */
		if (strcmp(type, "cmd") == 0 || strcmp(type, "arg") == 0)
			args[++i] = realval = ufix(strsave(val));
		else if (strcmp(type, "prompt") == 0)
			args[++i] = realval = strsave(prompt(val));
		else if (strcmp(type, "aarg") == 0)
			args[i] = realval = ufix(strcatsave(args[i], val));
		else if (strcmp(type, "aprompt") == 0)
			args[i] = realval = strcatsave(args[i], prompt(val));

		/* build string for 'system' just in case */
		if (strcmp(type, "aarg") != 0 && strcmp(type, "aprompt") != 0)
			strcat(exec_string, " ");
		strcat(exec_string, realval);
	}

	args[++i] = NULL;
}

/* function to reorder various command line args based on original string *
 ======================================================================== */
assign_parameters (varg_ptr, input_line, command, args, aargs, promptval)
char * varg_ptr [2 * MAXARGS];
char input_line  [DESCLEN];
char command     [WORDLEN];
char args        [MAXARGS][WORDLEN];
char aargs       [MAXARGS][WORDLEN];
char promptval   [MAXARGS][WORDLEN];

{
	char target_string [DESCLEN];
	int position, i = 0;
	
	i = 0;
	while ( strcmp (input_line, NULLSTR) != 0 ) {

		filter_leading_trailing_blanks_tabs (input_line);
		if ( (position = strsearch (input_line, " ")) < 0 ) 
			position = strlen(input_line) - 1;

		target_string[0] = EOS;
		strncpy ( target_string, input_line, position + 1);
		target_string [position+1] = EOS;
		remove_string (input_line, 0, position + 1);

		if ( strsearch (target_string, CMDVAL) >= 0)
			varg_ptr [i++] = command;
		else if ( strsearch (target_string, ARGVAL) >= 0) 
			varg_ptr [i++] = (args++);
		else if ( strsearch (target_string, AARGVAL) >= 0)
			varg_ptr [i++] = (aargs++);
		else if ( strsearch (target_string, PROMPTVAL) >= 0)
			varg_ptr [i++] = (promptval++);
		else if (index(target_string, '=') == NULL) /* same as ARGVAL */
			varg_ptr [i++] = (args++);
		
	}	/* while */
}		/* assign_parameters */

reorganize (var_args, new_var_args, rcount)
char * var_args [2 * MAXARGS];
char * new_var_args [MAXARGS][MAXARGS];
int  * rcount;

{
	int i, j=0, k=0;
	char * temp;

	for ( i=0; var_args[i] != NULL; ) {

		while (( !index (var_args[i], PIPECHAR)) && (var_args[i] != NULL))
			new_var_args[j][k++] = var_args[i++];

		if ( index (var_args[i], PIPECHAR) ) {
			new_var_args[j++][k] = NULL;
			k = 0;
			temp = var_args[i++];
			temp++;
			new_var_args[j]  [k++] = temp;
		}
	}

	new_var_args [j][k] = NULL;
	*rcount = j + 1;
}

doexec(args)
char *args[];	/* assumes is run in child process */
{
	int fds [2], rpid, i = MAXARGS;

	while (--i > 0)
		if (args[i] && args[i][0] == PIPECHAR)
			break;

	if (i > 0) {		/* not first command in pipeline */
		args[i]++;	/* skip PIPECHAR */
		pipe(fds);
		if (fork()) {
			dup2(fds[1], 1);
			close(fds[0]);
			close(fds[1]);
		}
		else {	/* child */
			close(0);
			dup(fds[0]);
			close (fds[0]);
			close (fds[1]);

			while (i < MAXARGS)
				args[i++] = NULL;

			doexec(args);
		}
	}

	execvp(args[i], args+i);
	perror(args[i]);
	exit(0);
}

struct command {
	DL_NODE n;
	char *c;
};

invalidcommand(cmd)
char *cmd;
{
	static int initialized;
	static DLIST commands;
	int iscmd();

	if (!initialized) {
		FILE *fp;
		char line[256], *p;
		struct command *c;

		if ((fp = fopen(COMMAND_LIST, "r")) == NULL) {
			printf("Command list missing!\n");
			return TRUE;
		}

		if ((commands = dl_create(DL_FREE)) == NULL) {
			printf("Out of memory!\n");
			exit(1);
		}

		while (fgets(line, sizeof(line), fp)) {
			if ((p = malloc(strlen(line)+1)) == NULL ||
			    (c = getnode(sizeof(struct command))) == NULL) {
				printf("Out of memory!\n");
				exit(1);
			}
			strcpy(p, line);
			p[strlen(p)-1] = '\0';
			c->c = p;
			dl_append(commands, c);
		}

		fclose(fp);
		initialized = TRUE;
	}

	return(!dl_lsearch(commands, dl_head(commands), NULL, cmd, iscmd));
}

iscmd(c, cmd)
struct command *c;
char *cmd;
{
	return(strcmp(cmd, c->c) == 0);
}
