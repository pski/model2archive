/*   setenv.c   */
#include "mshell.h"

extern char **environ;

#define NULL	0
#define NO_ROOM	(-1)
#define O_K	0

setenv(var, value)
register char *var, *value;
{
	char **env = environ;
	char **newenv, **newenv_base;
	char *entry;		/* pointer to the new, malloc'd entry */
	char *getenv(), *malloc(), *calloc();
	int var_len;

	var_len = strlen(var);	/* used often (maybe) */

	/* make room for the new entry */

	entry = malloc(var_len+strlen(value)+2);
	if (entry == NULL)
		return(NO_ROOM);

	/* copy in the entry */

	sprintf(entry, "%s=%s", var, value);

	/* see where to put it now */

	if (getenv(var) != NULL)	/* if it has a value, change it */
		for (; *env != NULL; env++) {
			if (strncmp(*env, var, var_len) == 0) {
				*env =  entry;
				break;	/* for */
			}
		}
	else {				/* remake the whole list, and add it */
		newenv = (char **) calloc(sarsize(env)+2, sizeof(char *));
		if (newenv == NULL)
			return(NO_ROOM);
		newenv_base = newenv;

		while (*newenv++ = *env++)
			;			/* copy table */
		*--newenv = entry;		/* add new one at end */
		*++newenv = NULL;		/* end list */
		environ = newenv_base;		/* and make it final */
	}

	return(O_K);

} /* setenv */


/*
 * sarsize(sar) -- determine size of
 * NULL terminated string array ("sar"),
 * such as argv or envp.
 * Returned value is akin to argc:
 * sar[returned_val] == NULL.
 */

sarsize(sar)
register char **sar;
{
	register size = 0;

	if (sar == NULL)	/* if no array to begin with, return 0 */
		return(0);

	while (sar[size] != NULL)
		size++;

	return(size);

} /* sarsize */


printenv()
{
	char **env = environ;

	printf("--------------------\n");
	while (*env != NULL)
		printf("%s\n", *env++);
	printf("--------------------\n");


}
