#include "mshell.h"

extern char     G_homevar      [];
extern char     G_uservar      [];
extern char 	G_termvar      [];
extern char     G_mailfile     [WORDLEN];
extern char     G_mail_message [WORDLEN];
extern int      G_mailsize; 
extern struct   stat G_st;

void change_directory(new_dir)
char *new_dir;

{
	char old_dir [MAXLEN]; 
	int i;

#ifdef BSD
	getwd (old_dir);
#endif
#ifdef SYSV
	getcwd(old_dir, sizeof(old_dir));
#endif

	if ( strcmp ( new_dir, NULLSTR ) == 0 )
		printf ("\t no directory change requested !!\n\n");
		/* XXX - could cd home */
	else {
		printf ("\n\n");
		if ( chdir (new_dir) != 0 ) 
			printf ("\t No such directory as %s\n\n\n", new_dir );
	}		/* end else strcmp */
}			/* terminate function change_directory */
