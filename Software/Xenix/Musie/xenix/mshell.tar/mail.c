#include "mshell.h"


extern char     G_homevar      [];
extern char     G_uservar      [];
extern char 	G_termvar      [];
extern char     G_mailfile     [WORDLEN];
extern char     G_mail_message [WORDLEN];
extern int      G_mailsize; 
extern struct   stat G_st;

check_for_new_mail (message)
char * message;
{
	off_t new_mail_size;

	stat (G_mailfile, &G_st);

	new_mail_size = G_st.st_size;

	if ( new_mail_size > G_mailsize )
		strcpy ( message, MAIL_MESSAGE );

	G_mailsize = new_mail_size;
}
