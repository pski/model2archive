#include "mshell.h"

#ifdef BSD
#define strchr	index
#endif


/* function to find the position of sub_string in main_string 
 * ---------------------------------------------------------- */

strsearch (main_string, sub_string)
char main_string[], sub_string[];
{
	int start_mstring = 0, start_sstring = 0, 
	    factor = 0, answer, main_pos = 0;

		while ( main_string[start_mstring] != EOS  &&
			sub_string[start_sstring] != EOS )       {

			if ( main_string[start_mstring] !=
		              sub_string[start_sstring] )  {
				++main_pos;
				start_mstring = main_pos;
				start_sstring = 0;
				factor = 0;
			}
			else   {
				++factor;
				++start_mstring;
				++start_sstring;
			}		/* end if-else */

		}			/* end while */

		if (( sub_string[start_sstring] == EOS && factor > 0 ) ||
		    ( main_string[start_mstring] == EOS &&
		       sub_string[start_sstring] == EOS ))   {

			answer = main_pos;
			return(answer);
		}
		else 
			return(-1);	/* end if-else */
}					/* end function strsearch */

/* function to remove string starting at a specified position  
 * ----------------------------------------------------------  */

remove_string (main_string, start_index, no_of_bytes )
char main_string[];
int  start_index, no_of_bytes;

{
	int index, offset;

	offset = strlen (main_string) - no_of_bytes;
	/* offset is defined as the index no of the last element which
	 * will be present in the new string or the unremoved bytes +
	 * bytes that need to be repositioned */

	for ( index = start_index; index < offset; ++ index ) 
		main_string [index] = main_string [index + no_of_bytes];

	main_string[index] = EOS;

}				/* end of function remove_string */

/* replace string function 
 * ----------------------- */

int replace_string (main_string, old_string, new_string)
char main_string[256], old_string[256], new_string[256]; 

{
	int  pos;

	pos = strsearch (main_string, old_string);

	if ( pos >= 0 ) {
		remove_string (main_string, pos, strlen(old_string));
		insert_string (main_string, new_string, pos);
		return (TRUE);
	/* 	printf ("\n\n\tnew string is  %s\n\n", main_string); */
	}
	else
		return (FALSE);
} 	/* end function replace_string */

/* function to find insert sub-string in main-string at a specific position
 * ------------------------------------------------------------------------ */

insert_string ( main_string, sub_string, position )
char main_string [], sub_string [];
int  position;

{
	int i, j, offset;

	if (sub_string) {
		offset = strlen(sub_string);
		j = strlen (main_string);

		for (i = j; i >= position; i--)
			main_string [i+offset] = main_string [i];

		for (i=0; i < offset ; i++) 
			main_string [i+position] = sub_string [i];

		main_string [j+offset] = EOS;
	}
}

#include <ctype.h>

#define NULL	0
#define STRLEN	256

char *
findvar(s)
char *s;
{
	static char var[STRLEN];
	char *p, *v = var, *strchr();

	if ((p = strchr(s, '$')) == NULL)
		return (NULL);

	p++;	/* skip $ */

	while (isalnum(*p))
		*v++ = *p++;

	*v = '\0';

	return(var);
}

substitute(s)
char *s;
{
	char var[STRLEN], *v_in_s, *getenv();

	if ((v_in_s = findvar(s)) == NULL)
		return(0);
	
	sprintf(var, "$%s", v_in_s);
	replace_string(s, var, getenv(v_in_s));
	return(1);
}

#ifdef DEBUGGING
main()
{
	char s[STRLEN];

	while (1) {
		printf("s-> ");
		gets(s);
		substitute(s);
		printf("--> %s\n", s);
	}
}
#endif

all_blanks (string)
char * string;
{
	for ( ; ((*string == BLANK) && (*string != EOS)) ; ++string);

	if ( *string == EOS ) 
		return (TRUE);
	else
		return (FALSE);
}

/* function to find position  of sub string in a main string 
 * ---------------------------------------------------------- */

/* ========================================= */
char * find_string (main_string, sub_string)
/* ========================================= */
char main_string[], sub_string[];
{
	int start_mstring = 0, start_sstring = 0, 
	    factor = 0, answer, main_pos = 0;

		while ( main_string[start_mstring] != EOS  &&
			sub_string[start_sstring] != EOS )       {

			if ( main_string[start_mstring] !=
		              sub_string[start_sstring] )  {
				++main_pos;
				start_mstring = main_pos;
				start_sstring = 0;
				factor = 0;
			}
			else   {
				++factor;
				++start_mstring;
				++start_sstring;
			}		/* end if-else */

		}			/* end while */

		if (( sub_string[start_sstring] == EOS && factor > 0 ) ||
		    ( main_string[start_mstring] == EOS &&
		       sub_string[start_sstring] == EOS ))   {

			answer = main_pos;
			return(&main_string[main_pos]);
		}
		else  {
			/* answer = -1; */
			return(NULL);	/* end if-else */
		}
}					/* end function find_string */

/******************************************************************************
 * reads a line of input string from the terminal and keeps doing so until    *
 * input string contains no colons                                            *
 *****************************************************************************/


struct inp_link {
	DL_NODE n;
	char *input;
};
static DLIST inputstack;

read_input_line(string)
char *string;
{
	extern int G_shell_ok;
	char *p;

	if (string == NULL) {	/* just read and trash line */
		int c;
		while ((c = getchar()) != '\n' && c != EOF)
			;
		return;
	}

	if (inputstack == NULL)
		inputstack = dl_create(DL_FREE);

	do {
		/* if any input (e.g., from last time) on stack use that... */
		if (dl_size(inputstack) > 0) {
			struct inp_link *l;
			l = (struct inp_link *) dl_shead(inputstack);
			strcpy(string, l->input);
			free(l->input);
			dl_delete(inputstack);
		} /* ... else get some new input */
		else if (gets(string) == NULL) {
			printf("End of input -- quitting...\n");
			exit(1);
		}

		/* if it has a multi-command delim, save rest for next time */
#define MULTI_CMD_DELIM ','
		if (p = index(string, MULTI_CMD_DELIM)) {
			char *strsave();
			struct inp_link *l;
			*p++ = EOS;
			if ((l=getnode(sizeof(*l))) && (l->input=strsave(p)))
				dl_prepend(inputstack, l);
		}

		filter_leading_trailing_blanks_tabs (string);

		/* if macro, then expand & push definition on stack */
#define MACRO_DELIM '#'
		if (string[0] == MACRO_DELIM) {
			char *mac_lookup();
			char *def = mac_lookup(string+1);
			struct inp_link *l;
			if (def && (l = getnode(sizeof(*l))) &&
						(l->input = strsave(def)))
				dl_prepend(inputstack, l);
		}
	} while (string[0] == MACRO_DELIM);

	/* if not allowing shell, then chop off at funny chars */
	if (! G_shell_ok)
		truncate_at_invalid_chars (string);

}  /* end function read_input_line */

int moreinput()
{
	return (inputstack && dl_size(inputstack) > 0);
}


/****************************************************************************
 * Function to filter out all leading and trailing blanks from a strings    *
 * Takes a character string as a parameter                                  *
 ****************************************************************************/

void filter_leading_trailing_blanks_tabs ( string )
char * string;
{
	int i, j ;

	for ( i = 0 ; (( string[i] != EOS ) && (( string[i] == BLANK )
					    ||  ( string[i] == TAB   )) ); ++i )
		;
	for ( j = 0 ; ( string[j] != EOS ) ; ++j ) 
		string[j] = string[j + i];

	string[j] = EOS;

	for ( i = strlen(string) - 1 ; ( i >= 0 ) ; --i )
		if (( string[i] != BLANK ) && ( string[i] != TAB ))
			break;

	string[i+1] = EOS; 

	return ;
}

char *
strsave(s)
char *s;
{
	char *p, *malloc();
	if (s == NULL || (p=malloc(strlen(s)+1)) == NULL)
		return(NULL);
	strcpy(p, s);

	return(p);
}

/* assumes d was malloc'd -- then makes large enough to cat s onto it */
char *
strcatsave(d, s)
char *d, *s;
{
	char *realloc();

	if (d && (d = realloc(d, strlen(d)+strlen(s)+2)))
		strcat(d, s);

	return(d);
}

/* replace _ with space */
char *
ufix(s)
char *s;
{
	char *p;
	for (p = s; p && *p; p++)
		if (*p == '_')
			*p = ' ';
	return(s);
}

strcontains(s, chars)
char *s, *chars;
{
	while (*chars)
		if (index(s, *chars++))
			return(1);
	return(0);
}

/* remove string from no-no chars on */
truncate_at_invalid_chars (string)
char *string;
{
	char *p, *index();
	/* XXX - update to use strpbrk */
	if (p = index(string, ';'))
		*p = EOS;
	if (p = index(string, '`'))
		*p = EOS;
	if (p = index(string, '|'))
		*p = EOS;
	if (p = index(string, '<'))
		*p = EOS;
	if (p = index(string, '>'))
		*p = EOS;
	if (p = index(string, '^'))
		*p = EOS;
	if (p = index(string, '('))
		*p = EOS;
	if (p = index(string, '&'))
		*p = EOS;
}
