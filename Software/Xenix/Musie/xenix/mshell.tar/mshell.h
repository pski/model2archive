#include <stdio.h>
#include <curses.h>
#include <sys/signal.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifdef BSD
#include <sys/dir.h>		/* accessing the directory structure	*/
#include <sgtty.h>		/* struct for terminal attributes       */
#endif
#ifdef SYSV
#define index	strchr
#define rindex	strrchr
/* #include <termio.h>		/* do this if curses.h doesn't */
#endif
#include "dl.h"

#define  BLANK           ' '
#define  COLUMNS         256
#define  DESCLEN         128
#define  EOS             '\0'
#define  EXCLAIM         '!'
#define  LINES           80
#define  MAXARGS         10
#define  MAXLEN          256
#define  NULLSTR         ""
#define  MAIL_MESSAGE    "	[You have new mail]"
#define  OPTLEN          16
#define  PIPECHAR        '|'
#define  DELIM_LINE      "*****\n"	/* \n since fgets is used */
#define  SUFFIX          ".men"
#define  TAB             '\t'
#define  HOME_CHAR       "~"
#define  VISIBLE_SPACE   '_'
#define  WORDLEN         64

#define  CMDVAL          "cmd="
#define  ARGVAL          "arg="
#define  AARGVAL         "aarg="
#define  HELPVAL         "help="
#define  PROMPTVAL       "prompt="
#define  APROMPTVAL      "aprompt="
#define  HELP            "help"
#define  MAN             "man="
#define  BYE             "bye"
#define  QUIT            "x"
#define  CHANGE_DIR      "cd"
#define  SETENV		 "setenv"

#ifndef  MAILDIR
#define  MAILDIR         "/usr/spool/mail/"
#endif
#ifndef  MENUDIR
#define  MENUDIR         "/nyx/lib/menus"
#endif
#ifndef  GLOBAL_MACRO_FILE
#define  GLOBAL_MACRO_FILE         "/nyx/lib/menus/macros"
#endif
#ifndef  COMMAND_LIST
#define  COMMAND_LIST         "/nyx/lib/menus/commands"
#endif

#ifndef TRUE	/* curses.h may #define */
#define TRUE   1
#define FALSE  0
#endif

struct   menu_struct {
	char curr [WORDLEN];
	char prev [WORDLEN];
};

#define void	int
int 	all_blanks ();
void    change_directory();
void    check_for_new_mail ();
void 	helpfile_display ();
void 	display_menu ();
void 	display_prompts ();
void 	execute_command ();
void 	extract_actions ();
void 	extract_action_word ();
void	filter_leading_trailing_blanks_tabs ();
char * 	find_string ();
void    find_user_details ();
char *  in_string ();
void    initialize ();
void 	insert_string ();
void    invoke_unix_system ();
void 	M_Shell ();
void 	read_input_line ();
void 	remove_string ();
int 	replace_string ();
void 	search_menu_array ();
int 	strsearch ();
void 	set_terminal_attributes ();
int    	setenv ();
void 	wait_for_user ();
