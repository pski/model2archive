#include "mshell.h"
#include <setjmp.h>
char * index ();


extern char     G_homevar      [];
extern char     G_uservar      [];
extern char 	G_termvar      [];
extern char     G_mailfile     [WORDLEN];
extern char     G_mail_message [WORDLEN];
extern int      G_mailsize; 
extern int      G_shell_ok; 
extern struct   stat G_st;

/* ================== */
M_Shell (m)
/* ================== */

char *m;

{
	char opt           [WORDLEN],
	     opt1          [OPTLEN],
	     opt2          [OPTLEN],
	     action_string [DESCLEN],
	     exec_string   [DESCLEN],
	     *args         [MAXARGS],
	     *menu_array   [LINES],
	     tmpword       [WORDLEN],
	     *malloc();

	int  i, 
	     idx,
	     invalid_option = FALSE,
	     firsttime = TRUE,
	     dontdisplay = FALSE,
	     unix_flag,
	     menu_flag,
	     exit();

	static jmp_buf topenv;
	static int topenvset;

	menu_flag = FALSE;
	signal (SIGHUP,  exit);
	signal (SIGINT,  SIG_IGN);	/* ignore all ^C interrupts */
	signal (SIGQUIT, SIG_IGN);	/* ignore all ^\ interrupts */
	signal (SIGTSTP, SIG_IGN);	/* ignore all ^Z interrupts */
	signal (SIGPIPE, SIG_IGN);	/* ignore dead pipes */
	log("enter", m);

	while TRUE {

		if (!topenvset) {
			topenvset = TRUE;
			setjmp(topenv);
		}

		unix_flag = FALSE;

		/* keep looping until a valid response has been entered *
		 * ==================================================== */
		do {
			if (display_menu(m, menu_array, &menu_flag, &idx) == 0)
				return;

			if ( firsttime ) {
				firsttime = FALSE;
				search_menu_array (menu_array, idx, "_init",
					action_string, &invalid_option);
				if (!invalid_option) {
					while (substitute(action_string))
						;
					get_actions (action_string,
						exec_string, args);
					execute_command (exec_string, args);
				}
				else	
					invalid_option = FALSE;
			}

			if ( invalid_option )
				printf ("No such choice as '%s'.", opt);

			if (!moreinput())
				printf ("\tSelect choice [or help, x, top, bye]: ");
			opt[0] = 0;
			read_input_line (opt);
			log("	", opt);
			invalid_option = FALSE;
			putchar('\n');

			/* if first character of option is an "!"    *
			 * character then invoke the remaining line  *
			 * using the C system function               *
			 * ======================================== */

			if ( !opt[0] )
				continue;
			else if ( opt[0] == EXCLAIM && G_shell_ok ) {
				system(opt+1);
				unix_flag = TRUE;
				wait_for_user ();
			}
			else {
				search_menu_array (menu_array, idx, opt,
					action_string, &invalid_option);
			}
		}
		while ( invalid_option );

		if ( unix_flag || !opt[0] )
		/* bypass execution of code until end of while(TRUE) loop *
		 * ====================================================== */
			continue;


		/* replace environment variables with values */
		while (substitute(action_string))
			;

	/* remove actual values of commands and arguments from action-string */
	/* ================================================================= */
		get_actions (action_string, exec_string, args);

	/* display any prompt and get values if specified in the command line */
	/* ================================================================== */
		opt1[0] = EOS;
		opt2[0] = EOS;

		if ( index (opt, BLANK) != NULL )
			sscanf (opt, "%s %s", opt1, opt2);
		else
			strcpy (opt1, opt);

		if ( strcmp (opt1, HELP) == 0 ) {
			if ( strcmp (opt2, NULLSTR) == 0 )
				strcpy(opt2, prompt("Help on which choice"));

			search_menu_array (menu_array, idx, opt2,
				   action_string, &invalid_option);

			if ( strcmp (action_string, NULLSTR) == 0 ) {
				invalid_option = TRUE;
				printf ("\tNo such help option name as: %s\!\!\n", opt2);
			}
			else {
				tmpword[0] = EOS;
				extract_action_word (action_string, MAN, tmpword, 0);
				if ( strcmp (tmpword, NULLSTR) == 0 ) 
					extract_action_word (action_string, CMDVAL, tmpword, 0);
				if (strcmp(tmpword, NULLSTR) != 0)
					do_man(tmpword);
			}

/*			if ( invalid_option ) {*/
				invalid_option = FALSE;
				wait_for_user ();
/*			}*/
			continue;
		}

	/* if the command is to invoke another menu then do not exec	*
	 * but call M_Shell recursively					*
	 * =========================================================    */
		if ( all_blanks (opt) ) 
			;
		else if (strcmp (opt, BYE)  == 0)
			bye(0);
		else if (strcmp (opt, QUIT) == 0) {
			for (i = 0; i < LINES; i++)
				if (menu_array[i])
					free(menu_array[i]);
			log("exit", m);
			return;
		}
		else if (strcmp(opt, "T") == 0 || strcmp(opt, "top") == 0) {
			for (i = 0; i < LINES; i++)
				if (menu_array[i])
					free(menu_array[i]);
			longjmp(topenv, 1);
		}
		else if ( strcmp(args[0], "menu") == 0 )
			M_Shell (args[1]);
		else {
			execute_command (exec_string, args);
			wait_for_user();
		}
	}
}

do_man(entry)
char *entry;
{
	char cmd[WORDLEN], *p, *rindex();

	if (p = rindex(entry, '/'))
		entry = p+1;

	sprintf(cmd, "man %s", entry);
	system(cmd);
}

bye(status)
int status;
{
	printf("\nLogging out -- come back again soon...\n\n");
	exit(status);
}
