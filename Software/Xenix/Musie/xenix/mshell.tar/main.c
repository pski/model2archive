/*
 * Mshell
 *
 * A menu shell.
 *
 * Copyright 1991 by Andrew Burt and the University of Denver.
 */
#include "mshell.h"

char     G_homevar      [] = { "$HOME" };
char     G_uservar      [] = { "$USER" };
char 	 G_termvar      [] = { "$TERM" };
char     G_mailfile     [WORDLEN];
char     G_mail_message [WORDLEN];
int      G_mailsize; 
struct   stat G_st;
int	 G_shell_ok;
int	 G_limited = FALSE;

main (argc, argv)
int     argc;
char ** argv;

{
	char menu[WORDLEN];
	char menuname[WORDLEN];
	char *progname = argv[0];

	G_shell_ok = TRUE;
	if ( argc > 1 && strcmp(argv[1], "-s") == 0 ) {
		G_shell_ok = FALSE;
		argc--;
		argv++;
	}
	else if ( argc > 1 && strcmp(argv[1], "-r") == 0 ) {
		G_limited = TRUE;
		G_shell_ok = FALSE;
		argc--;
		argv++;
	}

	if ( argc < 2 ) {
		printf ("Usage: %s <primary menu name>\n", progname);
		exit (1);
	}

	strcpy ( G_mailfile, MAILDIR );
	strcat ( G_mailfile, getenv(&G_uservar[1]) );
	G_mail_message[0] = EOS;

	stat ( G_mailfile, &G_st );
	G_mailsize = G_st.st_size;
	if (G_mailsize > 0)
		strcpy(G_mail_message, "	[You have mail.]");
	else
		G_mail_message[0] = EOS;

#ifdef check_parent
	if ( getppid() == 1 )			/* Mshell is login shell */
#endif
		set_terminal_attributes();
	set_resource_limits();

	rc();
	openlog();
	load_macrofile(GLOBAL_MACRO_FILE);
	load_macrofile(".mshellmac");

	M_Shell (argv[1]);
	bye(0);
}

rc()
{
	if (!G_shell_ok)
		return;

	if (access(".mshellrc", 0) == -1)	/* assumedly now in home dir */
		return;

	system("sh .mshellrc");
}

#ifndef LOGDIR
#define LOGDIR "/u1/logs"
#endif

FILE *logfp;
openlog()
{
	struct passwd *pw;
	char fn[32];

	if ((pw = getpwuid(getuid())) == NULL)
		return;
	sprintf(fn, "%s/%s", LOGDIR, pw->pw_name);
	logfp = fopen(fn, "a");
	chmod(fn, 0600);
}

log(s1, s2)
char *s1, *s2;
{
	if (logfp)
		fprintf(logfp, "%s %s\n", s1, s2);
}
