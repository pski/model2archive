#include "mshell.h"
#include <sys/time.h>
#include <sys/resource.h>

set_terminal_attributes()
{
#ifdef BSD
	struct sgttyb  sg;
	struct tchars  tc;
	struct ltchars lt;
	int ldisc = NTTYDISC;

	ioctl ( 0, TIOCSETD, &ldisc );

	ioctl ( 0, TIOCGETP, &sg );
	if (access(".stty", 0) == -1) {	/* not already set up */
		sg.sg_erase = '\b';
		sg.sg_kill  = 21;	/* ^U */
		sg.sg_flags |= XTABS;
	}
	sg.sg_flags |= ECHO;
	sg.sg_flags &= ~ RAW;
	sg.sg_flags &= ~ CBREAK;
	sg.sg_flags |= CRMOD;
	ioctl ( 0, TIOCSETP, &sg );

	ioctl ( 0, TIOCGETC, &tc );
	tc.t_intrc  = 3;	/* ^C */
	ioctl ( 0, TIOCSETC, &tc );

	ioctl ( 0, TIOCGLTC, &lt );
	lt.t_werasc = 23;	/* ^W */
	lt.t_rprntc = 18;	/* ^R */
	ioctl ( 0, TIOCSLTC, &lt );
#endif
#ifdef SYSV
	struct termio t;

	ioctl ( 0, TCGETA, &t );

	t.c_cc[VINTR] = '\003';
	t.c_cc[VERASE] = '\b';
	t.c_cc[VKILL] = '\025';
	t.c_iflag = IGNBRK | IGNPAR | ICRNL | IXON ;
	t.c_oflag = OPOST | ONLCR ;
	t.c_lflag = ISIG | ICANON | ECHO | ECHOE | ECHOK ;
	t.c_cflag |= TAB3;

	ioctl ( 0, TCSETA, &t );
#endif
}
set_resource_limits()
{
	struct rlimit lim;

	lim.rlim_cur = lim.rlim_max = 0;
	setrlimit(RLIMIT_CORE, &lim);
}
