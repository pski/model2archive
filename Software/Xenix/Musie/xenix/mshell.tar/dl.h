/* ============================== dl.h ============================== */
#ifndef DL_H
#define DL_H    /* so it isn't included more than once */

#ifndef TRUE
#define TRUE	1
#define FALSE	0
#endif

/*
 * Template for other "derived" node types.  We assume a struct dl_node is at
 * the front of the derived type.  Thus dl.c knows nothing about user data.
 */
typedef struct dl_node {
        struct dl_node *next;
        struct dl_node *prev;
        int size;                       /* number of bytes of data following */
} DL_NODE;

/*
 * Structure to refer to a doubly-linked list.
 */
typedef struct dl {
        DL_NODE *head;
        DL_NODE *tail;
        DL_NODE *curr;
        int size;                       /* number of nodes in list */
        int flags;
} *DLIST;

char *getnode();
DLIST dl_create(), dl_copy();
DL_NODE **dl_l2a();

#define dl_head(dl)		((void *) ((dl)->head))
#define dl_tail(dl)		((void *) ((dl)->tail))
#define dl_curr(dl)		((void *) ((dl)->curr))
#define dl_size(dl)		((dl)->size)
#define dl_flags(dl)		((dl)->flags)
#define dl_prev(dl)		((void *) ((dl)->curr->prev))
#define dl_next(dl)		((void *) ((dl)->curr->next))
#define dl_set(dl, n)		((void *) ((dl)->curr = (DL_NODE *) (n)))
#define dl_shead(dl)		((void *) (dl_set(dl, dl_head(dl))))
#define dl_stail(dl)		((void *) (dl_set(dl, dl_tail(dl))))
#define dl_snext(dl)		((void *) (dl_set(dl, dl_next(dl))))
#define dl_sprev(dl)		((void *) (dl_set(dl, dl_prev(dl))))
#define dl_nextof(n)		((void *) (((DL_NODE *)(n))->next))
#define dl_prevof(n)		((void *) (((DL_NODE *)(n))->prev))
#define dl_sflags(dl,f)		((dl)->flags = (f))
#define dl_searchlist(l,key,func)  (dl_lsearch(l, dl_head(l), NULL, key, func))
#define dl_delete(l)		(dl_delete_node(l, dl_curr(l)))
#define dl_detach(l)		(dl_detach_node(l, dl_curr(l)))
#define dl_ins_after(l, n)	(dl_ins_after_node(l, dl_curr(l), n))
#define dl_ins_before(l, n)	(dl_ins_before_node(l, dl_curr(l), n))
#define dl_append(l, n)		(dl_ins_after_node(l, dl_tail(l), n))
#define dl_prepend(l, n)	(dl_ins_before_node(l, dl_head(l), n))
#define dl_split(l, n)		(dl_split_at_node(l, dl_curr(l)))

/* Whether to free() nodes upon deletion or not. */
#define DL_FREE         1
#define DL_NOFREE       0

#ifndef NULL
#define NULL	(0)
#endif

#define NIL     ((void *) 0)            /* for passing as param */

#define foreach(l)		for (dl_shead(l); dl_curr(l); dl_snext(l))
#define foreachnode(l,p)	for ((p)=dl_shead(l); (p); (p)=dl_snext(l))
#endif
