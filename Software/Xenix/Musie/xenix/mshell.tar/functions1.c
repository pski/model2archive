#include "mshell.h"

extern char     G_homevar      [];
extern char     G_uservar      [];
extern char 	G_termvar      [];
extern char     G_mailfile     [WORDLEN];
extern char     G_mail_message [WORDLEN];
extern int      G_mailsize; 
extern struct   stat G_st;

helpfile_display (filename)
char * filename;

{
	FILE * fp;
	char record [DESCLEN];
	if (( fp = fopen (filename, "r")) == NULL ) {
		printf ("\tNo such helpfile as %s\!\!\n", filename);
		return;
	}

	while ( fgets (record, sizeof(record), fp) )
		fputs (record, stdout);
	printf ("\n");
	fclose (fp);
}

/* ================================ */
char *
prompt(p)
/* ================================ */
char *p;
{
	static char ans[WORDLEN];
	extern int G_limited;

	printf ("%s : ", ufix(p));
	if (!G_limited) {
		read_input_line (ans);
		replace_string (ans, HOME_CHAR, getenv(&G_homevar[1])) ;
	}
	else {
		strcpy(ans, "XXX");
		printf("(no input for unvalidated users)");
	}
	printf ("\n");
	return(ans);
}

/* ================================================ */
extract_action_word ( str, sub_str, dest_str, flag)
/* ================================================ */
char *str, *sub_str, *dest_str;
int  flag;

{
	char *position, *target;
	int startpos = 0, string_length = 0, i = 0;
	unsigned  no_of_chars = 0;

	strcpy (dest_str, NULLSTR);		/* initialize dest_str */

	startpos = strsearch (str, sub_str);
						/* find position of sub-string 
						   in main string             */

	if ( startpos != -1 )				/* if it exists */
		target = &str[startpos] + strlen (sub_str);	
							/* assign target */
	else
		return;				/* no such string found */

	for (position = target; 		/* actual value of parameter */
	    (*position != BLANK) && (*position != EOS);
	     ++position, ++no_of_chars);

	strncpy (dest_str, target, no_of_chars);  /* copy the required value */
	dest_str[no_of_chars] = EOS;

	string_length = strlen(sub_str) + no_of_chars;

	if ( *position != EOS )
		++string_length ;

	remove_string (str, startpos, string_length) ;

	if ( flag ) 
		for (i = 0; dest_str[i] != EOS ; ++i)
			if ( dest_str[i] == VISIBLE_SPACE ) 
				dest_str[i] = BLANK;
}

/* ===================== */
display_menu (menu_name, menu_array, menu_flag, idx)
/* ===================== */
char * menu_name;
char * menu_array [];
int  * menu_flag;
int  * idx;

{
	FILE * fp;
	char junk[COLUMNS] , keyword[DESCLEN], description[DESCLEN],
		action_description[DESCLEN], *strsave(), *fgets(), *index();
	register int i;
	int delay;

	if (!moreinput())
		clear_screen();

	check_for_new_mail (G_mail_message);

	if ( *menu_flag == FALSE ) {
		*menu_flag = TRUE;
		if (index(menu_name, '/'))
			strcpy(junk, menu_name);
		else
			sprintf(junk, "%s/%s%s", MENUDIR, menu_name, SUFFIX);
		if (( fp = fopen (junk, "r")) == NULL ) {
			printf ("\tNo such menu as %s!!\n", junk);
			return(0);
		}

		for (
		      i = *idx = 0;
		      i < LINES &&
			(menu_array[i] = strsave(fgets(junk, COLUMNS, fp)));
		      i++
		    )
			if ( strcmp (menu_array[i], DELIM_LINE) == 0 )
				*idx = i;
		
		fclose (fp);

		for ( ; i < LINES; i++)
			menu_array[i] = strsave("");
	}

	if (strcmp(G_mail_message, "") != 0) {
		junk[0] = EOS;
		sscanf(menu_array[0], "%[^\n]", junk);
		printf("%s%s\n", junk, G_mail_message);
		i = 1;
	}
	else
		i = 0;

	if (!moreinput())
		for (; i < *idx; i++)
			fputs(menu_array[i], stdout);

	printf ("\n");
	return(1);
}

/* find the home directory of the person invoking M_Shell */
/* ====================================================== */

find_user_details (home_dir, user_name)
char * home_dir;
char * user_name;
{
	struct passwd *pw, *getpwuid();

	pw = getpwuid (getuid ());

 	strcpy (home_dir, pw->pw_dir);
	strcpy (user_name, pw->pw_name);
}

/* ====================================================== */
search_menu_array (menu_array, ind, option, string, invalid)
/* ====================================================== */
char * menu_array [];
int    ind;
char * option, * string;
int  * invalid;

{
	int i;
	char keyword [WORDLEN];
	char action_description[DESCLEN], junk[DESCLEN];
	char opt1[OPTLEN], opt2[OPTLEN];

	for ( i = ++ind; i < LINES ; ++i ) {
		sscanf (menu_array[i], "%s	%[^\n]", keyword, action_description);
		if ( index (option, BLANK) != NULL ) 
			sscanf (option, "%s %[^\n]", opt1, opt2);
		else
			strcpy (opt1, option);

		if ( strcmp (opt1, keyword) == 0 ) {
			strcpy (string, action_description);
			*invalid = FALSE;
			return;
		}
	}

	if ( all_blanks(option)            || strcmp(option, QUIT) == 0 ||
             strncmp(option, HELP, 4) == 0 || strcmp(option, BYE)  == 0 ||
	     strcmp(option, "T") == 0      || strcmp(option, "top") == 0)
		*invalid = FALSE;
	else
		*invalid = TRUE;

	strcpy (string, NULLSTR);
}

wait_for_user ()
{
	printf("\nHit ENTER to continue ... ");
	read_input_line (NULL);
}

clear_screen()
{
	static int doneinit = 0;

	if (!doneinit) {
		initscr();
		doneinit++;
	}
	clear();
	refresh();
}
