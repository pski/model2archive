/*	xcmalt.h
	patchlevel 2.6 -- JPRadley
	This file uses 4-character tabstops
*/

#define SOH		0x1		/* ^A */
#define ETX		0x3		/* ^C */
#define EOT		0x4		/* ^D */
#define ENQ		0x5		/* ^E */
#define ACK		0x6		/* ^F */
#define DLE		0x10	/* ^P */
#define XON		0x11	/* ^Q */
#define XOFF	0x13	/* ^S */
#define NAK	 	0x15	/* ^U */
#define CAN		0x18	/* ^X */

#define ESCAPE_CHR	01		/* control-A */
#define ESC_STR	 "Ctrl-A"	/* How ESCAPE_CHR is shown in on-line help */

#define	CAPTFILE	"capture.log"	/* Default capture file */
#define PHFILE		".phonelist"	/* Default phonelist file */
#define STARTUP		".xcmalt"		/* XCMALT Startup Script */
#define LIBDIR		"/usr/local/lib/xcmalt"		/* System wide storage of dot-files */
#define INIT_BAUD	B2400			/* Default start-up rate */

#define DUP2	1					/* 0 if dup2() not available */
#define	STRSTR	0					/* 0 if strstr() not available */
#define MEMSET	1					/* 0 if memset() not available */
#define STRDUP	1					/* 0 if strdup() not available */
#define NAP		1					/* 0 if nap() not available */
#ifdef NAP
#define NAP_TIMER 1120				/* see timer.c for a proper value here */
#endif

#define	DTR_DROPS_CARRIER	0		/* Dropping DTR drops carrier */

/*
    Some Berkely and Xenix systems have index() and rindex() which are
    functionally identical to the more standard strchr() and strrchr()
    functions.  Include these defines if your Unix supports index and
    rindex INSTEAD of strchr and strrchr.
*/
/* #define strchr           index		/* for SYSV */
/* #define strrchr          rindex		/* for SYSV */

/* Other defines */

#ifndef TRUE
#define TRUE    1
#define FALSE   0
#define Success	  1
#define Failure   0
#endif

#define SM_BUFF  256				/* small buffer */
#define LG_BUFF 1024				/* large buffer */
#define S	show(1,Msg)
#define S2	show(2,Msg)

#ifdef DEBUG
#define fprintf Fprintf
#define fputc Fputc
#endif

/* globals */

extern int		cbaud, bitmask, tfd;
extern short	badline, captflag, capture, cismode, crcheck, dd_done,
				eof_flag, flowflag, hdplxflag, LI, linkflag, autoflag,
				nlmode, reterm, scriptflag, verbose;
extern char captfile[], phonefile[], *mport(), word[], *wptr, line[], Msg[],
			*lptr, Name[], *getenv(), *strstr(), *strcpy(), *strncat(),
			*strchr(), *strrchr(), *strdup();

extern void	exit(), free(), divert(), show(), show_abort(),
			drawline(), xc_setflow();

extern FILE *tfp,			/* the local terminal */
            *openfile(), *QueryCreate();

extern struct termio newmode, sigmode;
