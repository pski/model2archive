/*	Program	xcscrpt.c	Script handler for xcomm
	patchlevel 2.6 -- JPRadley
	This file uses 4-character tabstops
	Author: larry gensch, ESQ December 4, 1987
	This code is released to the public domain
*/

#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include <ctype.h>
#include <signal.h>
#include <setjmp.h>
#include "xcmalt.h"

#define	MAX_PATH	256
#define	MAX_LINE	128

static double waitfor_time = 0;

FILE *cf;

short tty_flag,
	echo_flag = FALSE,
	captflag = FALSE,
	linkflag = FALSE,
	scriptflag = FALSE,
	mrbstart,			/* ring buffer start pointer */
	mrbcount;			/* ring buffer counter */

jmp_buf here;

char mringbuf[LG_BUFF];	/* ring buffer for modem input */

void newsigint()
{
	signal(SIGINT, SIG_IGN);

	eof_flag = 1;
	show_abort();
	S_bombout();
	longjmp(here,1);
}

void do_script(file)
char *file;
{
	int quiet = 0;
	extern int unsetall();

	if (linkflag == 2){
		quiet = 1;
		linkflag = 0;
	}

	if (!quiet)
		sprintf(Msg,"RUNNING %s", file),
		S2;

	captflag = FALSE;
	tty_flag = TRUE;
	scriptflag = TRUE;

	eof_flag = 0;

	if (setjmp(here) == 0){
		signal(SIGINT, newsigint);
		intdel(TRUE);
		S_call(file);
	}
	unsetall();
	if (captflag)
		fclose(cf);

	if (!quiet)
		sprintf(Msg,"%s COMPLETE", file),
		S2;

	linkflag = 0;
	scriptflag = 0;

	signal(SIGINT, SIG_IGN);
	intdel(FALSE);

	return;
}

k_seen(bytes,fword)
long int bytes;
char *fword;
{
	int i, j, k;
	char *cptr;

	cptr = fword;

	if (!fword || !*fword){
		show(2,"No argument to SEEN command");
		return -1;
	}
	j = mrbstart - 1;
	if (bytes<=0 || bytes>LG_BUFF)
		bytes = LG_BUFF;
	k = mrbcount - bytes;	/* check only most recent 'bytes' bytes */
	i = 0;
	while ((i++)<mrbcount){
		++j;
		j = j % LG_BUFF;
		if (i<k)
			continue;
		if (mringbuf[j] != *cptr){
			cptr = fword;
			continue;
		}
		if (*(++cptr)=='\0')
			return 0;
	}
	return -1;
}

static char wf[MAX_LINE];

k_waitfor(interval,fword)
long int interval;
char *fword;
{
	int i;
	double t;
	int c;
	char *ptr = wf;
	extern void s_cis();

	mrbstart = mrbcount = 0;
	i = (-1);
	lptr = line;
	strcpy(line,fword);
	strcpy(word,fword);
	strcpy(wf,fword);
	lc_word(wf);

	if (interval == -2){
		waitfor_time = 0.2;
		goto SPITOUT;
	}
	if (!word || word[0] == '\0'){
		show(2,"No argument to WAITFOR command");
		return -1;
	}

	waitfor_time = ((interval > 0) ? interval : 30);
	eof_flag = 0;

SPITOUT: t = (double)(time(0L) + waitfor_time);

	while (t >= time(0L) && !eof_flag){

		if ((c = read_mbyte(1)) == -1)
			continue;

		if (cismode && c==ENQ){
			s_cis();
			goto SPITOUT;
		}

		++i;
		i = i % LG_BUFF;
		mringbuf[i] = c;
		mrbstart = mrbstart % LG_BUFF;
		if (mrbcount<LG_BUFF)
			++mrbcount;
		else {
			++mrbstart;
			mrbstart = mrbstart % LG_BUFF;
		}

		if (tty_flag)
			fputc(c,tfp);

		if (captflag && c != '\r')
			fputc(c,cf);

		if (mklow(c) != *ptr){
			ptr = wf;
			continue;
		}

		if (*++ptr == '\0')
			return 0;
	}
	return -1;
}

k_transmit(junk,fword)
long int junk;
char *fword;
{
	sprintf(line,"\"%s\"",fword);
	lptr = line;
	getword();
	if (!fword || fword[0] == '\0'){
		show(2,"No argument to TRANSMIT command");
		return -1;
	}
	send_slowly(word);
	return 0;
}

k_pause(pause_time,junk)
long int pause_time;
char *junk;
{
	pause_time = pause_time ? pause_time : 5;
	sleep((unsigned)pause_time);
	return 0;
}

k_dial(junk,fword)
long int junk;
char *fword;
{
	sprintf(line,"%s",fword);
	lptr = line;
	getword();
	if (!word || word[0] == '\0'){
		show(2,"DIAL command must have an argument");
		return -1;
	}
	dial(word);
	return 0;
}

k_capture(junk,fword)
long int junk;
char *fword;
{
	int val = captflag;

	sprintf(word,"capture");
	sprintf(line,"%s",fword);
	lptr = line;
	set_onoff(&captflag);

	if (val == captflag)
		return 0;

	if (captflag == 0)
		fclose(cf);
	else {
		if ((cf = fopen(captfile, "a")) == NULL){
			sprintf(Msg,"Cannot open capture file %s",captfile);
			S2;
			eof_flag++;
			return -1;
		}
	}
	return 0;
}

k_echo(junk,fword)
long int junk;
char *fword;
{
	sprintf(word,"echo");
	sprintf(line,"%s",fword);
	lptr = line;
	set_onoff(&echo_flag);
	return 0;
}

k_tty(junk,fword)
long int junk;
char *fword;
{
	sprintf(word,"tty");
	sprintf(line,"%s",fword);
	lptr = line;
	set_onoff(&tty_flag);
	return 0;
}

k_type(junk,fword)
long int junk;
char *fword;
{
	sprintf(line,"%s",fword);
	lptr = line;
	getword();
	if (!word || word[0] == '\0'){
		show(2,"TYPE command must have an argument");
		return -1;
	}
	(void) divert(TRUE);
	return 0;
}

k_beep()
{
	putc(7,tfp);
}

k_linked()
{
	return(!!(linkflag) - 1);
}

k_exit()
{
	s_exit();
}
