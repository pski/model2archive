/*	xcsubs.c	XCMALT Subroutines
	patchlevel 2.6 -- JPRadley
	This file uses 4-character tabstops
*/

#include <stdio.h>
#include <sys/types.h>
#include <ctype.h>
#include <signal.h>
#include <termio.h>
#ifdef T6000
#include <sys/ioctl.h>
#endif
#include <setjmp.h>
#include "xcmalt.h"

extern jmp_buf erret;

char line[SM_BUFF],	/* Input line */
     word[SM_BUFF],	/* Parsed word */
     *wptr, *lptr,	/* Word and line pointers */
	 *tgetstr(),
	 *tgoto();

short eof_flag,		/* Indicates EOF during getline() processing */
      LI,		/* Derived from screen length in termcap entry */
	  ospeed;

static char tc[LG_BUFF],	/* termcap buffer */
			tbuf[LG_BUFF], PC, *CD, *CE, *CF, *CL, *CM, *CN, *SO, *SE;

#define Tgetstr(code) ((s = tgetstr(code,&p)) ? s : "")

#if	!STRSTR
/*	Find first occurence of str2 in str1 and return a pointer to it */
char *strstr(str1, str2)
char *str1, *str2;
{
	register char *Sptr, *Tptr;
	int len = strlen(str1) -strlen(str2) + 1;

	if (*str2)
		for (; len > 0; len--, str1++) {
			if (*str1 != *str2)
				continue;

			for (Sptr = str1, Tptr = str2; *Tptr != '\0'; Sptr++, Tptr++)
				if (*Sptr != *Tptr)
					break;

			if (*Tptr == '\0')
				return str1;
		}

	return NULL;
}
#endif

#if !DUP2		/* For those that do not have dup2() */
#include <fcntl.h>
dup2(oldfd, newfd)
int oldfd, newfd;
{
if (fcntl(oldfd, F_GETFL, 0) == -1)     /* Valid file descriptor? */
		return (-1);                    /* No, return an error. */
	close(newfd);                           /* Ensure newfd is closed */
	return (fcntl(oldfd, F_DUPFD, newfd));  /* Dup oldfd into newfd */
}
#endif /* !DUP2  Thanks to Bill Allie CIS: 76703,2061 */

#if !STRDUP	/* For those that do not have strdup() */
char *strdup(s)
char *s;
{
	return strcpy((char *)malloc(strlen(s)+1), s);
}
#endif

#if !MEMSET		/* For those that do not have memset() */
char *memset(dst, chr, len)
char *dst;
register chr;
register len;
{
	char *d;
	for (d = dst; --len >= 0; *d++ = chr)
		;
	return dst;
}
#endif

#if !NAP		/* For those that do not have nap() */
#ifdef BSD
nap(t)
register t;
{
	usleep(1000 * (t));
}
#else
nap(t)	/* a hack */
register t;
{
	t= t*NAP_TIMER; 
	while (t--)
		;
}
#endif
#endif

void sendstr(p)       /* send a string to the port */
char *p;
{
	while (*p)
		send_mbyte(*p++);
}

/*	Do the fork call, packaging the error return so that the caller
	need not have code for it.
*/
forkem()
{
	int i;

	if ((i = fork()) < 0) {
		show(1,"XCMALT: Fork failed");
		longjmp(erret,1);
	}
	return(i);
}

/*	Throw away all input characters until no more are sent.  */
void purge()
{
	while (readbyte(1) != -1)
		;
}

/*	This is a line input routine to be used
	when the raw terminal mode is in effect.
*/
void getline()
{
	int c, i = 0;

	lptr = line;
	memset(line, 0, SM_BUFF);

	while ((c = coninp()) != '\r' && c != '\n') {
		if (c == '\b') {
			if (i > 0) {
				i--;
				fprintf(tfp, "\b \b");
			} else
				putc(7,tfp);
			continue;
		}
		line[i++] = c;
		fputc(c, tfp);
	}
	fputc(' ', tfp);
}

/*	Parse the "line" array for a word */
void getword()
{
	char quote, *ptr = word;
	short carat = FALSE, backslash = FALSE;

	wptr = lptr;
	memset(word, 0, SM_BUFF);

	while (isspace(*lptr))
		lptr++;

	if (*lptr == '\0')
		return;

	if (*lptr == '\'' || *lptr == '\"')
		quote = *lptr++;
	else
		quote = '\0';

	for (; *lptr != '\0'; lptr++) {
		if (quote) {
			if (*lptr == '\0') {
				word[0] = '\0';
				sprintf(1,"Unmatched quote: %s", line);
				S;
				kill(getpid(),1);
				return;
			}
			if (*lptr == quote)
				break;
		} else if (!backslash && isspace(*lptr))
			break;

		if (carat)
			*ptr++ = *lptr & 0x1f,
			carat = FALSE;
		else if (backslash)
			*ptr++ = *lptr,
			backslash = FALSE;
		else if (*lptr == '^')
			carat = TRUE;
		else if (*lptr == '\\')
			backslash = TRUE;
		else
			*ptr++ = *lptr;
	}

	lptr++;
}

/*	Make the specified word all lower case */
void lc_word(ptr)
char *ptr;
{
	while (*ptr) {
		*ptr = mklow(*ptr);
		ptr++;
	}
}

static void alrm()
{  /* do nothing */
}

/*	trminp() is used as a single-character terminal input routine */
trminp(fd, seconds)
int fd, seconds;
{
	static int count = 0;
	static char *p, rxbuf[LG_BUFF];
	unsigned alarm();

	if (count > 0) {
		count--;
		return(*p++ & 0xff);
	}
	if (seconds > 0) {
		signal(SIGALRM, alrm);
		alarm((unsigned)seconds);
	}
	if ((count  = read(fd, p = rxbuf, LG_BUFF)) < 1)
		return(-1);
	if (seconds > 0)
		alarm(0);
	count--;
	return(*p++ & 0xff);
}

/*	coninp() gets a single character from the local terminal */
coninp()
{
	int c;

	while ((c = trminp(tfd, 0)) == -1)
		;

	return c;
}

void intdel(flag)
{
	if (flag)
		ioctl(tfd, TCSETAW, &sigmode);
	else
		ioctl(tfd, TCSETAW, &newmode);
}

/*	get_ttype()
	initialize termcap stuff
	returns: 0 (SUCCESS) or -1 (ERROR)
*/
get_ttype()
{
	char *ttytype;
	char *p = tbuf;
	char *s;

	if ((ttytype = getenv("TERM")) == NULL) {
		show(1,"TERM not set");
		return(-1);
	}
	if (tgetent(tc, ttytype) != 1) {
		sprintf(Msg,"Can't load %s", ttytype);
		S;
		return(-1);
	}
	ospeed = newmode.c_cflag & CBAUD;
	LI = tgetnum("li") - 1;
	if ((s=tgetstr("pc")) == NULL)
		PC = '\0';
	else
		PC = *s;
	CD = Tgetstr("cd");
	CE = Tgetstr("ce");
	CL = Tgetstr("cl");
	CM = Tgetstr("cm");
	SE = Tgetstr("se");
	SO = Tgetstr("so");
	CF = Tgetstr("CF");
	CN = Tgetstr("CN");
	
	return(0);
}

/*	putchr() is a routine to pass to tputs() */
void putchr(c)
int c;
{
	putc(c,tfp);
}

void cls()		{ tputs(CL,LI,putchr); }

void cur_on()	{ tputs(CN,1,putchr); }

void cur_off()	{ tputs(CF,1,putchr); }

void cl_line()	{ tputs(CE,1,putchr); }

void cl_end()	{ tputs(CD,LI,putchr); }

void ttgoto(row, col)
int row, col;
{
	tputs(tgoto(CM, col, row),1,putchr);
}

void drawline(row, col, len)
int row, col, len;
{

	ttgoto(row, col);
	while (len--)
		fputc('-', tfp);
}

void show(flag, str)
short flag;
char *str;
{
	if (!flag) {
		k_beep();
		ttgoto(LI,0);
		cl_line();
		ttgoto(LI,(80-strlen(str))/2 -1);
	}
	if (flag == 2)
		putc('\n', tfp);
	tputs(SO,1,putchr);
	putc(' ',tfp);
	fprintf(tfp, str);
	putc(' ',tfp);
	tputs(SE,1,putchr);
	if (flag > 0)
		putc('\n',tfp);
}

void show_abort()
{
	show(2, "USER ABORT");
}

/*	dgetch()
	fetch a "hot key"
	returns: (int)
*/
dgetch()
{
	char c;
	struct	termio oldt, t;

	ioctl(tfd, TCGETA, &oldt);
	t = oldt;
	t.c_lflag &= ~ICANON;	/* turn off canonicalization */
	t.c_lflag &= ~ECHO;		/* turn off echo */
	t.c_lflag &= ~ISIG;		/* turn off signal processing */
	t.c_cc[VMIN] = 1;		/* single-character I/O */
	ioctl(tfd, TCSETAW, &t);

	read(tfd, &c, 1);

	ioctl(tfd, TCSETAW, &oldt);
	return((int)c);
}

FILE *openfile(name)
char *name;
{
	FILE *fp;
	char *home, fullname[SM_BUFF];

	fp = fopen(name, "r");

	if (fp == NULL) {
		if ((home=(char *)getenv("HOME")) != NULL) {
			sprintf(fullname, "%s/%s", home, name);
			fp = fopen(fullname, "r");
		}
	}

	if (fp == NULL) {
		sprintf(fullname, "%s/%s", LIBDIR, name);
		fp = fopen(fullname, "r");
	}
	return fp;
}

/* Convert uppercase characters to lowercase, (without
 * mangling non-uppercase characters), in a portable manner.
 */
mklow(c)
int c;
{
    if(isupper(c))
        return(tolower(c));
    return(c);
}

/* Vice-versa */
mkhigh(c)
int c;
{
	if(islower(c))
		return(toupper(c));
	return(c);
}
