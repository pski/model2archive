/*	xcterm.c		XCMALT terminal mode
	patchlevel 2.6 -- JPRadley
	This file uses 4-character tabstops
*/
#include <stdio.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <setjmp.h>
#include <sys/stat.h>
#include "xcmalt.h"

#define ENDCHAR		(('X' & 0x1f) + 128)	/* Exit terminal mode */
#define TOGCHAR		(('T' & 0x1f) + 128)	/* Toggle capture buffer */
#define DIVCHAR		(('F' & 0x1f) + 128)	/* Send file through modem */
#define DIALCHR		(('D' & 0x1f) + 128)	/* Dial from phonelist */
#define HUPCHAR		(('H' & 0x1f) + 128)	/* Hang up modem */
#define	SCRPCHR		(('S' & 0x1f) + 128)	/* Execute script file */
#define	BRKCHAR		(('B' & 0x1f) + 128)	/* modem BREAK character */

char captfile[SM_BUFF] = CAPTFILE,	/* capture file's name */
	 phonefile[SM_BUFF] = PHFILE;	/* phone number file's name */

static FILE	*cfp,			/* capture file pointer */
			*fp;			/* file to transmit */

static int	child_pid; 		/* ID of child process */
static void (*oldvec)();
static short doneyet_dd, s_flag;
static jmp_buf rtm, stop;
static char	ddsname[SM_BUFF];

short capture = FALSE;
void toggle(), cleanup(), newbmask(), cisbmode(), hangup();

extern char *strstr();

void terminal(todir)
short todir;
{
	int c;

	doneyet_dd = FALSE;
	intdel(FALSE);
Reterm:
	setjmp(rtm);

	if (cismode > 1 || doneyet_dd) {
		if (doneyet_dd)
			doneyet_dd = FALSE;
		return;
	}

	s_flag = FALSE;		/* reset scripting flag */

	if (!todir)
		show(2,"Entering Terminal Mode");
	/* split into read and write processes */
	if ((child_pid = forkem()) == 0) {
		/* child, read proc: read from port and write to tty */
		cfp = NULL;
		if (autoflag && !todir)
			toggle();
		signal(SIGUSR2, toggle);
		signal(SIGTERM, cleanup);
		signal(SIGUSR1, newbmask);
		while (1) {
			while ((c = read_mbyte(0)) == -1)
				;
			if (cismode && c == ENQ) {
				cismode = 2;
				cleanup();
			}
			fputc(c,tfp);
			if (capture && c != '\r')
				fputc(c,cfp);
		}
		/*NOTREACHED*/
	}
	/* parent, write proc: read from tty and write to port */
	signal(SIGCLD, cisbmode);

	if (todir) goto dialdir;
	do {
		switch (c = getconchr()) {
		case TOGCHAR:		/* signal child to toggle buffer */
			kill(child_pid, SIGUSR2);
			break;

		case DIVCHAR:		/* divert a file through modem port */
			intdel(TRUE);
			(void) divert(FALSE);
			intdel(FALSE);
			break;

		case BRKCHAR:
			k_xmitbrk();
			break;

		case SCRPCHR:		/* execute a script file */
			if (get_script()==Failure)
				break;
			s_flag = TRUE;
			goto fillicide;

		case DIALCHR:		/* select and dial a phone number */
dialdir:
			doneyet_dd = dd_done = TRUE;
			if ((dial_dir()==Failure && todir) || s_flag)
				goto fillicide;
			break;

		case ENDCHAR:		/* signal child to cleanup and exit */
fillicide:
			c = ENDCHAR;
			signal(SIGCLD, SIG_IGN);
			kill(child_pid, SIGTERM);
			break;

		case HUPCHAR:		/* Hangup */
			hangup();
			break;

		case '\n':		/* See if NL translation in effect */
			if (nlmode)
				c = '\r';

		default:	/* just send the character to the port */
			send_mbyte(c);
			if (hdplxflag) {
				fputc(c,tfp);
				rewind(tfp);
			}
			break;
		}
	} while (c != ENDCHAR);

	dd_done = !s_flag;

	while (wait((int *) 0) >= 0)	/* wait for the read process to die */
		;

	if (s_flag) {
		do_script(ddsname);
		if (!dd_done)
			goto Reterm;
	}

	if (!dd_done)
		show(2,"Leaving Terminal Mode");
}

static void cisbmode()
{
	cismode = 2;
	signal(SIGCLD, SIG_IGN);

	longjmp(rtm,1);
}

/*	The next three functions are only run by the port read process (child).
	They handle the capture file.
*/

/* toggle capture status */
void toggle()
{
	if (capture) {
		fclose(cfp);
		capture = FALSE;
		sprintf(Msg,"\"%s\" CLOSED for CAPTURING", captfile);
		S2;
	} else {
		if ((cfp = fopen(captfile, "a")) == NULL) {
			sprintf(Msg,"CAN'T OPEN \"%s\" for CAPTURING", captfile);
			S2;
		} else {
			capture = TRUE;
			sprintf(Msg,"CAPTURING to \"%s\"", captfile);
			S2;
		}
	}
	sleep(1);

	signal(SIGUSR2, toggle);	/* set signal for next toggle */
}

/*	cleanup, flush and exit */
static void cleanup()
{
	if (capture) {
		fclose(cfp);
		sprintf(Msg,"\"%s\" CLOSED for CAPTURING", captfile);
		S2;
	}

	exit(0);
}

void newbmask()
{
	if (bitmask == 0xff)
		bitmask = 0x7f;
	else
		bitmask = 0xff;

	if (child_pid)
		kill(child_pid, SIGUSR1);
}

/*	Select a script file. If the file exists, execute it, otherwise
	exit with a non-zero return.
*/
get_script()
{
	putc('\n', tfp);
	show(-1,"Enter script file:");
	getline();
	if (line[0] == '\0') {
		putc('\n', tfp);
		show(1,"Script file not specified");
		return Failure;
	}
	linkflag = FALSE;
	getword();
	sprintf(ddsname,"%s",word);
	return Success;
}

void end_divert()
{
	show_abort();
	fseek(tfp,0L,1);
	fclose(fp);
	signal(SIGINT, oldvec);
	longjmp(stop,1);
}

/*	Divert file into input stream, with delay after each newline. */
void divert(script)
short script;
{
	int c, i = 0;

	if (!script) {
		putc('\n', tfp);
		show(-1,"File?");
		rewind(tfp);
		getline();
		getword();
	}
	fseek(tfp,0L,1);
	if (word[0] == '\0')
		return;
	if ((fp = fopen(word, "r")) == NULL) {
		sprintf(Msg,"Cannot access '%s'", word);
		S2;
		return;
	}

	oldvec = signal(SIGINT,end_divert);
	if (setjmp(stop))
		return;

	while ((c = getc(fp)) != EOF) {
		if (c != '\n') {
			send_mbyte(c);
			i++;
		}
		else {
			send_mbyte('\r');
			if (script)
				k_waitfor(-2, "");
			else
				nap (400 + 10 * i);
			i = 0;
		}
	}
	fclose(fp);
	signal(SIGINT,oldvec);
}

void dialbuf(buf)
char *buf;
{
	char *s, *t, *nbr;

	if (s = strstr(buf, "BPS=")) {
		s += 4;
		if (mrate(s) < 0) {
			show(0,"Invalid BPS=");
			return;
		}
	}
	if (s = strstr(buf, "BITS=")) {
		s += 5;
		switch (*s) {
			case '7':
				if (bitmask == 0xff)
					newbmask();
				break;
			case '8':
				if (bitmask == 0x7f)
					newbmask();
				break;
			default:
				show(0,"Invalid BITS=");
				return;
		}
	}

	cls();
	if ((s = strstr(buf, "PREFIX=")) != NULL) {
		s += 7;
		send_slowly("\r");
		send_slowly(s);
		send_slowly("\r");
		s -= 7;
		*s = '\0';
		sleep(1);
	}
	else
		buf[strlen(buf)-1] = '\0';

	sprintf(Msg,"Calling %s", buf);
	S;

	dd_done = TRUE;

	while (isspace(*buf) && *buf)
		buf++;

	if (!(*buf))
		return;

	for (nbr = buf; !isspace(*buf) && *buf; buf++)
		;

	*buf = '\0';
	intdel(TRUE);
	dial(nbr);

	if (s = strstr(++buf, "SCRIPT=")) {
		s += 7;
		t = s;
		while (!isspace(*t) && *t != '\0')
			t++;
		*t = '\0';
		sprintf(ddsname,"%s",s);
		s_flag = 1;
		linkflag = TRUE;
	}
}
 
getconchr()
{
	int c, tc;

	if ((c = coninp()) == ESCAPE_CHR) {
		switch (c = ((tc = coninp()) & 0x1f) + 128) {
		case ENDCHAR:
		case TOGCHAR:
		case BRKCHAR:
		case DIVCHAR:
		case DIALCHR:
		case HUPCHAR:
		case SCRPCHR:
			break;

		default:
			c = tc;
		}
	}
	return c;
}
