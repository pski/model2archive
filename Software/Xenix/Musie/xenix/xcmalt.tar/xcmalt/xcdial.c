/*	xcdial.c	- nicer dialing directory for Larry Gensch's XCOMM
	This file uses 4-character tabstops
	Author: Steve Manes 8/26/88
	patchlevel 2.6 -- JPRadley
 */

#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include "xcmalt.h"

#define	MAXNAME		27	/* maximum display for system name */
#define	MAXNUMBER	20	/*	  "		  "		"  phone number */
#define	MAXPROTOCOL	 9	/*	  "		  "		"  protocol string */
#define	MAXSCRIPT	14	/*	  "		  "		"  script name */

static	FILE *dirf;
static	short pages[60],	/* these keep track of where we are in menu */
		dirnum, thispage, hipage, lastpage;

void showentry(), scroll_dir();

dial_dir()
{
	int i, c;
	char buff[5], f[30];

	if ((dirf = openfile(phonefile)) == NULL) {
		sprintf(Msg,"Phonelist '%s' not found", phonefile);
		S;
		return(Failure);
	}

	dirnum = thispage = hipage = 0;
	lastpage = -1;
	cls();
	drawline(0, 0, 80);
	ttgoto(1, 23);
	show(-1," D I A L I N G   D I R E C T O R Y ");
	drawline(2, 0, 80);
	ttgoto(3, 0);
	sprintf(f,"     %%-%ds %%%ds %%%ds %%-%ds%*s\n",
		MAXNAME, MAXNUMBER, MAXPROTOCOL, MAXSCRIPT,
		80-MAXNAME-MAXNUMBER-MAXPROTOCOL-MAXSCRIPT-8, "");
	sprintf(Msg, f, "NAME", "NUMBER", "PROTOCOL", "SCRIPT");
	show(-1,Msg);
	scroll_dir();
	while (1) {
		ttgoto(LI-1, 0);
		fprintf(tfp,
		"==>     [#] Dial Entry   [M]anual Dial   [X]it   [N]ext   [P]revious");
		ttgoto(LI-1, 4);
		while (1) {
			c = dgetch();
			if (c == '\b')
				continue;
			if (c == 'n' || c == 'N' || c == '\n' || c == ' ') {
				if (thispage > (int)((1000/(LI-6))-1) || thispage == lastpage)
					show(0,"Last page");
				else
					thispage++,
					scroll_dir();
				break;
			}
			else if (c == 'p' || c == 'P' && dirnum > 1) {
				if (thispage == 0)
					show(0,"First page");
				else
					thispage--,
					fseek(dirf, pages[thispage], 0),
					scroll_dir();
				break;
			}
			else if (c == 'x' || c == 'X') {
				cls();
				fclose(dirf);
				return(Failure);
			}
			else if (c == 'm' || c == 'M') {
				if (man_dial()) {
					fclose(dirf);
					reterm = TRUE;
					return(Success);
				}
				reterm = FALSE;
				break;
			}
			else if (isdigit(c)) {
				buff[0] = c;
				fseek(tfp,0L,1);
				fputc(c,tfp);
				for (i=1; i<4; ++i) {
					fseek(tfp,0L,1);
					buff[i] = fgetc(tfp);
					if (buff[i]=='\b') {
						if (i>0)
							rewind(tfp),
							fprintf(tfp,"\b \b"),
							i -= 2;
						else
							i = -1;
						continue;
					}
					fseek(tfp,0L,1);
					fputc(buff[i],tfp);
					if (buff[i]=='\n' || buff[i]=='\r')
						break;
				}
				if (i == 0) {
					reterm = FALSE;
					dd_done = FALSE;
					break;
				}
				buff[++i] = '\0';
				reterm = TRUE;
				dd_done = TRUE;
				if (dial_entry( atoi(buff))) {
					fclose(dirf);
					return(Success);
				}
				else
					break;
			}
		}
	}
}

/*	scroll_dir()
	scroll directory at current filepos
*/
static void scroll_dir()
{
	short i;
	char buff[121];
	long fpos;

	ttgoto(4, 0);
	cur_off();
	cl_end();

	fpos = ftell(dirf);
	dirnum = thispage * (LI - 6);
	for (i=0; i < LI - 6; i++) {
		if (fgets(buff, 120, dirf) == NULL) {
			fseek(dirf, thispage, 0);
			lastpage = thispage;
			break;
		}
		showentry(++dirnum, buff);
	}
	if (thispage == hipage)
		pages[++hipage] = fpos;
	cur_on();
}

/*	showentry(dirnum, entry)
	show a single, formatted dialdir entry.
	check its format integrity as we go
*/
static void showentry(choice, entry)
short choice;
char *entry;
{
	char name[MAXNAME +1], num[MAXNUMBER +1], f[30],
		protocol[MAXPROTOCOL +1], script[MAXSCRIPT +1];
	char *s;
	short i, j = 0;

	s = entry;

	/* get phone number */
	while (isspace(*s))
		s++;

	for (i=0; i < MAXNUMBER && !isspace(*s); i++)
		num[j++] = *s++;
	num[j] = '\0';

	/* get name */
	while (!isspace(*s))
		s++;
	while (isspace(*s))
		s++;
	j=0;
	for (i=0; i < MAXNAME && *s != '\t'; i++)
		name[j++] = *s++;
	name[j] = '\0';
	s = strchr(name,'\n');
	if (s)
		*s = '\0';

	/* get protocol */
	if (s = strstr(entry, "BPS=")) {
		s += 4;
		j=0;
		for (i=0; i < 6 && isdigit(*s); i++)
			protocol[j++] = *s++;
		protocol[j] = '\0';
		strcat(protocol, "/");
	}
	else
		sprintf(protocol,"????/");

	if (s = strstr(entry, "BITS=")) {
		s += 5;
		switch (*s) {
			case '7':
				strcat(protocol, "7/");
				break;
			case '8':
				strcat(protocol, "8/");
				break;
			default:
				k_beep();
				sprintf(Msg,"Invalid BITS= for '%s'", name);
				S;
				strcat(protocol,"8/N");
				return;
		}
	}
	else
		strcat(protocol,"?/");

	if (*s == '7')
		strcat(protocol, "E");
	else
		strcat(protocol, "N");

	if (s = strstr(entry, "SCRIPT=")) {
		s += 7;
		j=0;
		for (i=0; i < MAXSCRIPT && !isspace(*s); i++)
			script[j++] = *s++;
		script[j] = '\0';

	}
	else
		script[0] = '\0';

	sprintf(f,"%%3d - %%-%ds %%%ds %%%ds %%-%ds\n",
		MAXNAME, MAXNUMBER, MAXPROTOCOL, MAXSCRIPT);
	fprintf(tfp, f, choice, name, num, protocol, script);
}

static dial_entry(choice)
short choice;
{
	char buff[121];

	if (choice == 0)
		return(Failure);
	rewind(dirf);
	while (choice--) {
		if (fgets(buff, 120, dirf) == NULL) {
			show(0,"Nonexistent entry");
			return(Failure);
		}
	}
	dialbuf(buff);
	return(Success);
}

static man_dial()
{
	short i;
	char buff[128];

	fseek(tfp,0L,1);
	ttgoto(LI-1, 0);
	cl_end();
	fprintf(tfp,"Number to dial: ");
	for (i=0; i<40; ++i) {
		fseek(tfp,0L,1);
		buff[i] = fgetc(tfp);
		fseek(tfp,0L,1);
		if (buff[i]!='\b')
			fputc(buff[i],tfp);
		else {
			if (i>0)
				fprintf(tfp,"\b \b"),
				i -= 2;
			else
				i = -1;
			continue;
		}
		if (buff[i]=='\n' || buff[i]=='\r') {
			if (!i)
				return(Failure);
			else
				break;
			}
	}
	buff[++i] = '\0';
	dialbuf(buff);
	return(Success);
}
