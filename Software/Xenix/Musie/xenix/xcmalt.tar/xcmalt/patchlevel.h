static char version[]="@(#)XCMALT 2.6 JPRadley 29 Apr 90";
