/*	xcxmdm.c	XMODEM Protocol Module
	patchlevel 2.6 -- JPRadley
	This source code is purely public domain
	This file uses 4-character tabstops
*/
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <setjmp.h>
#include "xcmalt.h"

#define CPMEOF	032	/* ^Z */
#define WANTCRC 'C'
#define OK		 0
#define TIMEOUT	-1	 /* -1 is returned by readbyte() upon timeout */
#define ERROR	-2
#define WCEOT	-3
#define RETRYMAX 10
#define SECSIZ  128

short badline = FALSE;	/* bad telephone line? */
	  /*crcheck = TRUE;	/* CRC check enabled?  */

static FILE *xfp;				/* buffered file pointer */
static short firstsec,			/* first sector of file or not? */
			textmode;			/* Text translations enabled? */
			/*save_crc*/;			/* Saved crcheck value */

static char wcbuff[SECSIZ];		/* Ward Christensen sector buffer */

static unsigned short Updcrc();
static void xmsigint();		/* Our SIGINT handler */
static jmp_buf our_env;

/*	send 10 CAN's to try to get the other end to shut up */
static void canit()
{
	int i;

	for(i = 0; i < 20; i++)
		sendbyte(CAN);
}

void xreceive(c)
int c;
{
	xc_setflow(0);
	/*save_crc = crcheck;*/
	signal(SIGINT, xmsigint);

	if (setmode(c)) {
		if (setjmp (our_env) == 0) {
			/* crcheck = 0xff; */

			sprintf(Msg,"Ready to receive single file %s", word);
			S;
			if (wcrx() == ERROR)
				canit();
			return;
		}
	}

	signal(SIGINT, SIG_IGN);
	/*crcheck = save_crc;*/
	intdel(FALSE);
	xc_setflow(flowflag);
}

void xsend(c)
int c;
{
	xc_setflow(0);
	/*save_crc = crcheck;*/
	signal(SIGINT, xmsigint);

	if (setmode(c)) {
		if (setjmp (our_env) == 0) {
			/* crcheck = 0xff; */
			if (wctx() == ERROR) {
				sprintf(Msg,"Error transmitting file %s", word);
				S;
				return;
			}
		}
	}

	signal(SIGINT, SIG_IGN);
	/* crcheck = save_crc; */
	intdel(FALSE);
	xc_setflow(flowflag);
}

static void xmsigint()
{
	show_abort();
	signal(SIGINT, SIG_IGN);	/* Ignore subsequent DEL's */
	canit();					/* Abort the transmission */
	longjmp(our_env,1);
}

/* Receive a file using XMODEM protocol */
static wcrx()
{
	register sendchar, sectnum, sectcurr;
	int Result;

	strcpy(Name, word);
	if ((xfp=QueryCreate("w", 1, &Result)) == NULL)
		return(ERROR);

	firstsec = TRUE;
	sectnum = 0;
	sendchar = /*crcheck ?*/ WANTCRC /*: NAK*/;
	fputc('\n', tfp);
	show(1,"Sync...");

	while(TRUE) {
		if (badline)
			purge();
		sendbyte(sendchar);
		sectcurr = wcgetsec(6);
		if (sectcurr == ((sectnum + 1) & 0xff)) {
			sectnum++;
			putsec();
			fprintf(tfp,"Received sector #%d\r", sectnum);
			sendchar = ACK;
			continue;
		}

		if (sectcurr == (sectnum & 0xff)) {
			sprintf(Msg,"Received duplicate sector #%d", sectnum);
			S2;
			sendchar = ACK;
			continue;
		}

		fclose(xfp);

		if (sectcurr == WCEOT) {
			show(1,"File received OK");
			sendbyte(ACK);
			return(OK);
		}

		if (sectcurr == ERROR)
			return(ERROR);

		sprintf(Msg,"Sync error ... expected %d(%d), got %d",
			(sectnum + 1) & 0xff, sectnum, sectcurr);
		S;
		return(ERROR);
	}
}

/* Transmit a file using XMODEM protocol */
static wctx()
{
	register sectnum, eoflg, c, attempts;

	if ((xfp = fopen(word, "r")) == NULL) {
		sprintf(Msg,"Can't open `%s' for input", word);
		S;
		return(ERROR);
	}
	firstsec = TRUE;
	attempts = 0;
	show(1,"Sync...");

	while((c = readbyte(30)) != NAK && c != WANTCRC && c != CAN)
		if (c == TIMEOUT && ++attempts > RETRYMAX) {
			show(1,"Receiver not responding");
			fclose(xfp);
			return(ERROR);
		}
	if (c == CAN) {
		show(1,"Receiver CANcelled");
		fclose(xfp);
		return(ERROR);
	}
	/*crcheck = (c == WANTCRC);*/
	/*show(1,"%s error checking requested", crcheck ? "CRC check" : "Checksum");*/
	sectnum = 1;

	do {
		eoflg = getsec();
		fprintf(tfp,"Transmitting sector #%d\r", sectnum);

		if (wcputsec(sectnum) == ERROR) {
			fclose(xfp);
			return(ERROR);
		}
		sectnum++;
	} while(eoflg);

	fclose(xfp);
	attempts = 0;
	sendbyte(EOT);
	while(readbyte(5) != ACK && attempts++ < RETRYMAX)
		sendbyte(EOT);
	if (attempts >= RETRYMAX) {
		show(1,"Receiver not responding to completion");
		return(ERROR);
	}

	show(1,"Transmission complete");
	return(OK);
}

/*	wcgetsec() inputs an XMODEM "sector".
	This routine returns the sector number encountered, or ERROR if a valid
	sector is not received or CAN received; or WCEOT if EOT sector.

	Maxtime is the timeout for the first character, set to 6 seconds for
	retries.  No ACK is sent if the sector is received ok.  This must be
	done by the caller when it is ready to receive the next sector.
*/
static wcgetsec(maxtime)
int maxtime;
{
	register unsigned short oldcrc;
	register /*checksum,*/ j, c;
	int sectcurr, sectcomp, attempts;

	for(attempts = 0; attempts < RETRYMAX; attempts++) {
		do {
			c = readbyte(maxtime);
		} while(c != SOH && c != EOT && c != CAN && c != TIMEOUT);

		switch(c) {
		case SOH:
			sectcurr = readbyte(3);
			sectcomp = readbyte(3);
			if ((sectcurr + sectcomp) == 0xff) {
				oldcrc /*= checksum*/ = 0;
				for(j = 0; j < SECSIZ; j++) {
					if ((c = readbyte(3)) < 0)
						goto timeout;
					wcbuff[j] = c;
					/*if (crcheck)*/
						oldcrc = Updcrc(c, oldcrc);
					/*else
						checksum += c;*/
				}
				if ((c = readbyte(3)) < 0)
					goto timeout;
				/*if (crcheck) {*/
					oldcrc = Updcrc(c, oldcrc);
					if ((c = readbyte(3)) < 0)
						goto timeout;
					if (Updcrc(c, oldcrc)) {
						show(2,"CRC error");
						break;
					}
				/*}
				else if (((checksum - c) & 0xff) != 0) {
					show(2,"Checksum error");
					break;
				}*/
				firstsec = FALSE;
				return(sectcurr);
			}
			else
				sprintf(Msg,"Sector number garbled 0%03o 0%03o",
					sectcurr, sectcomp);
			S2;
			break;
		case EOT:
			if (readbyte(3) == TIMEOUT)
				return(WCEOT);
			break;
		case CAN:
			show(2,"Sender CANcelled");
			return(ERROR);
		case TIMEOUT:
			if (firstsec)
			break;
timeout:
		show(2,"Timeout");
		break;
		}
		show(2,"Trying again on this sector");
		purge();
		if (firstsec)
			sendbyte(/*crcheck ?*/ WANTCRC /*: NAK*/);
		else {
			maxtime = 6;
			sendbyte(NAK);
		}
	}
	show(2,"Retry count exceeded");
	canit();
	return(ERROR);
}

/*	wcputsec outputs a Ward Christensen type sector.
	it returns OK or ERROR
*/
static wcputsec(sectnum)
int sectnum;
{
	register unsigned short oldcrc;
	register /*checksum,*/ j, c, attempts;

	oldcrc /*= checksum*/ = 0;
	for(j = 0; j < SECSIZ; j++) {
		c = wcbuff[j];
		oldcrc = Updcrc(c, oldcrc);
		/*checksum += c;*/
	}
	oldcrc = Updcrc(0, Updcrc(0, oldcrc));

	for(attempts = 0; attempts < RETRYMAX; attempts++) {
		sendbyte(SOH);
		sendbyte(sectnum);
		sendbyte(-sectnum - 1);
		for(j = 0; j < SECSIZ; j++)
			sendbyte(wcbuff[j]);
		if (badline)
			purge();
		/*if (crcheck) {*/
			sendbyte((int) (oldcrc >> 8));
			sendbyte((int) oldcrc);
		/*}
		else
			sendbyte(checksum);*/
		switch(c = readbyte(10)) {
		case CAN:
			show(2,"Receiver CANcelled");
			return(ERROR);
		case ACK:
			firstsec = FALSE;
			return(OK);
		case NAK:
			show(2,"Got a NAK on sector acknowledge");
			break;
		case TIMEOUT:
			show(2,"Timeout on sector acknowledge");
			break;
		default:
			sprintf(Msg,"Got 0%03o for sector acknowledge", c);
			S2;
			do {
				if ((c = readbyte(3)) == CAN) {
					show(2,"Receiver CANcelled");
					return(ERROR);
				}
			} while(c != TIMEOUT);
			/*if (firstsec)
			crcheck = (c == WANTCRC);*/
			break;
		}
	}
	show(2,"Retry count exceeded");
	return(ERROR);
}

/*	update the cyclic redundancy check value */
static unsigned short Updcrc(c, crc)
register c;
register unsigned crc;
{
	int i;

	for(i = 0; i < 8; i++) {
		if (crc & 0x8000)
			crc <<= 1,
			crc += (((c <<= 1) & 0400) != 0),
			crc ^= 0x1021;
		else
			crc <<= 1,
			crc += (((c <<= 1) & 0400) != 0);
	}
	return(crc);
}

static setmode(c)
int c;
{
	intdel(TRUE);

	switch(mklow(c)) {
	case 't':
		textmode = TRUE;
		break;
	case 'b':
		textmode = FALSE;
	case ' ':
		break;

	default:
		return Failure;
	}

	sprintf(Msg,"XMODEM %s file transfer mode", textmode ? "Text" : "Binary");
	S;

	return Success;
}

/*	fill the CP/M sector buffer from the UNIX file
	do text adjustments if necessary
	return 1 if more sectors are to be read, or 0 if this is the last
*/
static getsec()
{
	int i;
	register c;

	i = 0;
	while(i < SECSIZ && (c = getc(xfp)) != EOF) {
		if (textmode && c == '\n') {
			wcbuff[i++] = '\r';
			if (i >= SECSIZ) {		  /* handle a newline on the last byte */
				ungetc(c, xfp);		 /* of the sector					 */
				return(1);
			}
		}
		wcbuff[i++] = c;
	}
	/* make sure that an extra blank sector is not sent */
	if (c != EOF && (c = getc(xfp)) != EOF) {
		ungetc(c, xfp);
		return(1);
	}
	/* fill up the last sector with ^Z's if text mode or 0's if binary mode */
	while(i < SECSIZ)
		wcbuff[i++] = textmode ? CPMEOF : '\0';
	return(0);
}

/*	Put received WC sector into a UNIX file
	using text translations if neccesary.
*/

static putsec()
{
	int i;
	register c;

	for(i = 0; i < SECSIZ; i++) {
		c = wcbuff[i];
		if (textmode) {
			if (c == CPMEOF)
				return(1);
			if (c == '\r')
				continue;
		}
		fputc(c, xfp);
	}
	return(0);
}
