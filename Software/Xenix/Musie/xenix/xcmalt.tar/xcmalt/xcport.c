/*	Module:	xcport.c	XCMALT Modem Interface Routines
	patchlevel 2.6 -- JPRadley
	This file uses 4-character tabstops
	This code is purely public domain!

	The dial() routine uses these two defines.

	DIALSTR is a sprintf format string that assumes a HAYES-compatible
	modem.

	HAYSATT is the HAYES "attention" signal (used if DTR_DROPS_CARRIER
	is not set to 1).

	HAYSHUP is the HAYES "hangup" command (used if DTR_DROPS_CARRIER is not
	set to 1).
*/

#define HAYSATT "+++"		/* Hayes "attention" signal */
#define DIALSTR "ATDT%s\r"
#define HAYSHUP "ATH\r"			/* Hayes "hang up" command */

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>
#include <termio.h>
#include <errno.h>
#include "xcmalt.h"

#ifdef T6000
#include <sys/ioctl.h>
#define SIZEOFLOCKFILE sizeof(int)
extern int errno;
#endif

/*#define ASCII_PID		/* if your system uses ASCII PIDs in LCKfiles */
#ifdef SCOXENIX
# define DIDOPORT

# if SCOXENIX == 22
#	define UNGETTY "/usr/lib/uucp/ungetty"
#	define UG_NOTENAB	0
#	define UG_ENAB		1
#	define UG_FAIL		2
#	define SIZEOFLOCKFILE sizeof(short)
	static	int	code, retcode, errflag;
# endif /*SCO 2.2*/

# if SCOXENIX == 23
#	include <utmp.h>
#	ifndef ASCII_PID
#	 define ASCII_PID		/* SCO 2.3 Xenix does use ASCII PIDs */
#	 define PIDSIZE 10
#	endif
  static int gettypid = -1;
# endif /*SCO 2.3*/

#endif /*SCOXENIX*/

int bitmask = 0xFF,			/* modem port i/o data mask */
cbaud = INIT_BAUD;			/* symbolic bps */
short flowflag;				/* modem port i/o data mask */
static int mfd = -1,		/* modem port file descriptor */
		pid;
static struct termio pmode;	/* modem device control string */
static char port[SM_BUFF],	/* modem port device file string */
			lckname[SM_BUFF], /* lockfile string */
			*last_nbr = NULL;

void xc_setflow(flow)
short flow;
{
	if (flow)
		pmode.c_iflag |= IXON | IXOFF,
		pmode.c_iflag &= ~IXANY;
	else
		pmode.c_iflag &= ~(IXON | IXOFF | IXANY);

	ioctl(mfd, TCSETA, &pmode);
}

char *mport(s) /* get/set port string */
char *s;
{
	if (s != NULL && mfd == -1)
		if (strncmp("/dev/", s, 5))
			strcpy(port, strcat("/dev/",s));
		else
			strcpy(port, s);

	return(port);
}

/*	Get/set the bps of the modem port. If the port hasn't been opened yet,
	just store in pmode for mopen() to use when it opens the port.
*/
mrate(s)
char *s;
{
	if (s != NULL) {
		switch (atoi(s)) {
		case 300:
			cbaud = B300;
			break;
		case 1200:
			cbaud = B1200;
			break;
		case 2400:
			cbaud = B2400;
			break;
		case 9600:
			cbaud = B9600;
			break;
#ifdef B19200
		case 19200:
			cbaud = B19200;
			break;
		case 38400:
			cbaud = B38400;
			break;
#endif
		default:
			return(-1);
		}
		pmode.c_cflag &= ~CBAUD;
		pmode.c_cflag |= cbaud;

		ioctl(mfd, TCSETA, &pmode);
	}

	switch (pmode.c_cflag & CBAUD) {
	case B300:
		return(300);
	case B1200:
		return(1200);
	case B2400:
		return(2400);
	case B9600:
		return(9600);
#ifdef B19200
	case B19200:
		return(19200);
	case B38400:
		return(38400);
#endif
	}

	show(1,"Impossible error in bps");
	return(0);
}

/*	Output a byte to the modem port.
	All data sent to the modem is output through this routine.
*/
void sendbyte(ch)
int ch;
{
	char c = ch &0xff;

	if(write(mfd, &c, 1)<0)
		show(1,"sendbyte: write error!");
}

void send_mbyte(ch)
int ch;
{
	sendbyte(ch & bitmask);
}

void send_slowly(s)
char *s;
{
	while (*s) {
		send_mbyte(*s++);
		nap(30);
	}
}

/*	The following routine is used to hang up the modem. This is accomplished
	by setting bps to 0. According to my documentation on termio, setting bps
	to zero will result in DTR not being asserted. This hangs up some (most?)
	modems. If not, the second part of the routine sends the Hayes modem
	"escape" and then a hangup command.
*/
hangup()
{
	show(1,"<< HANGUP >>");

#if DTR_DROPS_CARRIER
	pmode.c_cflag &= ~CBAUD;
	pmode.c_cflag |= B0;		/* set cbaud 0 (drop DTR) */
	ioctl(mfd, TCSETA, &pmode);

	sleep(1);					/* wait a second */

	pmode.c_cflag &= ~CBAUD;	/* reset bps */
	pmode.c_cflag |= cbaud;
	ioctl(mfd, TCSETA, &pmode);
#else /* use Hayes command */
	sleep(2);					/* Allow for "escape guard time" */
	send_slowly(HAYSATT);		/* Send modem escape command */
	sleep(3);					/* More "escape guard time" */
	send_slowly(HAYSHUP);		/* Send hangup command */
#endif
}

/*	Opens the modem port and configures it. If the port string is
	already defined it will use that as the modem port; otherwise it
	gets the environment variable MODEM. Returns Success or Failure.
*/
mopen()
{
	int c;
	char *p;

	if (port[0] == '\0') {
		if ((p = getenv("MODEM")) == NULL) {
			show(1,
				"Exiting: no modem port specified or present in environment");
			exit(3);
		}
		mport(p);
	}

	if (!lock_tty()) {
		sprintf(Msg,"Modem port %s is locked -- try later",port);
		S;
		exit(4);
	}

#ifdef DIDOPORT
	suspend();
#endif

	if ((mfd = open(port, O_RDWR | O_NDELAY)) < 0) {
		sprintf(Msg,"Can't open modem port %s",port);
		S;
		return(Failure);
	}

	ioctl(mfd, TCGETA, &pmode);

	pmode.c_cflag &= ~(CBAUD | HUPCL);
	pmode.c_cflag |= CLOCAL | cbaud;
#if SCOXENIX == 23
	pmode.c_cflag |= CTSFLOW | RTSFLOW;
#endif
	pmode.c_iflag |= IGNBRK;
	pmode.c_iflag &= ~INLCR;
	pmode.c_oflag = pmode.c_lflag = 0;
	pmode.c_cc[VMIN] = 1; 	/* This many chars satisfies reads */
	pmode.c_cc[VTIME] = 0;	/* or in this many tenths of seconds */

	xc_setflow(flowflag);

	c = mfd;
	if ((mfd = open(port, O_RDWR)) < 0) {	/* Reopen line with CLOCAL */
		sprintf(Msg,"Can't re-open modem port %s",port);
		S;
		return(Failure);
	}
	close(c);

	return(Success);
}

/*	Attach standard input and output to the modem port. This only gets called
	after a fork by the child process, which then exec's a program that uses
	standard i/o for some data transfer protocol. (To put this here is actually
	a kludge, but I wanted to keep the modem-specific stuff in a black box.)
*/
void mattach()
{
	dup2(mfd, 0);	/* close local stdin and connect to port */
	dup2(mfd, 1);	/* close local stdout and connect to port */

	close(mfd);		/* close the old port descriptor */
}

readbyte(seconds)
int seconds;
{
	return(trminp(mfd, seconds));
}

/* Read a byte using bitmask */
read_mbyte(secs)
int secs;
{
	int c;

	return (c = readbyte(secs)) == -1 ? -1 : c & bitmask;
}

/* Dial a phone number, using proper format and delay. */
void dial(s)
char *s;
{
	char buffer[SM_BUFF];

	if (last_nbr)
		free(last_nbr);

	last_nbr = strdup(s);

	sprintf(buffer, DIALSTR, s);
	send_slowly(buffer);
}

redial()
{
	char *s;

	if (last_nbr == NULL) {
		show(1,"REDIAL FAILURE");
		return -1;
	}

	s = strdup(last_nbr);
	dial(s);
	free(s);
	return 0;
}

/* send a modem break */
k_xmitbrk()
{
	show(1,"<< BREAK >>");
	ioctl(mfd, TCSBRK, 0);
}

/*	lock_tty() returns Failure if the lock file exists (prevents XCMALT
	from running).

	unlock_tty() deletes the lock file.

	SCOXENIX 2.3 mods: Steve Manes
	Check for active LCK file and try to delete it

	SCOXENIX 2.2 mods: Jean-Pierre Radley
	As above, using 'ungetty'

	Tandy 6000 mods: Fred Buck
*/

lock_tty()
{
	int lckfd;
	char *s;
	char buff[12];
#ifdef ASCII_PID
	static char apid[PIDSIZE+2] = { '\0' };
#else
	pid = -1;
#endif

	strcpy(buff, strrchr(port, '/') +1);
	s = buff + strlen(buff) - 1;

#if SCOXENIX == 22
	*s = mkhigh(*s);
#endif
#if SCOXENIX == 23
	*s = mklow(*s);
#endif

	sprintf(lckname, "/usr/spool/uucp/LCK..%s", buff);

	if (!checkLCK())		/* check LCK file */
		return(Failure);	/* can't unlock it */

	if ((lckfd = creat(lckname, 0666)) < 0) {
		sprintf(Msg,"Can't create %s", lckname);
		S;
		exit(5);
	}

#ifdef ASCII_PID
	sprintf(apid, "%*d\n", PIDSIZE, getpid());
	write(lckfd, apid, PIDSIZE+1);
#else
	pid = getpid();
	write(lckfd, (char *)&pid, SIZEOFLOCKFILE);
#endif

	close(lckfd);
	return(Success);
}

void unlock_tty()
{
	static char byettyxx[50], *byeptr;
	extern char *ttyname();

	sprintf(byettyxx,"BYE%s", strrchr(ttyname(mfd),'/')+1);
	byeptr = getenv(byettyxx);
	if (byeptr != NULL && *byeptr) {
		show(1,"Sending BYE string to modem");
		send_slowly("\r\r");
		send_slowly(byeptr);
		send_slowly("\n");
	}

	pmode.c_cflag &= ~CLOCAL;
	pmode.c_cflag |= B0;
	pmode.c_cflag |= HUPCL;
	ioctl(mfd, TCSETA, &pmode);
	close(mfd);
	setuid(geteuid());
	setgid(getegid());
#if 0
	if (!lckname || lckname[0] == '\0')
		return;
#endif
	unlink(lckname);
#ifdef DIDOPORT
	restart();
#endif
	show(1,"Exiting XCMALT");
}

/*	check to see if lock file exists and is still active.
	kill(pid, 0) only works on ATTSV, some BSDs and Xenix
	returns: Success, or
			Failure if lock file active
	added: Steve Manes 7/29/88
*/
checkLCK()
{
	int rc, fd;
#ifdef ASCII_PID
	char alckpid[PIDSIZE+2];
#endif
#if SCOXENIX == 22
	short lckpid = -1;
#else
	int lckpid = -1;
#endif

	if ((fd = open(lckname, O_RDONLY)) == -1) {
		if (errno == ENOENT)
			return(Success);	/* lock file doesn't exist */
		goto unlock;
	}
#ifdef	ASCII_PID
	rc = read(fd, (char *)alckpid, PIDSIZE+1);
	close(fd);
	lckpid = atoi(alckpid);
	if (rc != 11) {
#else
	rc = read(fd, (char *)&lckpid, SIZEOFLOCKFILE);
	close(fd);
	if (rc != SIZEOFLOCKFILE) {
#endif
		show(1,"Lock file has bad format");
		goto unlock;
	}

	/* now, send a bogus 'kill' and check the results */
	if (kill(lckpid, 0) == 0 || errno == EPERM) {
		show(1,"Lock file process is still active");
		return(Failure);
	}

unlock:
	if (unlink(lckname) != 0) {
		show(1,"Can't unlink Lock file");
		return(Failure);
	}
	return(Success);
}

#ifdef DIDOPORT
/*	suspend() sends signal to a running getty
			  sets:	gettypid, process number of running getty, if SCO 2.3
					retcode, exit value of 'ungetty', if SCO 2.2
	restart(): restarts getty if it had been running before
*/
#if SCOXENIX == 23
suspend()
{
	struct	utmp *t, *getutent();
	char buff[12];
	char *s;

	strcpy(buff, strrchr(port, '/') +1);	/* get base port */
	s = buff + strlen(buff) -1;
	*s = mklow(*s);

	while ((t = getutent()) > 0) {
		if (t->ut_type == LOGIN_PROCESS && (!strcmp(buff, t->ut_line))) {
			gettypid = t->ut_pid;	/* get getty PID */
			if (kill(gettypid, SIGUSR1) == -1 && errno != EPERM)
				show(1,"Can't signal getty");
			break;
		}
	}
	endutent();
}
restart()
{
	if (gettypid  != -1)
		kill(gettypid, SIGUSR2);
}
#endif /*SCO 2.3*/
#if SCOXENIX == 22
suspend()
{
	char *p;

	code=errflag=pid=retcode=0;
	if ((pid = fork()) == 0) {
		p = port +strlen(port) -1;	/* convert port addr */
		*p = mkhigh(*p);		/* to ucase (tty1A-Z) */
		execl(UNGETTY, "ungetty", port, NULL);
		fprintf(stderr, "ungetty exec error\n");
		exit(-1);
		}
	while (((code = wait(&errflag)) != pid) && code != -1);
	switch ((errflag>>8) & 0xff) {
	case UG_NOTENAB:	/* line acquired: not enabled */
		retcode = UG_NOTENAB;
		break;
	case UG_ENAB:	/* line acquired: need ungetty -r when done */
		retcode = UG_ENAB;
		break;
	case UG_FAIL:		/* could not acquire line */
		exit(UG_FAIL);
	case 255:
		exit(255);
	}
}
restart()
{
	char *p;

	code=errflag=pid=0;
	if(retcode == UG_ENAB) {
		if ((pid = fork()) == 0) {
			p = port +strlen(port) -1;	/* convert port addr */
			*p = mkhigh(*p);		/* to ucase (tty1A-Z) */
			execl(UNGETTY, "ungetty", "-r", port, NULL);
			exit(-1);
		}
	while (((code = wait(&errflag)) != pid) && code != -1) ;
	}
}
#endif /*SCO 2.2*/
#endif /*DIDOPORT*/
