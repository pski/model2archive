/*	timer.c
	patchlevel 2.6 -- JPRadley
	This file uses 4-character tabstops.

	Xenix systems have a function nap(t), where t is a
	number of milliseconds. If you  do not have it, you
	must define NAP to be 0 in xcmalt.h, and then select
	a value for NAP_TIMER.

	This program is designed to test for a good value
	to use for NAP_TIMER.

	Compile it by simply typing
		make timer
	and then, whenever your system is not loaded down,
	run it by typing
		timer
	while looking at the second hand of a clock.

	You should hear a beep and see elapsed seconds on
	the screen every ten seconds.

	Choose a value for NAP_TIMER that gives appropriate
	results.

	Then edit xcmalt.h to use that value.

	The function call nap(t) from various points in
	XCMALT should then introduce a delay of t milliseconds.
*/

#define NAP_TIMER 1140	/* 1140 is appropriate for my 16Mhz 80386 machine */
main()
{
	register i,j = 0;
	while (1) {
		i = NAP_TIMER * 1000;
		while (i--)
			;
			if ((i = j++%10) == 0)
			printf("%c%3d\n", 7, j-1);
	}
}
