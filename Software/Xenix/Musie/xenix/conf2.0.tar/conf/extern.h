extern errno;

extern struct passwd *getpwuid();

extern FILE *fopen(), *popen();
extern char *getlogin(), *malloc(), *realloc(), *strchr(), *strrchr();
extern char *ttyname(), *getenv(), *strcpy(), *strncpy(), *strcat();

extern char *tgetstr();
extern void tputs();

extern char *sys_errlist[];
extern int sys_nerr;
extern long lseek();
extern void free(), longjmp();
extern unsigned alarm(), sleep();

extern char *progname;
extern int log_rfd, log_wfd, usr_fd;
extern long ourplace;
extern FILE *rec_fp;
extern int confing, columns, lines;
extern char ichar, qchar;

extern char *wrdata, replytty[], replyname[];
extern unsigned wdlen;

extern struct cusrfil cuser, tuser;
extern struct clogfil clog, tlog;

extern int banner, seeme, informe, lineinput, beep;
extern int expand8bit, expandctrl;
extern unsigned linelen, wordlen;

extern int nice_exit(), write_log();
extern int version(), do_to(), messptr(), colprnt(), fatal();
extern int getopts(), getrc(), setopts(), dispchar(), do_ring();
extern char *logname, *homedir;
extern char *pager, *shell, *normform, *lineform, *shoutform, *sendform;
extern char *informform, *recfile;

extern char *cls;

#ifdef	SYSV
extern struct termio term, saveterm;
#endif	SYSV

#ifdef	BSD
extern struct tchars chrstr;
extern struct sgttyb ktty;
extern int ttyflags;
#endif	BSD

extern char *getline(), *mymalloc(), *myrealloc(), *puterr();
extern char *getword(), *parsestr(), *putsig();
