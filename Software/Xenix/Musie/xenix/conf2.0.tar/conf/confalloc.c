#include "conf.h"

/*
 *	memory managment stuff.
 */

char *
mymalloc(size)
unsigned size;
{
    char *p;

    if ((p = malloc(size)) == NULL)
    {
	(void) fprintf(stderr, "%s: Out of memory.\n", progname);
	nice_exit(-1);
    }

    return p;
}

char *
myrealloc(p, size)
char *p;
unsigned size;
{
    if (p == NULL)
    {
	if ((p = malloc(size)) == NULL)
	{
	    (void) fprintf(stderr, "%s: Out of memory.\n", progname);
	    nice_exit(-1);
	}
    }
    else if ((p = realloc(p, size)) == NULL)
    {
	(void) fprintf(stderr, "%s: Out of memory.\n", progname);
	nice_exit(-1);
    }

    return p;
}
