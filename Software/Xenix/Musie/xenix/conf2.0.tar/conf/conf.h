#include "config.h"
#include <stdio.h>
#include <sys/types.h>
#include <ctype.h>
#include <signal.h>
#include <sys/stat.h>
#include <pwd.h>
#include <setjmp.h>
#include <errno.h>

#ifdef	SYSV
#include <sys/locking.h>
#include <unlstd.h>
#include <sys/ioctl.h>
#include <termio.h>
#include <fcntl.h>
#endif	SYSV

#ifdef	BSD
#include <sgtty.h>
#include <sys/ioctl.h>
#include <sys/file.h>

#define	index	strchr
#define	rindex	strrchr
#endif	BSD


#include "structs.h"
#include "extern.h"

/*
 * some ASCII values
 *
 */

#ifdef	CTRL
#undef	CTRL
#endif	CTRL
#define	CTRL(c)		(c&0x1F)
#define	BELL		0x07
#define	BS		0x08
#define	TAB		0x09
#define	LF		0x0A
#define	CR		0x0D
#define	DEL		0x7F

/*
 * some bools
 *
 */

#ifdef	TRUE
#undef	TRUE
#endif	TRUE
#define	TRUE	1

#ifdef	FALSE
#undef	FALSE
#endif	FALSE
#define	FALSE	0

#define	NEXTWORD	1
#define	THEREST		2

#define	NOVIS		0
#define	VIS		1

#define	forever		for ever
#define	ever		(;;)
