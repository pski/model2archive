/* adduser : add a new user account          */
/* Craig Hagan                               */
/*                                           */
/* pardon the kludge..written during         */
/* commercials of star trek tng              */

#include <stdio.h>
#include <string.h>
#include "stand.h"
#include <time.h>
#include <sys/conf.h>

#define PASSWD_FILE "/etc/passwd"
/*#define DEBUG*/

char *crypt();

main()
{
  char foo[32],uname[32],person[32],passwd[32],dir[60],shell[60],line[100];
  unsigned int group,uid;
  int bad=0,done=0,correct=0;
  char	salt[2];
  time_t tm;

  FILE *passwd_file;

  while(!correct)
    {
      while(!done)
	{
	  printf("Username to add: ");
	  fgets(uname,sizeof(uname),stdin); uname[strlen(uname)-1] = '\0';
	  printf("[%s]\n",uname);
	  passwd_file=fopen(PASSWD_FILE,"r");
	  while(!feof(passwd_file) && !bad)
	    {
	      fgets(line,100,passwd_file);
	      strcpy(foo,strtok(line,":"));
	      bad=!strcmp(foo,uname);
	    }
	  fclose(passwd_file);
	  
	  done=!bad;
	  
	  if(bad)
	    {
	      printf("That name is in use, choose another.\n");
	      bad=0;
	    }
	}
      
      printf("%s's personal name : ",uname);
      fgets(person,sizeof(person),stdin); person[strlen(person)-1] = '\0';
      
      bad=1;
      while(bad)
	{
	  printf("%s's group number: ",uname);
	  scanf("%d",&group);
	  fgets(foo,sizeof(foo),stdin); foo[strlen(foo)-1] = '\0';

	  bad=group==0;
	  if (group==0)
	    {
	      printf("Give %s superuser privs? [y|n] : ",uname);
	      fgets(foo,sizeof(foo),stdin); foo[strlen(foo)-1] = '\0';
	      bad=((foo[0]!='Y')&&(foo[0]!='y'));
	    }	      
	}

      printf("\n%s's uid : ",uname);
      scanf("%d",&uid);
      
      fgets(foo,sizeof(foo),stdin); foo[strlen(foo)-1] = '\0';

      printf("\n%s's home directory: [/home/%s] : ",uname,uname);
      fgets(dir,sizeof(dir),stdin); dir[strlen(dir)-1] = '\0';
      if (!strcmp(dir,""))
	sprintf(dir,"/home/%s",uname);

      printf("Default dir is [%s] \n",dir);
      
      printf("%s's default shell : [/bin/sh] : ",uname);
      fgets(shell,sizeof(shell),stdin); shell[strlen(shell)-1] = '\0';
      
      if (!strcmp(shell,""))
	sprintf(shell,"/bin/sh");
      printf("Default shell is [%s]\n",shell);
      
      printf("%s's default password : [%s] : ",uname,uname);
      fgets(passwd,sizeof(passwd),stdin); passwd[strlen(passwd)-1] = '\0';
      if (!strcmp(passwd,""))
	sprintf(passwd,"%s",uname);

      {
	
	time(&tm);
	salt[0] = (tm & 0x0f) +	'A';
	salt[1] = ((tm & 0xf0) >> 4) + 'a';
	
      }
  
      printf("\n\nCreate user [%s]\n",uname);
      printf("In directory, [%s],\n",dir);
      printf("with [%s] as a default shell,\n",shell);
      printf("and [%s], for a password.\n",passwd);
      printf("\nIs this correct? [y|n] : ");

      fgets(foo,sizeof(foo),stdin); foo[strlen(foo)-1] = '\0';
      done=bad=correct=(foo[0]=='Y'||foo[0]=='y');
      
    }

  printf("Making directory, [%s].\n",dir);
  mkdir(dir,0700);

  passwd_file=fopen(PASSWD_FILE,"a");
  fprintf(passwd_file,"%s:%s:%d:%d:%s:%s:%s\n"
	  ,uname,crypt(passwd, salt),uid,group,person,dir,shell);
  chown(dir,uid,group);


}
