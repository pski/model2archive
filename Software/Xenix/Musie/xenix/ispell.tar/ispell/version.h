static char Version_ID[] =
    "@(#) Ispell Version 2.0.02, May 1987 Beta posting";
