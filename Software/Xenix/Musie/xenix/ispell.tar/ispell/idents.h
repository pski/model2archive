#define Include_Len include_Len
#define currentfile Currentfile
#define newwords Newwords
#define current_F cUrrent_F
