/* @(#) error.h 1.1 91/11/30 21:10:36 */

extern void error();			/* default context */
extern void error_where();		/* user-specified context */
