/* local.h to force blackjack to compile on a Tandy16/6000*/
beep(){
putchar(7);
}
#define KEY_UP '\k'
#define KEY_DOWN '\j'
#define KEY_RIGHT '\h'
#define KEY_LEFT '\l'
#define A_ALTCHARSET ' '
#define ACS_ULCORNER ' '
#define ACS_LLCORNER ' '
#define ACS_HLINE ' '
#define ACS_URCORNER ' '
#define ACS_LRCORNER ' '
#define ACS_VLINE ' '
wattroff( )
{
}
wattron( )
{
}
