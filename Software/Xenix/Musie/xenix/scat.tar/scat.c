/* -*- Mode: C -*- */
/*
 * scat - intentionally slow version of cat
 *
 * This code has been put in the public domain by the author.
 *
 */

static const char RCS_Id [] =
"$Id: scat.c,v 1.3 1993/12/13 15:13:48 rfb Exp $";

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

static char* program_name = NULL;

static void delay (void);
int main (int, char**);
static void process_file (const char* file);
static void process_stream (FILE* stream);

static void
delay (void)
{
    /* usleep (1000); */
}

int
main (int    argument_count,
      char** argument_vector)
{
    int argument_index;
    int do_input = 1;

    program_name = argument_vector [0];

    for (argument_index = 1; argument_index < argument_count; ++argument_index)
    {
	char* argument = argument_vector [argument_index];

	if (argument [0] == '-')
	{
	    fprintf (stderr, "\n%s: Unrecognized option: %s\n", program_name,
		     argument);
	    exit (1);
	}
	else
	{
	    process_file (argument);
	    do_input = 0;
	}
    }
    if (do_input) process_stream (stdin);
    return 0;
}

void
process_file (const char* file)
{
    FILE* stream;

    if ((stream = fopen (file, "r")) == NULL)
    {
	fprintf (stderr, "\nCannot read %s\n", file);
	exit (1);
    }
    process_stream (stream);
}

void
process_stream (FILE* stream)
{
    while (! feof (stream))
    {
	int character = getc (stream);

	if (character == EOF)
	{
	    fclose (stream);
	    return;
	}
	fflush (stream);
	delay ();
	putc (character, stdout);
    }
}
