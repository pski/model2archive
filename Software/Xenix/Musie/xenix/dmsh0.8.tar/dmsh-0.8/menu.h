#include <stdio.h>
#include <strings.h>
#include <ctype.h>
#include <curses.h>
#include <signal.h>
/*#include <sys/file.h>		This one causes problems	*/
/* Regents of California time.h needed below	*/
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
/*#include <syslog.h>		Don't have this one	*/
#include <errno.h>
/* You might not have stdlib.h or malloc.h */
/* #include <stdlib.h>*/
/*#include <malloc.h>*/

#define MAXLINE 250
#define VERSION "0.8"
#define MESSAGE 19

char *get_time(), *tp;
char command[MAXLINE];

typedef struct menu
{
	char desc[50];
	char todo;
	char object[256];
}MENU;
