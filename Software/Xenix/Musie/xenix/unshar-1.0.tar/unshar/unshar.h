#ifdef PTX
#define V7
#define index strchr 
#define rindex strrchr 
#endif

#ifdef HPUX 
#define index strchr 
#define rindex strrchr 
#endif

static char version[]="\n@(#)unshar.c 1.0\n";

