Article 10862 of alt.binaries.pictures.erotica:
Xref: mnemosyne.cs.du.edu alt.binaries.pictures.erotica:10862 alt.binaries.pictures.erotica.d:6069 alt.binaries.pictures.d:5081
Newsgroups: alt.binaries.pictures.erotica,alt.binaries.pictures.erotica.d,alt.binaries.pictures.d
Path: mnemosyne.cs.du.edu!uunet!darwin.sura.net!convex!riogrande.cs.tcu.edu!sanantonio!yang
From: yang@sanantonio.cs.tcu.edu (FrogMan--II)
Subject: Kiss-1.0.c for uudecode 
Message-ID: <1992Jul25.072627.23437@riogrande.cs.tcu.edu>
Sender: news@riogrande.cs.tcu.edu
Organization: Texas Christian University
Date: Sat, 25 Jul 1992 07:26:27 GMT
Lines: 207




KISS-1.0.C

This is a C program that trims headers/footers and does uudecoding at the
same time.  This application has some advantages over the programs that have
appeared on this net.  For example, uuconvert.c , uudecode.c & eek.c , etc.
Also, it can handle an unlimited number of input files including standard input
and multiple parts in a single file.
Further, it handles special cases such as those that happen to USKT-76.JPG in which the end
marker is placed in a separate artical.  These net programs uuconvert.c, eek.c, and others
will crash because this special case is not taken into consideration.
This program has undergone extensive testing without failure to date.  All you need
to do is to make sure all articals used are in order.  Say, artical#1, artical#2, ...

This program is being written for your convenience.  Feel free to distribute
copies.  If you find any bugs or have any comments please respond accordingly.
I spent an entire sunday night to write it, without going on a date.  Oh, boy,
I miss kissing those hot lips in the summer night.  :-) :-)

FLAMES -->> GAMMA.IS.TCU.EDU

KEVIN YANG
SANANTONIO.CS.TCU.EDU


--------------CUT HERE---------------CUT HERE----------------CUT HERE----------


/*
 * kiss-1.0.c
 * AUTHOR: Kevin Yang
 *
 * This C program (UNIX) takes an unlimited number of uuencoded files,
 * and trims headers/footers.  The uuencoded lines are decoded and written 
 * to specific output files.
 *
 * To compile: "cc -O -o kiss kiss-1.0.c".
 *
 */


#include <stdio.h>
#include <ctype.h>

#define Author "Kevin Yang"
#define PName "KiSS"
#define DEC(C)	(((C) - ' ') & 077)
#define LEN 128

/* most variables are declared globally, in order to
 * speed up function calls.
 */

static char input_buf[LEN], a[LEN], b[LEN], dest[LEN];
static char *buf = input_buf, *ap = a, *bp = b, *tmp, *p;
static int len, mode, newdata, endmark, hasdata, bquote, i, x, y, z;
static unsigned siz = sizeof(input_buf);
static FILE *ofp;



main(argc, argv)
int argc;
char *argv[];
{
	FILE *ifp;

	if (argc < 2)  {
		KissFile(stdin);				/* standard input */
	} else  {
		for (;--argc && ++argv; ) {
			if (! (ifp  = fopen(*argv,"r"))) {
				fprintf(stderr, "%s: %s: ", PName, *argv);
				perror(ifp);
				continue;
			}
			KissFile(ifp);
/*			remove(*argv);  */		/* uncomment this when you want to save spaces,*/
							/* it simply delete the input file	       */
			fclose(ifp);
		}
	}
	printf("\tKiss me, horny ...\n");
}  /* main */



/* This function "kiss" the input file until all articals
 * are decoded.
 */

int KissFile(ifp)
FILE *ifp;
{
	hasdata = bquote = 0;
	while (fgets(buf, siz, ifp))  {
		while(1) {
			if (!strncmp(buf,"begin ",6) && isdigit(buf[6]))  {
				hasdata = 1;			/* yes, we found valid begin line */
				break;
			}
			if (!fgets(buf, siz, ifp)) {
				if (!hasdata) fprintf(stderr, "\t%s: No begin line\n", PName);
				return (0);
			}
		}

		if (sscanf(buf, "begin %o %s", &mode, dest) != 2)  {		/* extract filename and file-mode	*/
			fprintf(stderr, "%s: %s: Missing filename or mode\n", PName, buf);
			continue;						/* try again when error occur		*/
		}

		if ((ofp = fopen(dest, "w")) == NULL) {				/* prepare output file			*/
			fprintf(stderr, "%s: %s: ", PName, dest);
			perror(ifp);
			continue;
		}

		chmod(dest, mode);						/* set file-mode			*/
		fprintf(stdout, "Extracting  <%s>\t\t-- ", dest);

		while (fgets(buf,siz,ifp)) {
			if ( (endmark = !strncmp(buf, "end", 3))
				|| (newdata = !strncmp(buf, "begin ", 6)
				&& isdigit(buf[6])) )  {
				if (newdata)  {				/* no end marker*/
					fseek(ifp, -strlen(buf), 1);	/* reset input stream */
				}
				KissLin(ap,ofp);
				break;
			}
			len = strlen(buf);
			if (*buf != 'M' || len < 60 || len > 70
				|| !strncmp(buf, "Message-ID:", 11))  {
				if (*buf == '`')  {			/* "`" char exist */
					bquote = 1;
					KissLin(bp, ofp);		/* or end marker comes  */
					break;				/* from another file.   */
				}					/* This is a tricky case*/
				tmp = ap;
				ap = bp;
				bp = buf;
				buf = tmp;
				continue;
			}
			KissLin(buf, ofp);
		}
		fclose(ofp);

		fprintf(stdout, "Done\n");
		if ((newdata || !endmark) && !bquote) fprintf(stderr, "\t%s: No end line\n", PName);
	}
}



/* This function decodes one line of information.
 * C codes are slightly different from those of uuconvert.c
 * or uudecode.c.  I use pointers instead of array indices
 * to avoid time consuming address multiplications.  The 
 * condition tests are modified and eliminates 2 tests
 * for every 4 bytes.  Characters are decoded only when
 * one of the three conditions matches, in which complicated
 * mathmatical computation are eliminated for the last few
 * bytes.
 * I hope this can speed up the process!
 */
KissLin(str)
char *str;
{
	i = DEC(*str);
	p = ++str;
	while (i > 0)  {
		if (i >= 3)  {
			x  = (DEC(*p) << 2);	p++;
			x |= (DEC(*p) >> 4);
			y  = (DEC(*p) << 4);	p++;
			y |= (DEC(*p) >> 2);
			z  = (DEC(*p) << 6);	p++;
			z |= (DEC(*p));
			putc(x, ofp);
			putc(y, ofp);
			putc(z, ofp);
		} else {
			if (i >= 2)  {
				x  = (DEC(*p) << 2);	p++;
				x |= (DEC(*p) >> 4);
				y  = (DEC(*p) << 4);	p++;
				y |= (DEC(*p) >> 2);
				putc(x, ofp);
				putc(y, ofp);
			} else {
				if (i >= 1)  {
					x  = (DEC(*p) << 2);	p++;
					x |= (DEC(*p) >> 4);
					putc(x, ofp);
				}  /* if  */
			}  /* else  */
		}  /* else  */

		str += 4;
		p = str;
		i -= 3;
	}  /* while  */
}  /* KissLin */


