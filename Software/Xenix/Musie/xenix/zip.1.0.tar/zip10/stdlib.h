#ifndef STDLIB_H
#define STDLIB_H
/*
 * fake stdlib.h for C News use on pre-ANSI compilers.
 */

extern char *malloc(), *realloc();
#endif					/* STDLIB_H */
