#include <stdio.h>
char *obvious(word);			       /* external */
main()
{      char pword[200];			       /* potentially huge line	*/
       char *s;				       /* status from obvious test */
       printf("Password obviousness tester - try your candidates.\n");
       for (;;)
       {       printf("Candidate password: ");
	       if (gets(pword) == NULL)	break; /* read next try	*/
               if (pword[0] == '\0') break;    /* empty reply, quit */
	       s = obvious(pword);	       /* check	for obviousness	*/
	       if (s)			       /* if nonnull, bad choice */
               {       printf("NO GOOD: %s.\n",s); /* no good, print error msg */
               } else {printf("OK.\n");        /* OK, so state */
	       }
       }
}
