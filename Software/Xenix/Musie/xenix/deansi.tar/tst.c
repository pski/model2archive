/*
 * A test (with parentheses)
 */
extern int main(register int,char **),
	   func(void);
static int func2(void (*my_func)(),const char *);

main(register int ac,char **av)
{
   volatile int interrupt;
   const char *ptr = "World\n";

   (void)func2(func,ptr);
}

int
func(void)
{
   printf("Hello ");
}

static int
func2(void (*my_func)(),const char *s)
{
   (*my_func)();
   return(printf("%s",s));
}
