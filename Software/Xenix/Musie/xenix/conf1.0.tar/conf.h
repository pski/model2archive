/*
 *	conf - An interactive multi-user chat program.
 *
 *	conf Copyright (c) 1986, 1987 by Keith Gabryelski
 *
 *	Conf is quasi-public domain software; it may be used and copied
 *	freely and may be modified to suit the indivuals needs as long
 *	as:
 *
 *	[1] It is not sold.
 *	[2] It is not made part of any licensed product.
 *	[3] This header and others like it are not modified or removed.
 *	[4] You allow others to use and copy without charge.
 *	
 *	without expressed written permission from the original
 *	author (Keith Gabryelski).
 *
 */

#include "config.h"
#include <stdio.h>
#include <sys/types.h>
#include <ctype.h>
#include <signal.h>
#include <sys/stat.h>
#include <pwd.h>
#include <setjmp.h>
#include <errno.h>

#ifdef	SYSV
#include <sys/ioctl.h>
#include <unlstd.h>
#include <termio.h>
#include <fcntl.h>
#endif	SYSV

#ifdef	BSD
#include <sgtty.h>
#include <sys/ioctl.h>
#include <sys/file.h>

#define	index	strchr
#define	rindex	strrchr
#endif	BSD


#include "structs.h"
#include "extern.h"

/*
 * some ASCII values
 *
 */

#ifdef	CTRL
#undef	CTRL
#endif	CTRL
#define	CTRL(c)		('c'&0x1F)
#define	BELL		0x07
#define	BS		0x08
#define	TAB		0x09
#define	LF		0x0A
#define	CR		0x0D
#define	DEL		0x7F

/*
 * some bools
 *
 */

#ifdef	TRUE
#undef	TRUE
#endif	TRUE
#define	TRUE	1

#ifdef	FALSE
#undef	FALSE
#endif	FALSE
#define	FALSE	0

#define	NEXTWORD	1
#define	THEREST		2

#define	NOVIS		0
#define	VIS		1

#define	forever		for ever
#define	ever		(;;)
