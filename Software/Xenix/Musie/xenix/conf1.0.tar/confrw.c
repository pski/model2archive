/*
 *	conf - An interactive multi-user chat program.
 *
 *	conf Copyright (c) 1986, 1987 by Keith Gabryelski
 *
 *	Conf is quasi-public domain software; it may be used and copied
 *	freely and may be modified to suit the indivuals needs as long
 *	as:
 *
 *	[1] It is not sold.
 *	[2] It is not made part of any licensed product.
 *	[3] This header and others like it are not modified or removed.
 *	[4] You allow others to use and copy without charge.
 *	
 *	without expressed written permission from the original
 *	author (Keith Gabryelski).
 *
 *
 */

#include "conf.h"

read_log()
{
    char *ptr, *p;
    char rduser[MAXNAMELEN], rdtty[MAXTTYLEN];
    int tous, toline;
    unsigned meslen;

    while (read(log_rfd, (char *)&tlog, (unsigned)sizeof(struct clogfil)) ==
	sizeof(struct clogfil))
    {
	meslen = (tlog.messlen + 7)&~7;   /* divisable by 8 */

	switch(tlog.type)
	{
	    case NORMAL:
		if (tlog.f_line == cuser.cu_line)
		{
		    if (meslen > wdlen)
			wrdata = myrealloc(wrdata, wdlen = meslen);

		    read(log_rfd, rduser, tlog.f_usrlen);
		    read(log_rfd, rdtty, tlog.f_ttylen);
		    read(log_rfd, wrdata, meslen);

		    if (!seeme && !strcmp(rdtty, cuser.cu_tty))
			break;

		    setkey(curblock);
		    enccpy(wrdata, wrdata, meslen/MAXPASSWORDLEN, 1);

		    if (!cmpdat(tlog.password, curpass, MAXPASSWORDLEN))
		    {
			if (warncrypt)
			/* some one could fake this, BFD, but, maybe
			    take care of (someday) */
			    (void)strcpy(wrdata, "[Crypted Message]");
			else
			    break;
		    }

		    if (beep)
			(void)putchar(BELL);

		    printmess(stdout, normform, rduser, rdtty,
			    wrdata, tlog.messlen);

		    if (cuser.cu_flags&USER_RECORD)
			printmess(rec_fp, normform, rduser, rdtty,
				wrdata, tlog.messlen);
		}
		else
		    (void)lseek(log_rfd, (long)(tlog.f_usrlen + tlog.f_ttylen +
			meslen), 1);
		break;

	    case SEND:
		read(log_rfd, rduser, tlog.f_usrlen);
		read(log_rfd, rdtty, tlog.f_ttylen);

		ptr = mymalloc(tlog.t_utlen);
		read(log_rfd, ptr, tlog.t_utlen);
		read(log_rfd, wrdata, meslen);

		p = ptr;
		toline = tous = FALSE;
		do
		{
		    switch(*p)
		    {
			case '/':
			    if (atoi(p+1) == cuser.cu_line)
			    toline = TRUE;
			    break;

			case ':':
			    if (!strcmp(p+1, cuser.cu_tty))
				tous = TRUE;
			    break;

			default:
			    if (!strcmp(p, cuser.cu_cname))
				tous = TRUE;
			    break;
		    }
		    
		    while (*p++) ;  /* to next name */
		} while (*p);       /* while another name exists */

		free(ptr);

		if (tous)
		{
		    setkey(pubblock);
		    enccpy(wrdata, wrdata, meslen/MAXPASSWORDLEN, 1);

		    if (beep)
			(void)putchar(BELL);

		    printmess(stdout, sendform, rduser, rdtty,
			wrdata, tlog.messlen);

		    if (cuser.cu_flags&USER_RECORD)
			printmess(rec_fp, sendform, rduser, rdtty,
				wrdata, tlog.messlen);

		    (void)strcpy(replytty, rdtty);
		    replytty[strlen(replytty)] = '\0'; /* extra nul 4 send*/
		    (void)strcpy(replyname, rduser);
		}

		if (toline)
		{
		    setkey(pubblock);
		    enccpy(wrdata, wrdata, meslen/MAXPASSWORDLEN, 1);

		    if (beep)
			(void)putchar(BELL);

		    printmess(stdout, lineform, rduser, rdtty,
			    wrdata, tlog.messlen);

		    if (cuser.cu_flags&USER_RECORD)
			printmess(rec_fp, lineform, rduser, rdtty,
				wrdata, tlog.messlen);
		}
		break;

	    case SHOUT:
		read(log_rfd, rduser, tlog.f_usrlen);
		read(log_rfd, rdtty, tlog.f_ttylen);
		read(log_rfd, wrdata, tlog.messlen);

		if (beep)
		    (void)putchar(BELL);

		printmess(stdout, shoutform, rduser, rdtty, wrdata,
			tlog.messlen);

		if (cuser.cu_flags&USER_RECORD)
		    printmess(rec_fp, shoutform, rduser, rdtty,
			    wrdata, tlog.messlen);
		break;

	    case INFORM:
		if (tlog.f_line == cuser.cu_line)
		{
		    if (tlog.messlen > wdlen)
			wrdata = myrealloc(wrdata, wdlen = tlog.messlen);

		    read(log_rfd, rduser, tlog.f_usrlen);
		    read(log_rfd, rdtty, tlog.f_ttylen);
		    read(log_rfd, wrdata, tlog.messlen);

		    if (!informe && !strcmp(rdtty, cuser.cu_tty))
			break;

		    if (beep)
			(void)putchar(BELL);

		    printmess(stdout, informform, rduser, rdtty,
			    wrdata, tlog.messlen);

		    if (cuser.cu_flags&USER_RECORD)
			printmess(rec_fp, informform, rduser,
				rdtty,wrdata, tlog.messlen);
		}
		else
		{
		    (void)lseek(log_rfd, (long)(tlog.f_usrlen + tlog.f_ttylen +
			tlog.messlen), 1);

#ifdef DEBUG1
		    (void)puts("flushin' this inform...");
		    (void)printf("f_line = %d, cu_line = %d.\n", 
			tlog.f_line, cuser.cu_line);
#endif DEBUG1
		}
		break;

	    default:
		/* ignore invalid type lseek to end */
#ifdef	DEBUG0
		(void)printf("invalid type (0x%x)\n",tlog.type);
#endif	DEBUG0
		(void)lseek(log_rfd, 0L, 2);
		break;
	}
    }
}

write_log(type, message, user, userlen, siz)
int type;
unsigned int userlen, siz;
char *message, *user;
{
    static char *wrbuf;
    static unsigned wblen=0;
    unsigned wrlen, meslen;

    clog.type = type;

    clog.messlen = siz;
    meslen = (siz + 7)&~7;   /* divisable by 8 */

    clog.t_utlen = userlen;

    switch(type)
    {
	case NORMAL:
	    wrlen = sizeof(struct clogfil) + clog.f_usrlen + clog.f_ttylen +
		    meslen;

	    if (wrlen > wblen)
		wrbuf = myrealloc(wrbuf, wblen = wrlen);

	    /* move data into wrbuf */
	    setkey(curblock);
	    cpystr(clog.password, curpass, MAXPASSWORDLEN);

	    cpystr(wrbuf, (char *)&clog, (unsigned)sizeof(struct clogfil));
	    (void)strcpy(wrbuf+sizeof(struct clogfil), cuser.cu_cname);
	    (void)strcpy(wrbuf+sizeof(struct clogfil)+clog.f_usrlen, cuser.cu_tty);
	    enccpy(wrbuf+sizeof(struct clogfil)+clog.f_usrlen+clog.f_ttylen,
		message, meslen/MAXPASSWORDLEN, 0);

	    write(log_wfd, wrbuf, wrlen);
	    break;

	case SEND:
	    /* must encrypt the buffer or zero out the last 8 bytes before
		it copies the data into it. --kmg */

	    wrlen = sizeof(struct clogfil) + clog.f_usrlen + clog.f_ttylen +
		clog.t_utlen + meslen;

	    if (wrlen > wblen)
		wrbuf = myrealloc(wrbuf, wblen = wrlen);

	    /* move data into wrbuf */
	    setkey(pubblock);
	    cpystr(clog.password, pubpass, (unsigned)MAXPASSWORDLEN);

	    cpystr(wrbuf, (char *)&clog, sizeof(struct clogfil));
	    (void)strcpy(wrbuf+sizeof(struct clogfil), cuser.cu_cname);
	    (void)strcpy(wrbuf+sizeof(struct clogfil)+clog.f_usrlen, cuser.cu_tty);
	    cpystr(wrbuf+sizeof(struct clogfil)+clog.f_usrlen+clog.f_ttylen,
		 user, clog.t_utlen);
	    enccpy(wrbuf + sizeof(struct clogfil) + clog.f_usrlen +
		clog.f_ttylen + clog.t_utlen, message, meslen/MAXPASSWORDLEN, 0);

	    write(log_wfd, wrbuf, wrlen);
	    break;

	case SHOUT:
	    /* must encrypt the buffer or zero out the last 8 bytes before
		it copies the data into it. --kmg */

	    wrlen = sizeof(struct clogfil) + clog.f_usrlen + clog.f_ttylen +
		    clog.messlen;

	    if (wrlen > wblen)
		wrbuf = myrealloc(wrbuf, wblen = wrlen);

	    /* move data into wrbuf */

	    cpystr(wrbuf, (char *)&clog, sizeof(struct clogfil));
	    (void)strcpy(wrbuf+sizeof(struct clogfil), cuser.cu_cname);
	    (void)strcpy(wrbuf+sizeof(struct clogfil)+clog.f_usrlen, cuser.cu_tty);
	    cpystr(wrbuf+sizeof(struct clogfil)+clog.f_usrlen+clog.f_ttylen,
		message, clog.messlen);

	    write(log_wfd, wrbuf, wrlen);
	    break;

	case INFORM:
	    /* must encrypt the buffer or zero out the last 8 bytes before
		it copies the data into it. --kmg */

	    wrlen = sizeof(struct clogfil) + clog.f_usrlen + clog.f_ttylen +
		    clog.messlen;

	    if (wrlen > wblen)
		wrbuf = myrealloc(wrbuf, wblen = wrlen);

	    /* move data into wrbuf */

	    cpystr(wrbuf, (char *)&clog, (unsigned)sizeof(struct clogfil));
	    (void)strcpy(wrbuf+sizeof(struct clogfil), cuser.cu_cname);
	    (void)strcpy(wrbuf+sizeof(struct clogfil)+clog.f_usrlen, cuser.cu_tty);
	    cpystr(wrbuf+sizeof(struct clogfil)+clog.f_usrlen+clog.f_ttylen,
		message, clog.messlen);

	    write(log_wfd, wrbuf, wrlen);
	    break;

#ifdef	DEBUG0
	default:
	    (void)printf("warning .. Bogus type, no write (type = %d)\n", type);
	    break;
#endif	DEBUG0
    }
}

write_usr()
{
    (void)lseek(usr_fd, ourplace, 0);

#ifdef	SYSV
    lockf(usr_fd, F_LOCK, (long)sizeof(struct cusrfil));
#endif	SYSV

#ifdef	BSD
    flock(usr_fd, LOCK_EX);
#endif	BSD

    write(usr_fd, (char *)&cuser, sizeof(struct cusrfil));

#ifdef	SYSV
    (void)lseek(usr_fd, ourplace, 0);
    lockf(usr_fd, F_ULOCK, (long)sizeof(struct cusrfil));
#endif	SYSV

#ifdef	BSD
    flock(usr_fd, LOCK_UN);
#endif	BSD
}
