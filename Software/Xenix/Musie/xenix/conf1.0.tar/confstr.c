/*
 *	conf - An interactive multi-user chat program.
 *
 *	conf Copyright (c) 1986, 1987 by Keith Gabryelski
 *
 *	Conf is quasi-public domain software; it may be used and copied
 *	freely and may be modified to suit the indivuals needs as long
 *	as:
 *
 *	[1] It is not sold.
 *	[2] It is not made part of any licensed product.
 *	[3] This header and others like it are not modified or removed.
 *	[4] You allow others to use and copy without charge.
 *	
 *	without expressed written permission from the original
 *	author (Keith Gabryelski).
 *
 */

#include "conf.h"

unsigned int wordlen;

char *
parsestr(string, length, flags)
char *string;
int length, flags;
{
    static char *retbuf;
    static int buflen = 0;
    static char *prevs;
    static int prevl;
    char *p;

    if (buflen == 0)
	retbuf = mymalloc((unsigned)(buflen = PAGESIZ));

    p = retbuf;

    if (!length)
    {
	string = prevs;
	length = prevl;
    }

    while (length && isspace(*string))
    {
        ++string;
	--length;
    }

    prevs = string;
    prevl = length;

    if (!length)
    {
	wordlen = linelen = 0;
	return NULL;
    }

    while (length && ((flags&THEREST) || (!isspace(*string)&&(*string != ',')&&(*string != '='))))
    {
	if (*string == '"')
	{
	    ++string;  --length;

	    while (length && (*string != '"'))
	    {
		if (*string == '\\')
		{
		    ++string; --length;

		    if (length && isdigit(*string))
		    {
			int x, c;

			x = (*string++ - '0');  --length;

			if (length && isdigit(*string))
			{
			    x = (x * 10) + (*string++ - '0');  --length;

			    if (length && isdigit(*string))
			    {
				c = (x * 10) + (*string - '0');
				if (c < 256)
				{
				    x = c;
				    ++string;  --length;
				}
			    }
			}

			*p++ = x;
		    }
		    else
			if (length)
			{
			    *p++ = *string++;  --length;
			}
		}
		else
		{
		    *p++ = *string++; --length;
		}
	    }
	}
	else
	{
	    if (*string == '\\')
	    {
		++string; --length;

		if (length && isdigit(*string))
		{
		    int x, c;

		    x = (*string++ - '0');  --length;

		    if (length && isdigit(*string))
		    {
			x = (x * 10) + (*string++ - '0');  --length;

			if (length && isdigit(*string))
			{
			    c = (x * 10) + (*string - '0');
			    if (c < 256)
			    {
				x = c;
				++string;  --length;
			    }
			}
		    }

		    *p++ = x;
		}
		else
		    if (length)
		    {
			*p++ = *string++;  --length;
		    }
	    }
	    else
	    {
		*p++ = *string++; --length;
	    }
	}
    }

    *p = '\0';

    while (length && isspace(*string))
    {
        ++string;  --length;
    }

    if (length && ((*string == ',') || (*string == '=')))
    {
	++string;  --length;
    } 

    prevs = string;
    prevl = length;

    linelen = length;
    wordlen = p - retbuf;

    return wordlen ? retbuf : NULL;
}

cpystr(to, from, length)
register char *to, *from;
register unsigned int length;
{
   while(length--) *to++ = *from++;
}

zbuf(ptr, length)
register char *ptr;
register unsigned int length;
{
    while(length--) *ptr = '\0';
}

cmpdat(dat1, dat2, length)
register char *dat1, *dat2;
register int length;
{
    while (length--)
	if (*dat1++ != *dat2++)
	    return FALSE;

    return TRUE;
}

char *
puterr(error)
int error;
{
    static char qwerty[42];

    (void)sprintf(qwerty, "Unknown error %d", error);

    return ((unsigned)error >= sys_nerr) ? qwerty : sys_errlist[error];
}
