/*
 *	conf - An interactive multi-user chat program.
 *
 *	conf Copyright (c) 1986, 1987 by Keith Gabryelski
 *
 *	Conf is quasi-public domain software; it may be used and copied
 *	freely and may be modified to suit the indivuals needs as long
 *	as:
 *
 *	[1] It is not sold.
 *	[2] It is not made part of any licensed product.
 *	[3] This header and others like it are not modified or removed.
 *	[4] You allow others to use and copy without charge.
 *	
 *	without expressed written permission from the original
 *	author (Keith Gabryelski).
 *
 */

/*
 * System type.  Define only the *ONE* system that applies to you
 * the most.
 */

#define SYSV		        /* System V and Xenix.  SCO Xenix */
/*#define BSD		        /* Any of the Berkeley clan */

/*
 *  Define MYCRYPT only if you do not have working encrypt() or setkey()
 *  system calls.  Some system do not come with crypt because of oversea's
 *  laws.
 *
 *  Some systems have a broken encrypt() system call (3b1, and SCO Xenix)
 *
 *  The crypt functions supplied by me are BOGUS.  If you have a public
 *  domain crypt that I may include with later releases, please email a
 *  copy to: ag@portnoy.cts.com or crash!portnoy!ag@nosc.mil
 *
 *  If you *DO NOT* define MYCRYPT and conference messages look somewhat
 *  like line noise, then your encrypt function will not work with conf.
 *  You must then, define MYCRYPT and re-make conf.
 *
 */

#define MYCRYPT		/* Use my crypt function? */

/*
 * Define USE_TERMCAP if you have the termcap library.  conf will work
 * without termcap.  I include it to figure out the users terminal clear
 * screen string.  The clear screen string can be defined in your CONFOPTS
 * environment variable, .confrc, or at any time during conf.
 *
 * If you define this variable remember to include "-lcurses", "-ltermcap",
 * or "-ltermlib" in the Makefile.
 *
 */

#define	USE_TERMCAP 		/* Use-p TERMCAP */

/*
 * Define SENDER as the local command to use to SEND a message.
 * :rings will popen() this command giving it one user on the
 * command line and its message through standard input.
 *
 * If you do not have a local SEND program then define this as
 * "write".
 */

#define SENDER	"write"		/* the local send program */

/*
 * The default pager
 *	maybe "more" or "cat"
 */

#define	DEF_PAGER	"less"		/* local pager */
#define	DEF_SHELL	"sh"		/* default shell*/

/*
 * User settable files.
 *	Someday these files will be definable at any time during conf
 */

#define	CONFLOG		"/usr/lib/conf/conflog"   /* conversation log */
#define	CONFUSERS	"/usr/lib/conf/confusers" /* user log */
#define	CONFHELP	"/usr/lib/conf/confhelp"  /* help file */

#define	DEF_RECFILE	"conf.rec"	 /* default record file */
#define	CONFRC		".confrc"	 /* default rc file */

#define	CONFOPTS	"CONFOPTS"		  /* evironment variable */

#define	NUMBER_OF_THE_BEAST	0666
#define	FILEMASK	NUMBER_OF_THE_BEAST /* filemask for CONF{USERS,LOG} */

/* Some buffer length stuff */
#define	MAXNAMELEN	21
#define	MAXTTYLEN	21
#define	MAXCONFLINES	100     /* number of conference lines */

#define	PAGESIZ		512     /* alloc this amount at a time */

/*
 * DEF_CLSSTR is a default clear screen string.  It will be used if
 * conf cannot figure out your terminal (using TERMCAP) and the user
 * does set the clear screen string to something different.
 *
 * It is currently set to the ANSI clear screen string.  You may
 * want to set it to "\n" for no action.
 *
 */

#define	DEF_CLS		"\033[2J\033[H"  /* default clear screen screen */
#define DEF_COLUMNS	80
#define DEF_LINES	24
#define TABAGE		2		/* space between columns */

/*
 * The public key is used for normal messages, sends, replies, and informs
 * if another password is not given.
 *
 * Passwords are 8 characters or less.
 */

#define	MAXPASSWORDLEN	8
#define DEF_KEY		"Pax"		 /* default public key */

/*
 * Some important influences.
 *
 * Thanks should also go out to Neil Pert for awesome percussion. -MQH
 */

#define SIGNIFICANT_OTHER	"Marla Gabryelski"

#define	MUSICIAN		"Brian_Eno"
#define	SONG			"Third_Uncle"

#define VERNUM			1
#define PATCHLEVEL		0

#define AUTHOR			"Keith M. Gabryelski"
#define ADDRESS			"ag@portnoy.cts.com"
#define ALTPATH			"ag@crash.cts.com"
#define THANKS1			"ford@kenobi.cts.com (Mike Ditto)"
#define	THANKS2			"paul@portnoy.cts.com (Paul Palacios)"

/*
 * form strings
 *
 *	Meta characters for form string:
 *
 *	%N - Your conference name.
 *	%n - Name of user sending message.
 *	%m - Message users sent.
 *	%T - Your tty.
 *	%t - Tty of user that sent message.
 *	%% - The character '%'
 *
 */

#define	DEF_FORM_NORM	";;; %n (%t) - %m\n"
#define	DEF_FORM_SEND	">>> %n (%t) - %m\n"
#define	DEF_FORM_INFORM	"::: %n (%t) [%m]\n"
#define	DEF_FORM_LINE	"::: %n (%t) - %m\n"
#define	DEF_FORM_SHOUT	"*** %n (%t) - %m\n"

/*
 * DEBUGx are debugging defines.
 *
 */

#define DEBUG0		/* insignificant checks around conf */
/*#define DEBUG1		/* temporary debug messages */
/*#define DEBUG2		/* dealing with crypt and block functions */
/*#define DEBUG3		/* another temporary */
