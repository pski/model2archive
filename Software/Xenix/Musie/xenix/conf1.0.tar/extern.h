/*
 *	conf - An interactive multi-user chat program.
 *
 *	conf Copyright (c) 1986, 1987 by Keith Gabryelski
 *
 *	Conf is quasi-public domain software; it may be used and copied
 *	freely and may be modified to suit the indivuals needs as long
 *	as:
 *
 *	[1] It is not sold.
 *	[2] It is not made part of any licensed product.
 *	[3] This header and others like it are not modified or removed.
 *	[4] You allow others to use and copy without charge.
 *	
 *	without expressed written permission from the original
 *	author (Keith Gabryelski).
 *
 */

extern errno;

extern struct passwd *getpwuid();

extern FILE *fopen(), *popen();
extern char *getlogin(), *malloc(), *realloc(), *strchr(), *strrchr();
extern char *ttyname(), *getenv(), *strcpy(), *strncpy(), *strcat();

#ifdef	USE_TERMCAP
extern char *tgetstr();
extern void tputs();
#endif	USE_TERMCAP

extern char *sys_errlist[];
extern int sys_nerr;
extern long lseek();
extern void free(), longjmp();
extern unsigned alarm(), sleep();

extern char *progname;
extern int log_rfd, log_wfd, usr_fd;
extern long ourplace;
extern FILE *rec_fp;
extern int confing, columns, lines;
extern char ichar, qchar;

extern char pubkey[], curkey[], pubblock[], curblock[], pubpass[], curpass[];
extern char *wrdata, replytty[], replyname[];
extern unsigned wdlen;

extern struct cusrfil cuser, tuser;
extern struct clogfil clog, tlog;

extern int banner, seeme, informe, warncrypt, autowho, lineinput, beep;
extern int expand8bit, expandctrl, askdump;
extern unsigned linelen, wordlen;

extern int nice_exit(), makepass(), enccpy(), write_log();
extern int version(), do_to(), set_pass(), messptr(), colprnt(), fatal();
extern int getopts(), getrc(), setopts(), dispchar(), do_ring();
extern char *logname, *homedir;
extern char *pager, *shell, *normform, *lineform, *shoutform, *sendform;
extern char *informform, *recfile;

char *cls;

#ifdef	SYSV
extern struct termio term, saveterm;
#endif	SYSV

#ifdef	BSD
extern struct sgttyb ktty;
extern int ttyflags;
#endif	BSD

extern char *getline(), *mymalloc(), *myrealloc(), *puterr();
extern char *getword(), *parsestr(), *putsig();
