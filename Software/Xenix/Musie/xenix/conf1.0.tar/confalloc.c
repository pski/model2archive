/*
 *	conf - An interactive multi-user chat program.
 *
 *	conf Copyright (c) 1986, 1987 by Keith Gabryelski
 *
 *	Conf is quasi-public domain software; it may be used and copied
 *	freely and may be modified to suit the indivuals needs as long
 *	as:
 *
 *	[1] It is not sold.
 *	[2] It is not made part of any licensed product.
 *	[3] This header and others like it are not modified or removed.
 *	[4] You allow others to use and copy without charge.
 *	
 *	without expressed written permission from the original
 *	author (Keith Gabryelski).
 *
 */

#include "conf.h"

/*
 *	memory managment stuff.
 */

char *
mymalloc(size)
unsigned size;
{
    char *p;

    if ((p = malloc(size)) == NULL)
    {
	(void)fprintf(stderr, "%s: Out of memory.\n", progname);
	nice_exit(-1);
    }

    return p;
}

char *
myrealloc(p, size)
char *p;
unsigned size;
{
    if (p == NULL)
    {
	if ((p = malloc(size)) == NULL)
	{
	    (void)fprintf(stderr, "%s: Out of memory.\n", progname);
	    nice_exit(-1);
	}
    }
    else if ((p = realloc(p, size)) == NULL)
    {
	(void)fprintf(stderr, "%s: Out of memory.\n", progname);
	nice_exit(-1);
    }

    return p;
}
