
/*
 *	conf - An interactive multi-user chat program.
 *
 *	conf Copyright (c) 1986, 1987 by Keith Gabryelski
 *
 *	Conf is quasi-public domain software; it may be used and copied
 *	freely and may be modified to suit the indivuals needs as long
 *	as:
 *
 *	[1] It is not sold.
 *	[2] It is not made part of any licensed product.
 *	[3] This header and others like it are not modified or removed.
 *	[4] You allow others to use and copy without charge.
 *	
 *	without expressed written permission from the original
 *	author (Keith Gabryelski).
 *
 *
 */

#include "conf.h"

int nsig = 16;

char *sig_list[] =
{
	"Unkown Signal: 0",
	"Hangup",
	"Interrupt",
	"Quit",
	"Illegal Instruction",
	"Trace Trap", 
	"IOT Instruction",
	"EMT Instruction",
	"Floating Point Exception",
	"Kill",
	"Bus Error",
	"Segmentation Violation",
	"Bad Argument To System Call",
	"Write On A Pipe With No One To Read It",
	"Alarm Clock",
	"Software Termination Signal From Kill",
};

fatal(sig)
int sig;
{
    int c, p;

    (void)printf("\nFatal Signal %d (%s).\n", sig, putsig(sig));
    make_nice(FALSE);
    if (askdump || (sig == SIGQUIT))
    {
	p = TRUE;
	(void)fputs("dump core? [y] ", stdout);
	while(((c = getchar()) != '\n') && (c != EOF))
	{
	    switch(c)
	    {
		case 'y':
		case 'Y':
		    p = TRUE;
		    break;

		case 'n':
		case 'N':
		    p = FALSE;
		    break;
	    }
	}

	if (p)
	{
	    p = kill(cuser.cu_procid, sig);
	    if (p <0)
		(void)fprintf(stderr, "%s: Couldn't kill proccess %d (%s)\n",
			progname, cuser.cu_procid, puterr(errno));
	}
    }
    (void) exit(-1);
}

char *
putsig(sig)
int sig;
{
    static char qwerty[42];

    (void)sprintf(qwerty, "Unknown Signal: %d", sig);

    return ((unsigned)sig >= nsig) ? qwerty : sig_list[sig];
}
