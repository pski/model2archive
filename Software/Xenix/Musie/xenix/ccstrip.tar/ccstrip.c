#include <stdio.h>

main() /* ccstrip: strip control characters */
{
	int c;
	while ((c = getchar()) != EOF)
		if ((c >= ' ' && c < 0177)|
			c == '\t'|c == '\n')
			putchar(c);
	exit(0);
}
