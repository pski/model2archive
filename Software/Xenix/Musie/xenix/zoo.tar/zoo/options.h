/* @(#) options.h 2.22 88/08/24 15:27:36 */

/*
The contents of this file are hereby released to the public domain.

                           -- Rahul Dhesi 1986/11/14

For documentation about this file, see options.doc.
*/


/* ZOO is always defined currently */
#define ZOO

/* Compilation without ZOOCOMMENT has not been tested */
#define ZOOCOMMENT

#ifdef SYS_V
#define FILTER
#define VER_DISPLAY ";"
#define VER_INPUT ":;"
#define IO_MACROS
#define EXISTS(f)		(access(f, 00) == 0)
#define MEMSET
#define FNLIMIT 14
#define CHEKDIR
#define NIXTIME
#define NIXFNAME
#define NEEDCTYP
#define NOENUM
#define PORTABLE
#define REN_LINK
#define SETBUF
#define GETTZ
#define FATTR
#endif

#ifdef TURBOC
#define VER_DISPLAY ";"
#define VER_INPUT ":;"
#define USE_ASCII
#define SPECINIT
#define SPECEXIT
#define PURIFY
#define DISK_CH ':'
#define IGNORECASE
#define WILDCARD "*.*"
#define FOLD
#define FORCESLASH
#define FNLIMIT 12
#define CUR_DIR "."
#define PATH_CH "/"
#define PATH_SEP ":/\\"
#define EXT_CH '.'
#define EXT_SEP  ":/\\."
#define EXT_DFLT ".zoo"
#define SETMODE
/* 0x8000 and 0x4000 taken from <fcntl.h> for Turbo C */
#define MODE_BIN(f)      setmode(fileno(f), 0x8000)
#define MODE_TEXT(f)     setmode(fileno(f), 0x4000)
#define LINT_ARGS
#define MORE 	...
#define NOTHING		void
#define VOIDPTR		void *
#define REN_REV
#define UNBUF_IO
#define UNBUF_LIMIT		512
#ifdef  PORTABLE
#define SPECNEXT
#define NIXTIME
#undef  WILDCARD
#endif

#endif /* TURBOC */

#ifdef MSC
#define VER_DISPLAY ";"
#define VER_INPUT ":;"
#define ALWAYS_INT
#define USE_ASCII
#define SPECINIT
#define SPECEXIT
#define PURIFY
#define DISK_CH ':'
#define IGNORECASE
#define WILDCARD "*.*"
#define FOLD
#define FORCESLASH
#define FNLIMIT 12
#define CUR_DIR "."
#define PATH_CH "/"
#define PATH_SEP ":/\\"
#define EXT_CH '.'
#define EXT_SEP  ":/\\."
#define EXT_DFLT ".zoo"
#define SETMODE
/* 0x8000 and 0x4000 taken from <fcntl.h> for Microsoft C */
#define MODE_BIN(f)      setmode(fileno(f), 0x8000)
#define MODE_TEXT(f)     setmode(fileno(f), 0x4000)
#define LINT_ARGS
#define MORE
#define NOTHING
#define VOIDPTR		char *
#define REN_NORM

#define UNBUF_IO
#define UNBUF_LIMIT		512

#ifdef  PORTABLE
#define SPECNEXT
#define NIXTIME
#undef  WILDCARD
#endif

#endif /* MSC */

#ifdef BSD4_3
#define NOSTRCHR /* not really needed for 4.3BSD */
#define FILTER
#define VER_DISPLAY ";"
#define VER_INPUT ":;"
#define IO_MACROS
#define EXISTS(f)		(access(f, 00) == 0)
#define FNLIMIT 1023
#define CHEKDIR
#define NIXTIME
#define NIXFNAME
#define NEEDCTYP
#define PORTABLE
#define NOENUM
#define REN_REV
#define SETBUF
#define GETTZ
#define FATTR
#endif



#ifdef VMS

/*
Select VMS pre-4.6 or 4.6 next line.  Pre-4.6 library does not have
rename() and memset() so zoo defines its own;  4.6 has these, so we
must use them, else VMS library functions will conflict with our
own.
*/
# if 1		/* VMS version 4.6 */
#  define VMS_RENAME /* this symbol used only in file vms.c */
#  define REN_REV
#  define MEMSET
# else		/* VMS pre-version 4.5 */
#  define REN_NORM
# endif

#define VER_DISPLAY ";"
#define VER_INPUT ":;"

#define IO_MACROS
#define SPEC_WILD
#define EXT_ANYWAY
#define VER_CH ';'
#define SPECEXIT
#define CHEKUDIR
#define FNLIMIT 78
#define DIR_SEP '.'  /* separates dir fields */
#define DISK_CH ':'
#define DIR_LBRACK "[" /* left bracketing symbol dir dir name */
#define PATH_CH "]"
#define PATH_SEP ":]"
#define EXT_CH '.'
#define EXT_SEP ":]."
#define EXT_DFLT ".zoo"
#define CUR_DIR "."
#define NIXTIME
#define NEEDCTYP
#define NOENUM
#define PORTABLE
#define DUMB_ASS
#define IGNORECASE
#define SPECMOD
#define SPECNEXT
#define WILDCARD "*.*"
#define FOLD
#endif

#ifdef MCH_AMIGA
#define VER_DISPLAY ";"
#define VER_INPUT ":;"
#define PURIFY
#define DISK_CH ':'
#define SPECNEXT
#define WILDCARD "*"
#define IGNORECASE
#define FNLIMIT 30
#define NEEDCTYP
#define CUR_DIR "."
#define PATH_CH "/"
#define PATH_SEP ":/"
#define EXT_CH   '.'
#define EXT_SEP  ":/."
#define EXT_DFLT ".zoo"
#define PORTABLE
#define NOSIGNAL
#define REN_REV
#define NOENUM
#define SETBUF
#define CHEKUDIR
#define GETUTIME
#define NIXTIME
#endif

#ifdef NIXFNAME
#define CUR_DIR "."
#define PATH_CH "/"
#define PATH_SEP "/"
#define EXT_CH '.'
#define EXT_SEP  "/."
#define EXT_DFLT ".zoo"
#endif

#ifdef GENERIC
/* #define SPECNEXT */
#define IGNORECASE
#define FNLIMIT 11
#define NEEDCTYP
#define CUR_DIR "."
#define PATH_CH "/"
#define PATH_SEP ":/"
#define EXT_CH   '.'
#define EXT_SEP  ":/."
#define EXT_DFLT ".zoo"
#define PORTABLE
#define NOSIGNAL
/* REN_LINK is UNIX-specific.  Can't find a generic rename() function */
#define REN_LINK
/* #define FLAT */
#define NOENUM
#define SETBUF
#define CHEKUDIR
#define GETUTIME
#define NIXTIME
#endif

/* ANSI compatibility in declarations -- see zoofns.h for usage */
#ifndef PARMS
#ifdef LINT_ARGS
#define	PARMS(x)		x
#else
#define	PARMS(x)		()
#endif
#endif

/* Compensate for strchr/index differences */
#ifdef NOSTRCHR
#define	strchr	index
#define	strrchr	rindex
#endif
