/*@H************************ < COMPRESS utility> **************************** 
*   $@(#) compusi.uni,v 4.3d 90/01/18 03:00:00 don Release ^                * 
*                                                                           * 
*   compress : compusi.uni <Unix/Xenix support functions>                   * 
*                                                                           * 
*   port by  : Donald J. Gloistein                                          * 
*                                                                           * 
*   Source, Documentation, Object Code:                                     * 
*   released to Public Domain. This code is ported from compress v4.0       * 
*   release joe.                                                            * 
*                                                                           * 
*---------------------------  Module Description  --------------------------* 
*   Unix system dependent routines. These are specific to either the        * 
*   unix file structure or some unix only functions.                        * 
*                                                                           * 
*   Separated out for ease of writing the main module.                      * 
*                                                                           * 
*--------------------------- Implementation Notes --------------------------* 
*                                                                           * 
*   compiled with : compress.h compress.fns                                 * 
*   linked with   : compress.o compapi.o                                    * 
*                                                                           * 
*   To use, copy or rename this file to compusi.c and recompile.            * 
*   Set the defines in compress.h to reflect the status of your compiler's  * 
*   runtime library, allocation type for malloc()'s, and memory models if   * 
*   applicable, and your library function call for malloc() and free().     * 
*                                                                           * 
*   problems: header has some hardcoded defines you may need to change      * 
*             for your compiler. Please read the header thoroughly.         * 
*                                                                           * 
*---------------------------      Author(s)        -------------------------* 
*     Initials ---- Name ---------------------------------                  * 
*      DjG          Donald J. Gloistein                                     * 
*                   Plus many others, see rev.hst file for full list        * 
*      LvR          Lyle V. Rains, thanks for the improved implementation   * 
*                   of the compression and decompression routines.          * 
*************************************************************************@H*/ 
 
#include <stdio.h> 
 
#include "compress.h" /* contains the rest of the include file declarations */ 
 
/* For those who don't have it in libc.a */ 
 
#ifdef NO_STRRCHR 
char  *strrchr(s,c) 
char *s; 
int c; 
{ 
	register int count; 
 
	while (*s){ 
		s++; 
		count++; 
	} 
	s--; 
	while (count--) 
		if (*s == (char)c) 
			return(s); 
		else 
			s--; 
	return(NULL); 
} 
#endif 
 
char *get_program_name(ptr) 
char *ptr; 
{ 
	char *cp; 
	if ((cp = strrchr(ptr, '/')) != NULL) 
		cp++; 
	else 
		cp = ptr; 
 
	if(strcmp(cp,"uncompress") == 0) { 
		do_decomp = 1; 
	} 
	else 
		if(strcmp(cp, "zcat") == 0) { 
			keep = TRUE; 
			zcat_flg = do_decomp = 1; 
		} 
	return (cp); 
} 
 
 
char *name_index(ptr) 
char *ptr; 
{ 
	char *p; 
 
	p = strrchr(ptr,'/'); 
	return ((p)? ++p: ptr); 
} 
 
int is_z_name(ptr)       /* checks if it is already a z name */ 
char *ptr; 
{ 
	return (!(strcmp(ptr + strlen(ptr) -2,".Z"))); 
} 
 
int make_z_name(ptr) 
char *ptr; 
{ 
#ifndef BSD4_2 
	if (strlen(name_index(ptr)) > 12 ) { 
		fprintf(stderr,"%s: filename too long to add .Z\n",name_index(ptr)); 
		return FALSE; 
	} 
#endif 
	strcat(ptr,".Z"); 
	return TRUE; 
} 
void unmake_z_name(ptr) 
char *ptr; 
{ 
	register int len = strlen(ptr)-2; 
 
	ptr[len] = '\0'; 
} 
 
#ifndef NOSIGNAL 
SIGTYPE onintr ( ) 
{ 
	if (!zcat_flg && !keep_error){ 
		fclose(stdout); 
		unlink ( ofname ); 
	} 
	exit ( ERROR ); 
} 
 
SIGTYPE oops ( )    /* wild pointer -- assume bad input */ 
{ 
	if ( do_decomp == 1 ) 
		fprintf ( stderr, "%s: corrupt input: %s\n",prog_name,ifname); 
	if (!zcat_flg && !keep_error){ 
		fclose(stdout); 
		unlink ( ofname ); 
	} 
	exit ( ERROR ); 
} 
#endif 
 
int test_file(ifname)  /* test for a good file name and no links */ 
char *ifname;          /* returns ERROR for bad file */ 
{ 
    struct stat statbuf; 
 
    if (stat(ifname, &statbuf)) {       /* Get stat on input file */ 
        perror(ifname); 
        return(ERROR); 
    }else if ((statbuf.st_mode & S_IFMT/*0170000*/) != S_IFREG/*0100000*/) { 
        fprintf(stderr, "%s -- not a regular file: unchanged",ifname); 
        return(ERROR); 
    } else if (statbuf.st_nlink > 1) { 
        if(quiet) 
        fprintf(stderr, "%s -- has %d other links: unchanged",ifname, 
            statbuf.st_nlink - 1); 
        return(ERROR); 
    } 
   return (0); 
} 
 
void copystat(ifname, ofname) 
char *ifname, *ofname; 
{ 
	struct stat statbuf; 
	int mode; 
	time_t timep[2]; 
 
	fclose(stdout); 
	if (stat(ifname, &statbuf)) {       /* Get stat on input file */ 
		perror(ifname); 
		return; 
	} 
    if (exit_stat == NOSAVING && (!force)) { /* No compression: remove file.Z */ 
		if(!quiet) 
			fprintf(stderr, " -- no savings -- file unchanged"); 
	} 
	else if (exit_stat == NOMEM){ 
		if (!quiet) 
			fprintf(stderr, " -- file unchanged"); 
		if (!do_decomp) 
			exit(ERROR); 
		else 
			return;     /* otherwise will unlink outfile */ 
	} 
	else if (exit_stat == OK) {  /* ***** Successful Compression ***** */ 
		mode = statbuf.st_mode & 07777; 
		if (chmod(ofname, mode))        /* Copy modes */ 
			perror(ofname); 
		chown(ofname,statbuf.st_uid,statbuf.st_gid); /* Copy Ownership */ 
		timep[0] = statbuf.st_atime; 
		timep[1] = statbuf.st_mtime; 
		utime(ofname,timep);   /* Update last accessed and modified times */ 
		if (!keep){ 
			fclose(stdin); 
			if (unlink(ifname)) /* Remove input file */ 
				perror(ifname); 
			if(!quiet) 
				fprintf(stderr, " -- replaced with %s", ofname); 
		} 
		else{ 
			if(!quiet) 
				fprintf(stderr, " -- compressed to %s", ofname); 
		} 
		return;     /* Successful return */ 
	} 
 
	/* Unsuccessful return -- one of the tests failed */ 
	fclose(stdout); 
	if (unlink(ofname)) 
		perror(ofname); 
} 
 
#ifndef COMPVER 
#ifdef XENIX 
#define COMPVER "Xenix" 
#else 
#define COMPVER "unix" 
#endif 
#endif 
 
#ifdef COMP40 
#define RESET "Adaptive Reset" 
#else 
#define RESET "No Adaptive Reset" 
#endif 
 
void version() 
{ 
#ifdef DEBUG 
    fprintf(stderr, "%s\nOptions: %s %s DEBUG MAXBITS = %d\n",rcs_ident,COMPVER, 
	    RESET,MAXBITS); 
#else 
    fprintf(stderr, "%s\nOptions: %s %s MAXBITS = %d\n",rcs_ident,COMPVER, 
	RESET,MAXBITS); 
#endif 
} 
 
ALLOCTYPE FAR *emalloc(x,y) 
unsigned int x; 
int y; 
{ 
	ALLOCTYPE FAR *p; 
	p = (ALLOCTYPE FAR *)ALLOCATE(x,y); 
	return(p); 
} 
 
void efree(ptr) 
ALLOCTYPE FAR *ptr; 
{ 
	FREEIT(ptr); 
} 
