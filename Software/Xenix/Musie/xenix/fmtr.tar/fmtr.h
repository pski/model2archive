#include <stdio.h>
#include <ctype.h>

int z_flag;		/* look behind zero width spaces? */
int nf_val;		/* no fill on or off? */
int ul_val;		/* number of lines to underline */
int ce_val;		/* number of lines to center */
int llength;

char outbuf[BUFSIZ];	/* output buffer, ridiculously large */
char *outp;		/* pointer into outbuf */

void n_brk();
char *strcpy();
