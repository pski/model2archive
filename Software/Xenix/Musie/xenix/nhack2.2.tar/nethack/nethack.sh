mesg n
cd /usr/local/games/nethack.d
nethack
mesg y
echo -n "Another game `logname` y/n? "
	read answ
	case "$answ" in
		y)	exec nethack;;
		n)	exit ;;
esac
