/*    SCCS Id: @(#)date.h    1.4    87/08/08 */

char datestring[] = "Sun Apr  3 23:06:41 1994";
