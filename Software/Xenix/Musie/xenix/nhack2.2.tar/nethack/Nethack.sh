#!/bin/sh
#    SCCS Id: @(#)nethack.sh    1.4    87/08/08
HACKDIR=/usr/local/games/nethack.d
HACK=$HACKDIR/nethack

cd $HACKDIR
case $1 in
    -s*)
	exec $HACK $@
	;;
    *)
	exec $HACK $@ $MAXNROFPLAYERS
	;;
esac
