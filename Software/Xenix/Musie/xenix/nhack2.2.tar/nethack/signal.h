#define SIG_IGN     1
#define SIG_DFL     0
#define signal(x,y) SIG_IGN

