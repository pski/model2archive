#define BUFSZ	512
#define error printf

/* < Insert newest version of the compressing routines here > */

main(argc, argv)
int argc;
char *argv[];
{
    char buf[BUFSZ];
    int sz, from, to;

    from = open(argv[1], 0);
    to = creat(argv[2], 0666);
    if (argc > 3) {
	mread(0, (char *)0, 0);
	while (sz = mread(from, buf, BUFSZ))
	    write(to, buf, sz);
    } else {
	while (sz = read(from, buf, BUFSZ))
	    bwrite(to, buf, sz);
	bwrite(to, (char *)0, 0);
    }
    close(from);
    close(to);
}

