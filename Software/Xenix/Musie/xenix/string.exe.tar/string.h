/***	string.h -- string(3) routines
 *
 */

# include <memory.h>

extern	char
	*strcpy(),
	*strncpy(),
	*strcat(),
	*strncat(),
	*strchr(),
	*strrchr(),
	*strpbrk(),
	*strtok();
extern	int
	strcmp(),
	strncmp(),
	strlen(),
	strspn(),
	strcspn();

extern	char
	*strdup();
/*
 * Added String functions.
 */

char *strstr(/*const char *s, const char *wanted*/);
char *strerror(/*int errnum*/);

/*
 * V7 and Berklix compatibility per Henry Spencer's string library.
 * These functions will map to the correct Xenix 3.2 string functions
 * and mem functions.
 */
char *index(/*const char *s, int charwanted*/);
char *rindex(/*const char *s, int charwanted*/);
int bcopy(/*const char *src, char *dst, int length*/);
int bcmp(/*const char *s1, const char *s2, int length*/);
int bzero(/*char *dst, int length*/);

