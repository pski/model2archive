char *memcpy(/*char *dst, const char *src, int size*/);
char *memccpy(/*char *dst, const char *src, int ucharstop, int size*/);
int memcmp(/*const char *s1, const char *s2, int size*/);
char *memchr(/*const char *s, int ucharwanted, int size*/);
char *memset(/*char *s, int ucharfill, int size*/);
