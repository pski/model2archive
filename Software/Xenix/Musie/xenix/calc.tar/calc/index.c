/* index - return index of first occurrence of char c in string s
 *	pointer version
 */
#include "local.h"
char *index(s, c)
	char s[], c;
	{
	while (*s != '\0' && *s != c)
		++s;
	return (*s == c ? s : NULL);
	}
