/* local.h - definitions for use with
 *      Learning to Program in C
 */
#ifndef FAIL
#include <stdio.h>
#define FAIL		1
#define FOREVER		for (;;)
#define NO			0
#define STDERR		2
#define STDIN		0
#define STDOUT		1
#define SUCCEED		0
#define YES			1
#define bits		ushort
#define bool		int
#define metachar	short
#define tbool		char
#define ushort      unsigned  /* use unsigned short, if you can */
#define void		int
#define getln(s, n) ((fgets(s, n, stdin)==NULL) ? EOF : strlen(s))
#define ABS(x)		(((x) < 0) ? -(x) : (x))
#define MAX(x, y)	(((x) < (y)) ? (y) : (x))
#define MIN(x, y)	(((x) < (y)) ? (x) : (y))
#endif
