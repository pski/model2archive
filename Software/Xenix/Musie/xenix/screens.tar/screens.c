#include <stdio.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <bsd/dirent.h>
#define direct dirent

main()
{
	int i,q,filno;
	int graph = 0;
	struct direct **nlist;
	int select();
	int scandir();
	char dirname[80],fname[80];

	srandom(time(0));
	strcpy(dirname,getenv("SCREENS"));
	strcat(dirname,"/screens");
	if (chdir(dirname)) {
	    fprintf(stderr,"mode: You must have a $SCREENS/screens directory.\n");
	    exit(1);
	}
	q = scandir(dirname, &nlist, select, NULL);
	if (q < 1) {
		fprintf(stderr,"mode: You must have at least one file in ");
		fprintf(stderr,"your $SCREENS/screens directory.\n");
		exit(1);
	}
	filno = ((random()>>4)%q);
	strcpy(fname,nlist[filno]->d_name);
	if ((strind(fname,".g") == strlen(fname) - 2) && (!strncmp(getenv("TERM"),"z",1)))
		graph = 1;
	if (graph)
		printf("\033[10m");
	shofile(fname);
	if (graph)
		printf("\033[11m");
	exit(0);
}

int select(dirpt)
struct direct *dirpt;
{
	struct stat s;

	stat(dirpt->d_name,&s);
	if ((s.st_mode & S_IFMT) == S_IFREG)
		return(1);
	else
		return(0);
}

int strind(str1,str2)
char *str1,*str2;

{
	int c,res;

	res = 0;
	if (str1 != NULL)
		for (c=0; c<=strlen(str1)-strlen(str2); c++)
			if (!strncmp(&str1[c],str2,strlen(str2)))
				return(c);
}

nochar(string,c)
char *string,c;

{
	char *p;

	for (p=string;*p != c && *p != '\0'; ++p)
		;

	*p = '\0';

	return;
}

shofile(fname)
char *fname;

{
	FILE *f;
	int c;

	f = fopen(fname,"r");
	
	while ((c=fgetc(f)) != EOF)
		putchar(c);
}

